# sv2022-basesDeDades
Exercicis de Bases de dades, 1r DAW, SV 22/23
