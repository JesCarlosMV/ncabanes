/*
Para una tabla como esta:

CREATE TABLE registro (
    codigo VARCHAR2(10) PRIMARY KEY,  
    nombre VARCHAR2(30)
);

Crea un script PL/SQL, con un bloque anónimo que obtenga la 
cantidad de datos que contienen una A en el nombre, lo guarde en una 
variable llamada "cantidad" y muestre el valor de esa cantidad en caso 
de ser mayor que 0, o el texto "Ninguno" en caso contrario.
*/

DECLARE
	cantidad NUMBER;

BEGIN
	SELECT COUNT(*) INTO cantidad
	FROM registro
	WHERE nombre LIKE '%A%';
	
	IF cantidad > 0 THEN
		dbms_output.put_line(cantidad);
	ELSE
		dbms_output.put_line('Ninguno');
	END IF;
END;
