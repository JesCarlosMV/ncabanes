/* Crea un PROCEDURE PL/SQL anomenat EscriureJocs que reba el nom d'una 
plataforma com a paràmetre i escriga els noms dels jocs d'aqueixa plataforma, 
tots ells en la mateixa línia i separats per " - ". */

CREATE OR REPLACE PROCEDURE EscriureJocs( 
    nomPlataf IN VARCHAR2) 
IS
   CURSOR cj IS
        SELECT j.nom
        FROM jocs j INNER JOIN plataformes p
        ON p.codi = codiPlataforma
        WHERE p.nom = nomPlataf
        ORDER BY j.nom;
    resultat VARCHAR2(1000) := '';

BEGIN
    FOR joc in cj LOOP
        resultat := resultat || joc.nom || ' - ';
    END LOOP;
    dbms_output.put_line(resultat);
END EscriureJocs;

-- Ús

EXECUTE EscriureJocs('Amstrad CPC');
