-- A partir de les taules de ciutats i països:

-- Crea una vista amb: nom de cada ciutat, població de la ciutat, nom del 
-- seu país, continent, regió i població del país.

CREATE VIEW ciudadPais AS
	SELECT city.name AS ciudad, 
		city.population AS poblCiudad,		
		country.name AS pais, 
		continent AS continente, 
		region, 
		country.population AS poblPais
	FROM city, 
		country
	WHERE
		city.countryCode = country.code;
		
SELECT * FROM ciudadPais;

-- Usa aqueixa vista per a trobar: Quantitat de ciutats per país

SELECT pais, COUNT(*)
FROM ciudadPais
GROUP BY pais;
