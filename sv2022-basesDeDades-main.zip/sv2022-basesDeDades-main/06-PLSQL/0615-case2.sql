-- Mostra la quantitat de jocs que tenim de la plataforma amb codi 
-- "ps3"... usant números romans! (d'1 a 5). Has d'emprar un script PL/SQL 
-- i la sentència CASE.

DECLARE
    quantitatPS3 NUMBER (3);

BEGIN
    SELECT COUNT(*)
    INTO quantitatPS3
    FROM jocs
    WHERE codiPlataforma = 'ps3';

    CASE quantitatPS3

        WHEN 0 THEN
            dbms_output.put_line('No hi ha jocs de PS3.');

        WHEN 1 THEN
            dbms_output.put_line('Hi ha I joc de PS3.');

        WHEN 2 THEN
            dbms_output.put_line('Hi ha II jocs de PS3.');

        WHEN 3 THEN
            dbms_output.put_line('Hi ha III jocs de PS3.');

        WHEN 4 THEN
            dbms_output.put_line('Hi ha IV jocs de PS3.');

        WHEN 5 THEN
            dbms_output.put_line('Hi ha V jocs de PS3.');

        ELSE
            dbms_output.put_line('Hi ha més de V jocs de PS3.');

    END CASE;
END;
