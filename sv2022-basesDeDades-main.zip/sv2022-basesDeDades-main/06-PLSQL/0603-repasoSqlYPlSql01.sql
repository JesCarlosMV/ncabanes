-- Partiendo de una tabla como ésta:

CREATE TABLE atletas(
    dorsal NUMBER(4) PRIMARY KEY, 
    nombre VARCHAR2(30),
    prueba VARCHAR2(20),
    resultado NUMBER(8,3)
);

-- Datos de ejemplo

INSERT INTO atletas VALUES (11, 'Usain Bolt', '100 m', 9.58);
INSERT INTO atletas VALUES (12, 'Carl Lewis', '100 m', 9.86);
INSERT INTO atletas VALUES (21, 'Usain Bolt', '200 m', 19.19);
INSERT INTO atletas VALUES (31, 'Carl Lewis', 'Salto de longitud', 8.54);
INSERT INTO atletas VALUES (32, 'Mike Powell', 'Salto de longitud', 8.95);

-- 1.- Muestra, para cada prueba, la cantidad de resultados que tenemos.

SELECT prueba, COUNT(*)
FROM atletas
GROUP BY prueba;

-- 2.- Muestra el nombre de los atletas para los que tenemos dos o más resultados.

SELECT nombre, COUNT(*)
FROM atletas
GROUP BY prueba
HAVING COUNT(*) >= 2;

-- 3.- Muestra el nombre del atleta con el resultado más bajo en la prueba "100 m", usando ORDER BY y la sintaxis de Oracle.

SELECT nombre
FROM atletas
WHERE prueba = '100 m'
ORDER BY resultado
FETCH NEXT 1 ROWS ONLY;

-- 4.- Muestra el nombre del atleta con el resultado más bajo en la prueba "100 m", usando MAX o MIN.

SELECT nombre
FROM atletas
WHERE prueba = '100 m'
AND resultado = 
(
	SELECT MIN(resultado)
	FROM atletas
	WHERE prueba = '100 m'
);

-- 5.- Muestra el nombre del atleta con el resultado más bajo en la prueba "100 m", usando ANY o ALL.

SELECT nombre
FROM atletas
WHERE prueba = '100 m'
AND resultado <= ALL
(
	SELECT resultado
	FROM atletas
	WHERE prueba = '100 m'
);

-- 6.- Muestra el nombre del atleta con el resultado más bajo en la prueba "100 m", usando EXISTS o NOT EXISTS.

SELECT nombre
FROM atletas a1
WHERE prueba = '100 m'
AND NOT EXISTS
(
	SELECT resultado
	FROM atletas a2
	WHERE prueba = '100 m'
	AND a1.resultado > a2.resultado
);

-- 7.- Muestra los nombres de los atletas que han participado en una prueba en la que también ha participado "Usain Bolt", usando IN o NOT IN.

SELECT nombre FROM atletas 
WHERE prueba IN
(
	SELECT prueba FROM atletas 
	WHERE nombre = 'Usain Bolt'
);

-- 8.- Muestra los nombres de los atletas que han participado en una prueba en la que también ha participado "Usain Bolt", usando ANY o ALL.

SELECT nombre FROM atletas 
WHERE prueba = ANY
(
	SELECT prueba FROM atletas 
	WHERE nombre = 'Usain Bolt'
);

-- 9.- Muestra los nombres de los atletas que han participado en una prueba en la que también ha participado "Usain Bolt", usando EXISTS o NOT EXISTS.

SELECT nombre FROM atletas a1
WHERE EXISTS
(
	SELECT * FROM atletas a2
	WHERE a2.nombre = 'Usain Bolt'
	AND a1.prueba = a2.prueba
);

-- 10.- Crea un bloque anónimo en PL/SQL que obtenga el mayor resultado para la prueba "Salto de longitud", lo guarde en una variable y muestre esa variable en pantalla.

DECLARE
	saltoMax NUMBER(8,3);

BEGIN
	SELECT MAX(resultado)
	INTO saltoMax
	FROM atletas
	WHERE prueba = 'Salto de longitud';
	
	dbms_output.put_line(saltoMax);
END;
