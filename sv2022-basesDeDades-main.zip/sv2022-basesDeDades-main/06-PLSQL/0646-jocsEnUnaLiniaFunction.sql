/* Crea una FUNCTION en PL/SQL anomenada NomsDeJocs que reba el nom d'una 
plataforma com a paràmetre i retorne una cadena formada pels noms dels jocs 
d'aqueixa plataforma, tots ells en la mateixa línia i separats per " - ". */

CREATE OR REPLACE FUNCTION NomsDeJocs( 
    nomPlataf IN VARCHAR2)
RETURN VARCHAR2
IS
   CURSOR cj IS
        SELECT j.nom
        FROM jocs j INNER JOIN plataformes p
        ON p.codi = codiPlataforma
        WHERE p.nom = nomPlataf
        ORDER BY j.nom;
    resultat VARCHAR2(1000) := '';

BEGIN
    FOR joc in cj LOOP
        IF LENGTH(resultat) > 0 THEN
            resultat := resultat || ' - ' || joc.nom;
        ELSE
            resultat := joc.nom;
        END IF;
    END LOOP;
    RETURN resultat;
END NomsDeJocs;

-- Ús

EXECUTE dbms_output.put_line(NomsDeJocs('Amstrad CPC'));
