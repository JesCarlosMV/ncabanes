-- Crea un procediment "EscriureGuions", que escriga diversos guions en 
-- l'eixida de la base de dades, tants com s'indiquen en un paràmetre 
-- numèric (d'entrada).

CREATE OR REPLACE PROCEDURE EscriureGuions(numero IN NUMBER) 
IS
    guions VARCHAR2(100) := '';

BEGIN
    
    FOR i IN 1..numero LOOP
        guions := guions || '-';
    END LOOP;

    dbms_output.put_line(guions);

END EscriureGuions;

-- Ús 1

BEGIN
    EscriureGuions(10);
END; 

-- Ús 2

EXECUTE EscriureGuions(10);
