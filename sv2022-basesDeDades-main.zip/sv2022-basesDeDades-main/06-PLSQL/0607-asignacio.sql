-- Mostra les dues últimes xifres de l'any de llançament del joc el codi 
-- del qual és "last1". Primer hauràs d'obtindre la dada de l'any de 
-- llançament i després hauràs de bolcar les seues dues últimes xifres a 
-- una variable auxiliar, que finalment mostraràs en pantalla.

DECLARE
  anyJocLast  jocs.anyLlancament % TYPE;
  anyjocLast2 jocs.anyLlancament % TYPE;

BEGIN
  SELECT jocs.anyLlancament
  INTO anyJocLast
  FROM jocs
  WHERE codi = 'last1';

  anyJocLast2 := MOD(anyJocLast, 100);

  dbms_output.put_line('Año de Last1: ' || anyJocLast2);
END;
