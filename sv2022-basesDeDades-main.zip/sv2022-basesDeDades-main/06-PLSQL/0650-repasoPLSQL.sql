-- 1.- Crea una sentencia SELECT que obtenga los nombres de todos los 
-- juegos, ordenados alfabéticamente y pruébala.

SELECT nom
FROM jocs
ORDER BY nom;

-- 2.- Crea una sentencia SELECT que obtenga el nombre del primer juego en 
-- orden alfabético (usando sintaxis de Oracle) y pruébala.

SELECT nom
FROM jocs
ORDER BY nom
FETCH FIRST 1 ROWS ONLY;

-- 3.- Crea un script PL/SQL que contenga un bloque anónimo, que utilice 
-- la sentencia SELECT anterior para obtener el nombre del primer juego en 
-- orden alfabético (usando sintaxis de Oracle). Guarda ese nombre en una 
-- variable llamada "v_nomPrimerJoc" y muestra el valor de esa variable.

DECLARE
    v_primerJoc jocs.nom % TYPE;

BEGIN
    SELECT nom
    INTO v_primerJoc
    FROM jocs
    ORDER BY nom
    FETCH FIRST 1 ROWS ONLY;

    dbms_output.put_line(v_primerJoc);
END;


-- 4.- Intenta crear un script PL/SQL que contenga un bloque anónimo, use 
-- una SELECT como la primera (nombres de todos los juegos) y trate de 
-- guardar esos nombres en una variable "v_nom" y mostrar dicha variable. 
-- Verás la ejecución se interrumpirá con una excepción, porque es SELECT 
-- INTO necesita que el resultado de la consulta sea exactamente un 
-- registro, y nuestra tabla tiene más de un registro.

DECLARE
    v_nom jocs.nom % TYPE;

BEGIN
    SELECT nom
    INTO v_nom
    FROM jocs
    ORDER BY nom;

    dbms_output.put_line(v_nom);
END;

-- 5.- Crea un script PL/SQL que contenga un bloque anónimo, que utilice 
-- un cursor y un bucle LOOP para mostrar los nombres de todos los juegos, 
-- ordenados alfabéticamente (aprovechando la consulta que hiciste en el 
-- primer ejercicio).

-- Solución "normal"

DECLARE
    CURSOR jocs_cursor IS
    SELECT nom
    FROM jocs
    ORDER BY nom;

    v_nom jocs.nom % TYPE;

BEGIN 
    OPEN jocs_cursor;
    LOOP
        FETCH jocs_cursor INTO v_nom;
        EXIT WHEN jocs_cursor%NOTFOUND;
        dbms_output.put_line(v_nom);
    END LOOP;
    CLOSE jocs_cursor;
END; 

-- Solución con "if" (antinatural)

DECLARE
    CURSOR jocs_cursor IS
    SELECT nom
    FROM jocs
    ORDER BY nom;

    v_nom jocs.nom % TYPE;

BEGIN 
    OPEN jocs_cursor;
    LOOP
        FETCH jocs_cursor INTO v_nom;
        IF jocs_cursor % NOTFOUND THEN
            EXIT;
        END IF;
        dbms_output.put_line(v_nom);
    END LOOP;
    CLOSE jocs_cursor;
END; 

-- Solución con "%rowtype"

DECLARE
    CURSOR jocs_cursor IS
    SELECT *
    FROM jocs
    ORDER BY nom;

    v_registreJoc jocs % ROWTYPE;

BEGIN 
    OPEN jocs_cursor;
    LOOP
        FETCH jocs_cursor INTO v_registreJoc;
        EXIT WHEN jocs_cursor%NOTFOUND;
        dbms_output.put_line(v_registreJoc.nom);
    END LOOP;
    CLOSE jocs_cursor;
END;

-- 6.- Crea un script PL/SQL que contenga un bloque anónimo, que utilice 
-- un cursor y un bucle LOOP para mostrar los nombres y los años de los 
-- juegos para los que conocemos su año de lanzamiento, ordenados 
-- alfabéticamente.

DECLARE
    CURSOR jocs_cursor IS
    SELECT nom, anyLlancament
    FROM jocs
    WHERE anyLlancament IS NOT NULL
    ORDER BY nom;

    v_nom jocs.nom % TYPE;
    v_anyJoc jocs.anyLlancament % TYPE;

BEGIN 
    OPEN jocs_cursor;
    LOOP
        FETCH jocs_cursor INTO v_nom, v_anyJoc;
        EXIT WHEN jocs_cursor%NOTFOUND;
        dbms_output.put_line(v_nom||' '||v_anyJoc);
    END LOOP;
    CLOSE jocs_cursor;
END; 

-- Variante con %ROWTYPE

DECLARE
    CURSOR jocs_cursor IS
    SELECT *
    FROM jocs
    WHERE anyLlancament IS NOT NULL
    ORDER BY nom;

    v_regJoc jocs % ROWTYPE;

BEGIN 
    OPEN jocs_cursor;
    LOOP
        FETCH jocs_cursor INTO v_regJoc;
        EXIT WHEN jocs_cursor%NOTFOUND;
        dbms_output.put_line(v_regJoc.nom
            ||' '||v_regJoc.anyLlancament);
    END LOOP;
    CLOSE jocs_cursor;
END;

-- 

-- 7.- Crea una variante del ejercicio anterior usando WHILE: un script 
-- PL/SQL que contenga un bloque anónimo, que utilice un cursor y un bucle 
-- WHILE para mostrar los nombres y los años de los juegos para los que 
-- conocemos su año de lanzamiento, ordenados alfabéticamente.

DECLARE
    CURSOR jocs_cursor IS
    SELECT DISTINCT nom, anyLlancament
    FROM jocs
    WHERE anyLlancament IS NOT NULL
    ORDER BY nom;

    v_nomJoc jocs.nom % TYPE;
    v_anyJoc jocs.anyLlancament % TYPE;

BEGIN 
    OPEN jocs_cursor;
    FETCH jocs_cursor INTO v_nomJoc, v_anyJoc;
    WHILE jocs_cursor%FOUND LOOP
        dbms_output.put_line(v_nomJoc ||' '||v_anyJoc);
        FETCH jocs_cursor INTO v_nomJoc, v_anyJoc;
    END LOOP;
    CLOSE jocs_cursor;
END;

-- 8.- Crea una variante del ejercicio anterior usando FOR: un script 
-- PL/SQL que contenga un bloque anónimo, que utilice un cursor y un bucle 
-- FOR para mostrar los nombres y los años de los juegos para los que 
-- conocemos su año de lanzamiento, ordenados alfabéticamente.

DECLARE
    CURSOR jocs_cursor IS
    SELECT DISTINCT nom, anyLlancament
    FROM jocs
    WHERE anyLlancament IS NOT NULL
    ORDER BY nom;

    v_nom jocs.nom % TYPE;
    v_anyJoc jocs.anyLlancament % TYPE;

BEGIN 
    FOR reg IN jocs_cursor LOOP
        dbms_output.put_line(reg.nom||' '||reg.anyllancament);
    END LOOP;
END; 

-- 9.- Crea un procedimiento (PROCEDURE) llamado "MostrarJocsAmbAny", que 
-- muestre los nombres y los años de los juegos para los que conocemos su 
-- año de lanzamiento, ordenados alfabéticamente, empleando cualquiera de 
-- los cursores anteriores. Prueba el procedimiento desde un bloque 
-- anónimo de PL/SQL.

CREATE OR REPLACE PROCEDURE MostrarJocsAmbAny IS
    CURSOR jocs_cursor IS
    SELECT nom, anyLlancament
    FROM jocs
    WHERE anyLlancament IS NOT NULL
    ORDER BY nom;
    
BEGIN 
    FOR joc IN jocs_cursor LOOP
        dbms_output.put_line(joc.nom ||' '|| joc.anyllancament);  
    END LOOP;
END MostrarJocsAmbAny;

-- Forma de llamar 1

EXECUTE MostrarJocsAmbAny;

-- Forma de llamar 2

BEGIN
    MostrarJocsAmbAny;
END; 

-- 10.- Crea un procedimiento (PROCEDURE) llamado "MostrarJocsDAny", que 
-- muestre los nombres de los juegos que se lanzaron en un cierto año, que 
-- se indicará como parámetro. Emplea el tipo de cursor que prefieras. 
-- Prueba el procedimiento empleando EXECUTE y un año prefijado.

CREATE OR REPLACE PROCEDURE MostrarJocsAmbAny IS
    CURSOR jocs_cursor IS
    SELECT nom, anyLlancament
    FROM jocs
    WHERE anyLlancament IS NOT NULL
    ORDER BY nom;
    
BEGIN 
    FOR joc IN jocs_cursor LOOP
        dbms_output.put_line(joc.nom ||' '|| joc.anyllancament);  
    END LOOP;
END MostrarJocsAmbAny;

-- Forma de llamar 1

EXECUTE MostrarJocsAmbAny;

-- Forma de llamar 2

BEGIN
    MostrarJocsAmbAny;
END; 

-- 11.- Crea una función (FUNCTION) llamada "ObtindreAny", que devuelva el 
-- año de lanzamiento en un cierto juego, cuyo nombre se indicará como 
-- parámetro. Si el juego no existe, devolverás el valor -1. Prueba la 
-- función desde un bloque anónimo de PL/SQL.

-- Planteamiento 1, con cursores

CREATE OR REPLACE FUNCTION ObtindreAny(nomJoc IN VARCHAR2)
RETURN NUMBER
IS
    CURSOR jocs_cursor IS
    SELECT anyLlancament
    FROM jocs
    WHERE nom = nomJoc
    ORDER BY anyLlancament;
    
    v_any jocs.anyLlancament % TYPE;

BEGIN 
    OPEN jocs_cursor;
    
    FETCH jocs_cursor INTO v_any;
    
    IF jocs_cursor % NOTFOUND THEN
        RETURN -1;
    ELSE
        RETURN v_any;
    END IF;

    CLOSE jocs_cursor;
END ObtindreAny;

-- Forma de llamar 1

EXECUTE dbms_output.put_line(ObtindreAny('Manic Miner'));

-- Forma de llamar 2

BEGIN
    dbms_output.put_line(ObtindreAny('Manic Miner'));
END;

-- Planteamiento 2, con SELECT consecutivas

CREATE OR REPLACE FUNCTION ObtindreAny(nomJoc IN VARCHAR2)
RETURN NUMBER
IS
    
    v_any jocs.anyLlancament % TYPE;
    v_quantitat NUMBER;
        
BEGIN 

    SELECT COUNT(*)
    INTO v_quantitat
    FROM jocs
    WHERE nom = nomJoc;
    
    IF v_quantitat = 0 THEN
        RETURN -1;
    END IF;
    
    SELECT anyLlancament
    INTO v_any
    FROM jocs
    WHERE nom = nomJoc
    ORDER BY anyLlancament
    FETCH NEXT 1 ROWS ONLY;
    
    RETURN v_any;
END ObtindreAny;

-- Forma de llamar 1

EXECUTE dbms_output.put_line(ObtindreAny('Manic Miner'));

-- Forma de llamar 2

BEGIN
    dbms_output.put_line(ObtindreAny('Manic Miner'));
END; 
