-- A partir de estas tablas y de estos datos de ejemplo:

CREATE TABLE productos (
  codigo VARCHAR(6) PRIMARY KEY,
  nombre VARCHAR(30),
  precioCoste NUMBER(7,2)
);

CREATE TABLE categoriasProd (
  codigo VARCHAR(4) PRIMARY KEY,
  nombre VARCHAR(30)
);

CREATE TABLE perteneceA (
  codigoProd VARCHAR(6),
  codigoCateg VARCHAR(4),
  PRIMARY KEY (codigoProd, codigoCateg)
);

INSERT INTO productos VALUES ('p1','Producto 1', 23);
INSERT INTO productos VALUES ('p2','Producto 2', 32.5);
INSERT INTO productos VALUES ('p3','Producto 3', NULL);

INSERT INTO categoriasProd VALUES ('c1','Categoría 1');
INSERT INTO categoriasProd VALUES ('c2','Categoría 2');
INSERT INTO categoriasProd VALUES ('c3','Categoría 3');

INSERT INTO perteneceA VALUES ('p1','c1');
INSERT INTO perteneceA VALUES ('p1','c2');
INSERT INTO perteneceA VALUES ('p2','c2');


-- 6.- Crea un bloque anónimo que muestre el código de cada producto, su 
-- nombre y su precio en dólares, suponiendo un cambio de 1 Euro = 1.09 
-- dólares. Debes emplear un bloque WHILE.

DECLARE
    CURSOR c IS
    SELECT * FROM productos;
    v_producto productos%ROWTYPE;
    v_dolares NUMBER(7,2);
BEGIN
    OPEN c;
    FETCH c INTO v_producto;
    WHILE c%FOUND LOOP
        v_dolares := v_producto.precioCoste * 1.09;
        dbms_output.put_line(v_producto.codigo 
            || ' - ' || v_producto.nombre 
            || ': ' ||  v_dolares || ' dolares');
        FETCH c INTO v_producto;
    END LOOP;
    CLOSE c;
END;


-- 7.- Crea una función "PrecioMedio", que reciba el código de una 
-- categoría y devuelva el precio medio de los artículos que hay en esa 
-- categoría, o -99 en caso de que no haya ningún artículo en esa 
-- categoría.

-- Alternativa 1: SELECT INTO + EXCEPTION

CREATE OR REPLACE FUNCTION PrecioMedio (v_codCateg VARCHAR) 
RETURN NUMBER 
IS
    CURSOR c IS
        SELECT precioCoste
        FROM productos, perteneceA
        WHERE productos.codigo = codigoProd
        AND codigoCateg = v_codCateg;
    
    v_cantidad NUMBER(5);
    v_precioTotal NUMBER(7,2);

BEGIN
    SELECT COUNT(*)
    INTO v_cantidad
    FROM productos, perteneceA
    WHERE productos.codigo = codigoProd
    AND codigoCateg = v_codCateg
    GROUP BY codigoCateg;
    v_precioTotal := 0;
    FOR cursor IN c LOOP
        v_precioTotal := v_precioTotal + cursor.precioCoste;
    END LOOP;
    
    RETURN v_precioTotal / v_cantidad;
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN 
            RETURN -99;

END PrecioMedio;

-- Prova, amb categoria que existeix

BEGIN
    dbms_output.put_line(PrecioMedio('c2'));
END;

-- Prova, amb categoria que no existeix

BEGIN
    dbms_output.put_line(PrecioMedio('c7'));
END;

-- Alternativa 2: Sense EXCEPTION

CREATE OR REPLACE FUNCTION PrecioMedio (v_codCateg VARCHAR) 
RETURN NUMBER 
IS
    v_cantidad NUMBER(5);
    v_precioMedio NUMBER(7,2);

BEGIN
    SELECT COUNT(*)
    INTO v_cantidad
    FROM categoriasProd c 
    WHERE c.codigo = v_codCateg;

    IF v_cantidad = 0 THEN
        RETURN -99;
    END IF;
    
    SELECT AVG(precioCoste)
        INTO v_precioMedio
        FROM productos, perteneceA
        WHERE productos.codigo = codigoProd
        AND codigoCateg = v_codCateg;

    RETURN v_precioMedio;

END PrecioMedio;


-- 8.- Crea un procedimiento "MostrarCategoriasYProds", que, sin recibir 
-- parámetros, muestre el nombre de cada categoría, y, en la línea 
-- siguiente, los nombres de todos los productos que pertenecen a esa 
-- categoría, todos ellos en la misma línea, separados por un espacio en 
-- blanco.

-- Plantejament desitjable: cursor niat (no funciona)

CREATE OR REPLACE PROCEDURE MostrarCategoriasYProds IS
    v_productos VARCHAR(100);
    
BEGIN
    FOR categ IN (SELECT nombre AS categoria FROM categoriasProd) LOOP
        dbms_output.put_line(categ.nombre);
        v_productos := '';
        FOR prod IN 
            (SELECT productos.nombre FROM productos, perteneceA, categoriasProd
                WHERE perteneceA.codigoProd = productos.codigo
                AND perteneceA.codigoCateg = categoriasProd.codigo
                AND categoriasProd.nombre = categ.nombre) LOOP
            
            v_productos := v_productos || ' ' || prod.nombre;
        END LOOP;
        dbms_output.put_line(v_productos);
    END LOOP;
END MostrarCategoriasYProds;

BEGIN
    MostrarCategoriasYProds;
END;

-- Plantejament alternatiu: un únic cursor amb totes les dades

-- Prova prèvia

SELECT categoriasProd.nombre as nombreCategoria,
    productos.nombre as nombreProducto
FROM categoriasProd 
    LEFT JOIN perteneceA ON perteneceA.codigoCateg = categoriasProd.codigo 
    LEFT JOIN productos ON perteneceA.codigoProd = productos.codigo
ORDER BY nombreCategoria, nombreProducto;

-- Procedure

CREATE OR REPLACE PROCEDURE MostrarCategoriasYProds IS
    CURSOR c IS
        SELECT categoriasProd.nombre as nombreCategoria,
            productos.nombre as nombreProducto
        FROM categoriasProd 
            LEFT JOIN perteneceA ON perteneceA.codigoCateg = categoriasProd.codigo 
            LEFT JOIN productos ON perteneceA.codigoProd = productos.codigo
        ORDER BY nombreCategoria, nombreProducto;

    v_categAnterior categoriasProd.nombre % TYPE := '';
    v_listaProductos VARCHAR(1000) := '';
    
BEGIN
    FOR dato IN c LOOP
        IF v_categAnterior <> dato.nombreCategoria THEN
            dbms_output.put_line(v_listaProductos);
            dbms_output.put_line(dato.nombreCategoria);
            v_categAnterior := dato.nombreCategoria;
            v_listaProductos := '';
        END IF;
        v_listaProductos := v_listaProductos || dato.nombreProducto || ' - ';
    END LOOP;
    dbms_output.put_line(v_listaProductos);
END MostrarCategoriasYProds;

-- Prova

BEGIN
    MostrarCategoriasYProds;
END;


-- 9.- Crea un trigger llamado "PrecioPorDefecto" que, cuando se guarda un 
-- nuevo producto, si no se indica su precio, le asigne precio 10 si es de 
-- categoría 1 o precio 15 si es de categoría 2. Si es de cualquier otra 
-- categoría, dejará el valor NULL.

CREATE OR REPLACE TRIGGER PrecioPorDefecto
BEFORE INSERT ON productos
FOR EACH ROW
DECLARE
    v_categoria VARCHAR(4);
BEGIN
    SELECT codigoCateg
        INTO v_categoria
        FROM perteneceA
        WHERE codigoProd = :NEW.codigo;
        
    CASE v_categoria
        WHEN 'c1' THEN
            :NEW.precioCoste := 10;
        WHEN 'c2' THEN
            :NEW.precioCoste := 15;
        ELSE
            :NEW.precioCoste := NULL;
    END CASE;
    
END PrecioPorDefecto;

-- Prova

INSERT INTO perteneceA VALUES ('p4','c1');
INSERT INTO productos VALUES ('p4','Producto 4', NULL);
SELECT * FROM productos WHERE codigo = 'p4';

INSERT INTO perteneceA VALUES ('p5','c2');
INSERT INTO productos VALUES ('p5','Producto 5', NULL);
SELECT * FROM productos WHERE codigo = 'p5';

INSERT INTO perteneceA VALUES ('p6','c3');
INSERT INTO productos VALUES ('p6','Producto 6', NULL);
SELECT * FROM productos WHERE codigo = 'p6';


-- 10.- Crea un procedimiento "MostrarPreciosMedios", que se apoye en la 
-- función "PrecioMedio" para mostrar los precios medios de todas las 
-- categorías que tenemos almacenadas.

CREATE OR REPLACE PROCEDURE MostrarPreciosMedios IS
    CURSOR c IS
        SELECT codigo
        FROM categoriasProd;
    
BEGIN
    FOR registro IN c LOOP
        dbms_output.put_line(registro.codigo
            || ': ' || PrecioMedio(registro.codigo));
    END LOOP;
END MostrarPreciosMedios;

BEGIN
    MostrarPreciosMedios;
END;
