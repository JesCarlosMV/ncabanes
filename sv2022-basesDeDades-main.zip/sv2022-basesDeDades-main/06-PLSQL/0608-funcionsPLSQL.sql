-- Mostra les quatre primeres lletres de la plataforma el codi de la qual 
-- és "psx", després de convertir-les a minúscules. Primer hauràs 
-- d'obtindre el nom de la plataforma i després bolcar a una variable 
-- auxiliar el resultat de convertir-lo a minúscules i d'extraure les 
-- seues 4 primeres lletres. Inclou un comentari de diverses línies, que 
-- permeta recordar posteriorment què estaves practicant en aquest 
-- exercici.

    /*
        Declaro 2 variables
        En el declare hago un select con el nombre de la plataforma 
            y lo guardo en v_platCuatro
        Despues creo otra variable
    */


DECLARE
    v_platCuatro plataformes.nom%TYPE;
    v_platCuatroMayus plataformes.nom%TYPE;

BEGIN
    SELECT nom
    INTO v_platCuatro
    FROM plataformes
    WHERE codi = 'psx';
    
    v_platCuatroMayus := SUBSTR(v_platCuatro, 1, 4);
    v_platCuatroMayus := LOWER(v_platCuatroMayus);
    dbms_output.put_line(v_platCuatroMayus);
END;
