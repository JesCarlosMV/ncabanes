 -- Crea un bucle FOR que mostre els números del 20 al 200, 
 -- augmentant de 10 en 10

BEGIN

    /* 1: Multiplicant el comptador */

    FOR i IN 2 .. 20 LOOP
        dbms_output.put_line(i * 10);
    END LOOP;
    
    /* 2: Amb IF */
    
    FOR i IN REVERSE 10 .. 200 LOOP
        IF MOD(i,10) = 0 THEN
            dbms_output.put_line(i);
        END IF;
    END LOOP;
    
END;
