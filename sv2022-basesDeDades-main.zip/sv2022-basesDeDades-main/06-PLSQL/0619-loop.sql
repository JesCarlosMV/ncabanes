/* Crea un bucle LOOP que mostre els números del 10 al 100, augmentant
de 10 en 10. Has d'emprar la sintaxi EXIT WHEN. */

DECLARE
   num NUMBER := 10;

BEGIN
   LOOP
      EXIT WHEN num > 100;
      dbms_output.put_line(num);
      num := num + 10;
   END LOOP;
END;
