-- 1.- Crea un procediment "MostrarNomsDeJocs", que mostre els noms de 
-- tots els jocs que tenim en la nostra base de dades. Si algun joc està 
-- repetit (com, en les nostres dades d'exemple, Manic Miner), haurà 
-- d'aparéixer " (Repetit)" a continuació del nom.

CREATE OR REPLACE PROCEDURE MostrarNomsDeJocs IS
    CURSOR nomJocs IS
    SELECT nom, COUNT(*) as quantitat
    FROM jocs
    GROUP BY nom
    ORDER BY nom;

BEGIN
    FOR joc IN nomJocs LOOP
        IF joc.quantitat > 1 THEN
            dbms_output.put_line(joc.nom || ' (Repetit)' );
        ELSE
            dbms_output.put_line(joc.nom);
        END IF;
    END LOOP;
END MostrarNomsDeJocs;


-- Prova 1

EXECUTE MostrarNomsDeJocs;

-- Prova 2

BEGIN
    MostrarNomsDeJocs;
END; 

-- 2.- Crea un procediment "InserirPlatRepetitiu", que reba com a 
-- paràmetres el prefix del codi, el nom de plataforma, el valor numèric 
-- inicial i el valor numèric final, i inserisca diverses plataformes 
-- seguides, amb codis i nom correlatius entre aqueixos valors, com en 
-- aquest exemple: InserirPlatRepetitiu("sgs", "SupaGamStation ", 1, 6) 
-- inseriria des d'una plataforma amb codi "sgs1" i nom "SupaGamStation 1" 
-- fins a acabar amb una que tinga codi "sgs6" i nom "SupaGamStation 6".

CREATE OR REPLACE PROCEDURE InserirPlatRepetitiu (
    prefixCodi IN VARCHAR2, 
    nomPlataforma IN VARCHAR2, 
    valorNumericInicial IN NUMBER, 
    valorNumericFinal IN NUMBER)
IS
    
    nouPrefix VARCHAR(5);
    nouNom VARCHAR(50);
    
BEGIN
    FOR i IN valorNumericInicial..valorNumericFinal
    LOOP
        nouPrefix := prefixCodi || i;
        nouNom := nomPlataforma || ' ' || i;
        INSERT INTO plataformes VALUES (nouPrefix, nouNom);
    END LOOP;
END;

-- Prova

EXECUTE InserirPlatRepetitiu('sgs', 'SupaGamStation ', 1, 6);

SELECT * FROM plataformes
WHERE codi LIKE 'sgs%';


-- 3.- Crea un procediment "InserirNouJoc", que reba com a paràmetres el 
-- codi i nom de joc, així com el nom de la plataforma a la qual el volem 
-- associar. Si tot va bé, escriurà "Joc inserit" en la consola d'eixida. 
-- Si aqueixa plataforma no existeix, escriurà "Plataforma no trobada" 
-- (acceptarem que les majúscules puguen canviar en el nom de la 
-- plataforma). Si el joc no es pot inserir (perquè aqueixa clau primària 
-- ja s'haja utilitzat) escriurà "Clau duplicada".


CREATE OR REPLACE PROCEDURE InserirNouJoc(
    p_codiJoc IN jocs.codi %TYPE,
    p_nomJoc IN jocs.nom %TYPE,
    p_nomPlataf IN plataformes.nom %TYPE
)
IS
    v_codiPlataforma plataformes.codi %TYPE;
    
BEGIN
    SELECT codi
    INTO v_codiPlataforma
    FROM plataformes
    WHERE UPPER(nom) = UPPER(p_nomPlataf);
    
    INSERT INTO jocs(codi, nom, codiPlataforma) 
        VALUES (p_codiJoc, p_nomJoc, v_codiPlataforma);
    dbms_output.put_line('Joc inserit.');
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('Plataforma no trobada.');
        WHEN DUP_VAL_ON_INDEX THEN
            dbms_output.put_line('Clau duplicada.');
END InserirNouJoc;


-- Proves

EXECUTE InserirNouJoc('mm30', 'Megaman 2030', 'playstation 6x');
-- Plataforma no trobada.

EXECUTE InserirNouJoc('last1', 'The last of US (PC)', 'pc + steam');
-- Clau duplicada.

EXECUTE InserirNouJoc('hct', 'Horizon Chase Turbo', 'pc + epic');
-- Joc inserit.


-- 4.- Crea un procediment "InserirPlatJoc", que reba com a paràmetres el 
-- codi de plataforma, el nom de plataforma, el codi de joc i el nom de 
-- joc, i inserisca aqueixa plataforma (en cas que no existisca) i aqueix 
-- joc (associant-lo a aqueixa plataforma).


CREATE OR REPLACE PROCEDURE InserirPlatJoc(
    p_codiJoc IN jocs.codi %TYPE,
    p_nomJoc IN jocs.nom %TYPE,
    p_codiPlataf IN plataformes.codi %TYPE,
    p_nomPlataf IN plataformes.nom %TYPE
)
AS
    v_quantitatPlataf NUMBER;
    
BEGIN
    SELECT COUNT(*)
    INTO v_quantitatPlataf
    FROM plataformes
    WHERE codi = p_codiPlataf;
    
    IF v_quantitatPlataf = 0 THEN
        INSERT INTO plataformes VALUES (p_codiPlataf, p_nomPlataf);
        dbms_output.put_line('Plataforma inserida.');
    END IF;
    
    INSERT INTO jocs(codi, nom, codiPlataforma) 
        VALUES (p_codiJoc, p_nomJoc, p_codiPlataf);
    dbms_output.put_line('Joc inserit.');
END InserirPlatJoc;

-- Prova

EXECUTE InserirPlatJoc('smg', 'Super Mario Galaxy', 'wii', 'Nintendo Wii');


-- 5.- Crea una funció "EspaiMitja", que reba com a paràmetre el codi 
-- d'una plataforma i que retorne l'espai mitjà ocupat pels jocs d'aqueixa 
-- plataforma, o bé -1 en cas que la plataforma no existisca.


CREATE OR REPLACE FUNCTION EspaiMitja(p_codiPlat IN jocs.codiPlataforma%TYPE)
RETURN NUMBER
AS
    v_quantitatPlataf NUMBER;
    espai NUMBER;

BEGIN 

    SELECT COUNT(*)
    INTO v_quantitatPlataf
    FROM plataformes
    WHERE codi = p_codiPlat;
    
    IF v_quantitatPlataf = 0 THEN
        RETURN -1;
    END IF;
    
    SELECT AVG(espaiOcupatMb)
    INTO espai
    FROM plataformes, jocs
    WHERE plataformes.codi = p_codiPlat
    AND plataformes.codi = jocs.codiPlataforma;
    
    RETURN espai;

END EspaiMitja;

-- Prova 1 (sense dades)

EXECUTE dbms_output.put_line(EspaiMitja('abcd'));

-- Prova 2

EXECUTE dbms_output.put_line(EspaiMitja('cpc'));


-------

1.- Crea un procedimiento "MostrarNomsDeJocs", que muestre los nombres de todos los juegos que tenemos en nuestra base de datos. Si algún juego está repetido (como, en nuestros datos de ejemplo, Manic Miner), deberá aparecer " (Repetido)" a continuación del nombre.

2.- Crea un procedimiento "InserirPlatRepetitiu", que reciba como parámetros el prefijo del código, el nombre de plataforma, el valor numérico inicial y el valor numérico final, e inserte varias plataformas seguidas, con códigos y nombre correlativos entre esos valores, como en este ejemplo: InserirPlatRepetitiu("sgs", "SupaGamStation ", 1, 6) insertaría desde una plataforma con código "sgs1" y nombre "SupaGamStation 1" hasta terminar con una con código "sgs6" y nombre "SupaGamStation 6".

3.- Crea un procedimiento "InserirNouJoc", que reciba como parámetros el código y nombre de juego, así como el nombre de la plataforma a la que lo queremos asociar. Si todo va bien, escribirá "Juego insertado" en la consola de salida. Si esa plataforma no existe, escribirá "Plataforma no encontrada" (aceptaremos que las mayúsculas puedan cambiar en el nombre de la plataforma). Si el juego no se puede insertar (porque esa clave primaria ya se haya utilizado) escribirá "Clave duplicada".

4.- Crea un procedimiento "InserirPlatJoc", que reciba como parámetros el código de plataforma, el nombre de plataforma, el código de juego y el nombre de juego, e inserte esa plataforma (en caso de que no exista) y ese juego (asociándolo a esa plataforma).

5.- Crea una función "EspaiMitja", que reciba como parámetro el código de una plataforma y que devuelva el espacio medio ocupado por los juegos de esa plataforma, o bien -1 en caso de que la plataforma no exista.
