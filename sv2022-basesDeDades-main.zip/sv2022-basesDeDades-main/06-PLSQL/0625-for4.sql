-- Escriu 10 guions en una mateixa línia, usant FOR

DECLARE
  variable VARCHAR2(20) := '';

BEGIN
    FOR i IN 1..10 LOOP
        variable := variable || '-';
    END LOOP;

    dbms_output.put_line(variable);
END;
