/* Crea un script PL/SQL que empre cursors per a obtindre la següent informació
a partir de la nostra base de dades de jocs i plataformes: per a cada joc de la
base de dades, mostra el seu nom (ordenats alfabèticament) i, al seu costat, el
nom de la plataforma a la qual pertany. Si el nom d'algun joc està repetit
(coincideix amb l'anterior), escriuràs quatre espais en blanc en comptes
d'aquest nom. En aquesta ocasió hauràs d'utilitzar un bucle LOOP, juntament amb
la clàusula EXIT */

DECLARE
    CURSOR cursorJocsPlataformes IS
        SELECT j.nom, p.nom
        FROM jocs j INNER JOIN plataformes p
        ON p.codi = codiPlataforma
        ORDER BY j.nom;

    v_nomJoc jocs.nom % TYPE;
    v_nomPlataforma plataformes.nom % TYPE;

    v_nomJocAnterior jocs.nom % TYPE := '(Ninguno)';

BEGIN
    OPEN cursorJocsPlataformes;

    LOOP
        FETCH cursorJocsPlataformes INTO v_nomJoc, v_nomPlataforma;
        EXIT WHEN cursorJocsPlataformes % NOTFOUND;

        IF v_nomJoc = v_nomJocAnterior THEN
            dbms_output.put_line('     - ' || v_nomPlataforma);
        ELSE
            dbms_output.put_line(v_nomJoc || ' - ' || v_nomPlataforma);
        END IF;
        
        v_nomJocAnterior := v_nomJoc;
    END LOOP;

    CLOSE cursorJocsPlataformes;
END;
