-- A partir de les dades de la taula de plataformes (de jocs), crea un 
-- script que escriba "No tenim dades de plataformes basades en 
-- Playstation", "Tenim dades d'1 plataforma basada en Playstation", 
-- "Tenim dades de 2 plataformes basades en Playstation" o "Tenim dades 
-- de més de 2 plataformes basada en Playstation", segons corresponga, 
-- emprant CASE.

-- Versió A: SUBSTR
 
DECLARE
    v_quantitat NUMBER(3);

BEGIN
    SELECT COUNT(*)
    INTO v_quantitat
    FROM plataformes
    WHERE UPPER(SUBSTR(nom,1,11)) = 'PLAYSTATION';
    
    CASE v_quantitat
        WHEN 0 THEN
            dbms_output.put_line('No tenim dades de plataformes basades en Playstation');
        WHEN 1 THEN
            dbms_output.put_line('Tenim dades de 1 plataforma basada en Playstation');
        WHEN 2 THEN
            dbms_output.put_line('Tenim dades de 2 plataformes basades en Playstation');
        ELSE
            dbms_output.put_line('Tenim dades de més de 2 plataformes basada en Playstation');
    END CASE;
END;
