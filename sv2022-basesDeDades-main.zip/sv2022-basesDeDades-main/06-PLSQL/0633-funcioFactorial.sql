CREATE OR REPLACE FUNCTION Factorial (N IN NUMBER)
    RETURN NUMBER 
AS
BEGIN
    IF N<0 THEN
        RETURN -1;
    ELSIF N=0 THEN
        RETURN 1;
    ELSE
        RETURN N*Factorial(N-1);
    END IF;
END Factorial;


-- --------------------------------------------------------------------


-- Mostrar por pantalla (con bloque anónimo)

BEGIN
    dbms_output.put_line(Factorial(5));
END;



-- Mostrar por pantalla (con execute)

-- No: EXECUTE Factorial(5);

-- No: dbms_output.put_line( EXECUTE ( Factorial(5)) );

EXECUTE dbms_output.put_line(Factorial(5));
