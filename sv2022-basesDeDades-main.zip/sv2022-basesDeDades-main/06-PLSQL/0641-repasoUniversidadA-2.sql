-- Partiendo de la base de datos que puedes encontrar aquí:

-- https://github.com/ncabanes/sv2022-basesDeDades/blob/main/06-PLSQL/0640b-Repaso-Universidad-creacionOracle.sql

-- Realiza los siguientes ejercicios:

-- 1. Devuelve un listado con las asignaturas que no tienen un profesor 
-- asignado, usando LEFT JOIN y COUNT (basado en el ejercicio 1.5.6.5).

SELECT asignatura.nombre
FROM asignatura LEFT JOIN persona
ON asignatura.id_profesor = persona.id
GROUP BY asignatura.nombre
HAVING COUNT(id_profesor) = 0;

-- 2. Devuelve un listado con las asignaturas que no tienen un profesor 
-- asignado, usando IN / NOT IN (basado en el ejercicio 1.5.6.5).

SELECT nombre
FROM asignatura 
WHERE id_profesor NOT IN (SELECT id FROM persona);

-- 3. Devuelve un listado con las asignaturas que no tienen un profesor 
-- asignado, usando EXISTS / NOT EXISTS (basado en el ejercicio 1.5.6.5).

SELECT nombre
FROM asignatura
WHERE NOT EXISTS
    (SELECT persona.id 
    FROM persona
    WHERE persona.id = asignatura.id_profesor);


-- 4. Devuelve un listado con las asignaturas que no tienen un profesor 
-- asignado, usando ALL / ANY (basado en el ejercicio 1.5.6.5).

SELECT nombre
FROM asignatura 
WHERE id_profesor <> ALL (SELECT id FROM persona);
