/*
Crea una funció anomenada "AnyMitja", que reba com a paràmetre el nom 
d'una plataforma de jocs i retorne la mitjana dels anys de llançament 
dels jocs que pertanyen a aqueixa plataforma. Mostra el seu valor per a 
la plataforma anomenada " Amstrad CPC".
*/

CREATE OR REPLACE FUNCTION AnyMitja (plataforma IN VARCHAR2) 
	RETURN NUMBER 
AS
	mitjana NUMBER;
BEGIN
    
    SELECT AVG(anyllancament)
    INTO mitjana
    FROM plataformes, jocs
    WHERE codiPlataforma = plataformes.codi
    AND plataformes.nom = plataforma;
    
    RETURN mitjana;
    
END AnyMitja;

-- LLAMADA A LA FUNCIÓN

DECLARE
    mitjana NUMBER;
BEGIN
    mitjana := AnyMitja('Amstrad CPC');
    dbms_output.put_line(mitjana);
END;
