CREATE OR REPLACE PROCEDURE EscriureDestacat(cadena IN Varchar2) IS
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- ' || cadena || ' ---');
END EscriureDestacat;

-- ....

DECLARE
    missatge VARCHAR2(30) := 'Hola';
BEGIN
    EscriureDestacat(missatge);
END;

-- Alternatiu

EXECUTE EscriureDestacat('Hola');
