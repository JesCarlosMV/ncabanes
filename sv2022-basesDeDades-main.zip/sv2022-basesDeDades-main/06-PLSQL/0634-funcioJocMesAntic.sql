/*
Crea una funció anomenada "JocMesAntic", que reba com a paràmetre el 
nom d'una plataforma de jocs i retorne el nom del joc més antic 
(comprovant el camp de l'any de llançament) que tenim per a aqueixa 
plataforma, o bé el text "Plataforma no trobada" si no existeix una 
plataforma amb aqueix nom. Comprova el seu funcionament.
*/

CREATE OR REPLACE FUNCTION JocMesAntic(nomP IN plataformes.nom % TYPE)
	RETURN jocs.nom %type 
AS
	nomj jocs.nom % TYPE;
	quantitat NUMBER;

BEGIN
	SELECT COUNT(*) INTO quantitat FROM plataformes
		WHERE plataformes.nom=nomP;
	IF quantitat = 0 THEN
		RETURN 'No hi ha plataformes';
	END IF;

	SELECT jocs.nom INTO nomj
	FROM plataformes, jocs
	WHERE codiplataforma = plataformes.codi 
		AND plataformes.nom=nomP 
		ORDER BY anyllancament 
		FETCH NEXT 1 ROWS ONLY;
	RETURN nomj;

END JocMesAntic;

-- ----------------------

EXECUTE dbms_output.put_line(JocMesAntic('Playstation 3'));
