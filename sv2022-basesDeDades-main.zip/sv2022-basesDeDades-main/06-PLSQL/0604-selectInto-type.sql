-- A partir del ejercicio 601, crea una version 
--- utilizando el tipo de datos de la tabla

DECLARE
    espaiMitja jocs.espaiOcupatMb % TYPE;

BEGIN
    SELECT AVG(espaiOcupatMb)
    INTO espaiMitja
    FROM jocs;  

    dbms_output.put_line(espaiMitja);
END;
