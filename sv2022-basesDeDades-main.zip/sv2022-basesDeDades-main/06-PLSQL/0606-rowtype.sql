-- Crea un bloc PL/SQL que mostre el nom del primer joc en ordre
-- alfabètic, usant %ROWTYPE

DECLARE 
    primerJoc jocs % ROWTYPE;

BEGIN
    SELECT *
    INTO primerJoc
    FROM jocs
    ORDER BY nom ASC
    FETCH NEXT 1 ROWS ONLY;

    dbms_output.put_line(primerJoc.nom);
END;
