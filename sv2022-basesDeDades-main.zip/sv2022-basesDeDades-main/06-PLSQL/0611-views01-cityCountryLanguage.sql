-- A partir de les taules de ciutats, països, idiomes:
-- - Mostra el nom de cada ciutat, del seu país i idiomes que es parlen
-- - Filtra: ciutats d'Espanya, quantitat d'idiomes
-- - Repeteix totes dues operacions emprant una vista (VIEW)

-- -----

-- Nombre de cada ciudad, de su país e idiomas que se hablan

SELECT city.name AS cityName, 
	country.name AS countryName, 
	language
FROM city, 
	country, 
	countrylanguage
WHERE
	city.countryCode = country.code
	AND countrylanguage.countryCode = country.code;

-- Filtrar: ciudades de España, cantidad de idiomas

SELECT city.name AS cityName, 
	country.name AS countryName, 
	COUNT(language)
FROM city, 
	country, 
	countrylanguage
WHERE
	city.countryCode = country.code
	AND countrylanguage.countryCode = country.code
	AND country.name = 'Spain'
GROUP BY cityName, countryName;

-- Vista

CREATE VIEW ciudadPaisIdioma AS
	SELECT city.name AS cityName, 
		country.name AS countryName, 
		language
	FROM city, 
		country, 
		countrylanguage
	WHERE
		city.countryCode = country.code
		AND countrylanguage.countryCode = country.code;
		
SELECT * FROM ciudadPaisIdioma;

-- Filtrar: ciudades de España, cantidad de idiomas, desde vista

SELECT cityName, countryName, COUNT(*)
FROM ciudadPaisIdioma
WHERE countryName = 'Spain'
GROUP BY cityName, countryName;
