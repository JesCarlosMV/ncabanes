/*
A partir de les dades de la taula de plataformes (de jocs), crea un 
script que emplene una variable de text amb els valors "Zero", "Un", 
"Dos" o "Més de dos" segons la quantitat de jocs que tenim de la 
plataforma "ps4". Finalment, haurà de mostrar el valor d'aqueixa 
variable.
*/

DECLARE
    quantitatPS4_text VARCHAR2(30);
    quantitatPS4 NUMBER (3);
BEGIN
        SELECT COUNT(*)
        INTO quantitatPS4
        FROM jocs
        WHERE codiPlataforma = 'ps4';
    
        quantitatPS4_text := CASE quantitatPS4
            WHEN 0 THEN 'Zero'
                WHEN 1 THEN 'Un'
                WHEN 2 THEN 'Dos'
                ELSE 'Més de dos'
        END;
    
    dbms_output.put_line('Hi ha ' || quantitatPS4_text 
		|| ' joc(s) de PS4.');
END;
