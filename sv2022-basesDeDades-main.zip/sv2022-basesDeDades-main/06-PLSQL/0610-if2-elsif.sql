-- Crea una versió millorada de l'exercici anterior: a partir de les dades 
-- de la taula de jocs, crea un script que guarde en una variable la 
-- quantitat de jocs que tenim de la plataforma el codi de la qual és 
-- "ps3". En una altra variable, guarda la quantitat de jocs que tenim de 
-- la plataforma el codi de la qual és "ps4". Finalment, mostra el 
-- missatge "Tenim més jocs de PS3 que de PS4", o bé "Tenim més jocs de 
-- PS4 que de PS3", o "Tenim la mateixa quantitat de jocs de PS3 que de 
-- PS4", segons corresponga.

DECLARE
	ps3Jocs NUMBER(3);
	ps4Jocs NUMBER(3);
BEGIN 
	SELECT COUNT(*)
	INTO ps3Jocs
	FROM jocs
	WHERE codiPlataforma="ps3";
	
	SELECT COUNT(*)
	INTO ps4Jocs
	FROM jocs
	WHERE codiPlataforma="ps4";
	
	IF (ps3Jocs > ps4Jocs) THEN 
		dbms_output.put_line("Hi ha mes jocs de ps3 ");
	ELSIF (ps4Jocs > ps3Jocs) THEN 
		dbms_output.put_line("Hi ha mes jocas de ps4");
	ELSE 
		dbms_output.put_line("Te el mateix numero de jocs");
	END IF;
END;

