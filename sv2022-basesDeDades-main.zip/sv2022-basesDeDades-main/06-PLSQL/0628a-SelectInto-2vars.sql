DECLARE
	v_codi jocs.codi %TYPE;
	v_nom jocs.nom %TYPE;

BEGIN
	SELECT codi, nom
	INTO v_codi, v_nom
	FROM jocs
	WHERE codi = 'aa';

	dbms_output.put_line(v_codi || ' ' || v_nom);
END;
