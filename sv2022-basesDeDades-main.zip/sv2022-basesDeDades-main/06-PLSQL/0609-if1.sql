-- A partir de les dades de la taula de jocs, crea un script que guarde en 
-- una variable la quantitat de jocs que tenim de la plataforma el codi de 
-- la qual és "ps3". En una altra variable, guarda la quantitat de jocs 
-- que tenim de la plataforma el codi de la qual és "ps4". Finalment, 
-- mostra el missatge "Tenim més jocs de PS3 que de PS4" o bé "No tenim 
-- més jocs de PS3 que de PS4", segons corresponga

DECLARE
    v_quantitatPs3 NUMBER(3);
    v_quantitatPs4 NUMBER(3);

BEGIN
    SELECT COUNT(*)
    INTO v_quantitatPs3
    FROM jocs
    WHERE codiPlataforma = 'ps3';
   
    SELECT COUNT(*)
    INTO v_quantitatPs4
    FROM jocs
    WHERE codiPlataforma = 'ps4';
  
    IF v_quantitatPs3 > v_quantitatPs4 THEN
        dbms_output.put_line('Tenim més jocs de PS3 que de PS4');
    ELSE
        dbms_output.put_line('No tenim més jocs de PS3 que de PS4');
    END IF;
END;
