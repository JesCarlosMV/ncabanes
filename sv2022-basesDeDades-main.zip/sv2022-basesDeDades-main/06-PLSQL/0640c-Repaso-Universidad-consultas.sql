-- 2.- Muestra el nombre y los dos apellidos de los alumnos que no han 
-- dado de alta su número de teléfono en la base de datos (ejercicio 
--- 1.5.4.2).

SELECT DISTINCT nombre, apellido1, apellido2 
FROM persona, matricula
WHERE persona.id = matricula.id_alumno
AND telefono IS NULL;

-- 3.- Devuelve un listado con todas las asignaturas ofertadas en el Grado 
-- en Ingeniería Informática (Plan 2015), empleando WHERE para enlazar las 
-- tablas (ejercicio 1.5.5.2).

SELECT asignatura.nombre
FROM asignatura, grado
WHERE asignatura.id_grado = grado.id
AND grado.nombre = 'Grado en Ingeniería Informática (Plan 2015)';

-- 4.- Devuelve un listado con el nombre de las asignaturas, año de inicio 
-- y año de fin del curso escolar del alumno con nif 26902806M, empleando 
-- INNER JOIN (ejercicio 1.5.5.4).

-- Previo, con WHERE

SELECT asignatura.nombre, curso_escolar.anyo_inicio, curso_escolar.anyo_fin
FROM asignatura, curso_escolar, matricula, persona
WHERE matricula.id_asignatura = asignatura.id
  AND matricula.id_curso_escolar = curso_escolar.id
  AND matricula.id_alumno = persona.id
AND persona.nif = '26902806M';

-- Lo que se pedía, con INNER JOIN

SELECT asignatura.nombre, curso_escolar.anyo_inicio, curso_escolar.anyo_fin
FROM matricula 
  INNER JOIN curso_escolar ON matricula.id_curso_escolar = curso_escolar.id
  INNER JOIN asignatura ON matricula.id_asignatura = asignatura.id
  INNER JOIN persona ON matricula.id_alumno = persona.id
WHERE persona.nif = '26902806M';

-- 5.- Devuelve un listado con los profesores que no están asociados a un 
-- departamento, usando LEFT JOIN y COUNT (basado en el ejercicio 
-- 1.5.6.2).

-- Versión simplificada, para SQLite

-- SELECT nombre, apellido1, apellido2
-- FROM persona LEFT JOIN profesor ON persona.id = profesor.id_profesor
-- WHERE persona.tipo = 'profesor'
-- GROUP BY persona.id
-- HAVING COUNT(id_departamento) = 0;

-- Versión exhaustiva, para Oracle

SELECT persona.id, nombre, apellido1, apellido2
FROM persona LEFT JOIN profesor ON persona.id = profesor.id_profesor
WHERE persona.tipo = 'profesor'
GROUP BY persona.id, nombre, apellido1, apellido2
HAVING COUNT(id_departamento) = 0;

-- 6.- Devuelve un listado con los profesores que no están asociados a un 
-- departamento, usando IN / NOT IN (basado en el ejercicio 1.5.6.2).

SELECT nombre, apellido1, apellido2
FROM persona 
WHERE persona.tipo = 'profesor'
AND persona.id NOT IN (SELECT id_profesor FROM profesor);

-- 7.- Devuelve un listado con los profesores que no están asociados a un 
-- departamento, usando EXISTS / NOT EXISTS (basado en el ejercicio 
-- 1.5.6.2).

SELECT nombre, apellido1, apellido2
FROM persona 
WHERE persona.tipo = 'profesor'
AND NOT EXISTS 
(
    SELECT * FROM profesor 
    WHERE id_profesor = persona.id
);

-- 8.- Devuelve todos los datos del alumno más joven, usando una 
-- subconsulta con = y MAX (basado en el ejercicio 1.5.8.1).

-- Dando por sentado que la persona más joven es alumno, no profesor

SELECT * FROM persona
WHERE fecha_nacimiento =
(
    SELECT MAX(fecha_nacimiento) FROM persona
);

-- 9.- Devuelve todos los datos del alumno más joven, usando EXISTS / NOT 
-- EXISTS (basado en el ejercicio 1.5.8.1).

SELECT * FROM persona p1
WHERE NOT EXISTS
(
    SELECT fecha_nacimiento FROM persona p2
    WHERE p2.fecha_nacimiento > p1.fecha_nacimiento
);

-- 10.- Devuelve todos los datos del alumno más joven, usando ALL / ANY 
-- (basado en el ejercicio 1.5.8.1).

--No en SQLite

SELECT * FROM persona
WHERE fecha_nacimiento >= ALL
(
    SELECT fecha_nacimiento FROM persona
);

-- 11.- Crea una vista que obtenga código y nombre y apellidos de los 
-- alumnos que realmente están matriculados en algo, ordenados 
-- alfabéticamente.  El nombre y los apellidos deben aparecen como parte 
-- de un supuesto campo llamado nombreApellidos, que estará formado por el 
-- primer apellido, un espacio en blanco, el segundo apellido, una coma y 
-- un espacio en blanco, y finalmente el nombre. Comprueba que la vista 
-- parece funcionar correctamente. Luego usa esta vista para mostrar el 
-- nombre y apellidos de los alumnos que estén matriculados de alguna 
-- asignatura que contenga la palabra "Física".

CREATE VIEW alumnosMatriculados AS
    SELECT DISTINCT persona.id, apellido2 || ' ' || apellido1 || ', ' || nombre AS nombreApellidos
    FROM persona INNER JOIN matricula ON persona.id = matricula.id_alumno 
    ORDER BY nombreApellidos;

-- Prueba básica

SELECT * FROM alumnosMatriculados;

-- Y la consulta que se pedía

SELECT nombreApellidos, asignatura.nombre
FROM alumnosMatriculados LEFT JOIN matricula ON alumnosMatriculados.id = matricula.id_alumno
LEFT JOIN asignatura ON matricula.id_asignatura = asignatura.id
WHERE asignatura.nombre LIKE '%Física%';


-- 12.- Crea un procedimiento PL/SQL que muestre el nombre y el primer 
-- apellido del alumno más joven, ayudándose de dos consultas 
-- consecutivas.

CREATE OR REPLACE PROCEDURE MostrarMasJoven 
IS
    fechaMax   persona.fecha_nacimiento % TYPE;
    nombreAlu  persona.nombre % TYPE;
    apellAlu   persona.apellido1 % TYPE;

BEGIN
    SELECT MAX(fecha_nacimiento)
    INTO fechaMax
    FROM persona;   
    
    SELECT nombre, apellido1
    INTO nombreAlu, apellAlu
    FROM persona
    WHERE fecha_nacimiento = fechaMax;

    dbms_output.put_line(nombreAlu || ' ' || apellAlu);
END MostrarMasJoven;

-- Prueba de funcionamiento

EXECUTE MostrarMasJoven();


-- 13.- Crea una función PL/SQL que devuelva la cantidad de alumnos 
-- matriculados en una cierta asignatura, a partir del código de la 
-- asignatura, que se recibirá como parámetro. Comprueba que se comporta 
-- correctamente.

CREATE OR REPLACE FUNCTION CantidadAlumnosMatriculados(
        nombreAsig IN asignatura.nombre % TYPE)
    RETURN NUMBER 
IS
    nomj jocs.nom % TYPE;
    cantidad NUMBER;

BEGIN
    SELECT COUNT(*) 
        INTO cantidad
        FROM asignatura, matricula
        WHERE asignatura.id = matricula.id_asignatura
        AND asignatura.nombre = nombreAsig;
        
    RETURN cantidad;

END CantidadAlumnosMatriculados;

-- Prueba de funcionamiento

EXECUTE dbms_output.put_line(CantidadAlumnosMatriculados('Cálculo'));


-- 14.- Crea un cursor que muestre, para cada profesor, sus apellidos y su 
-- nombre, en una misma línea, empleado LOOP - EXIT WHEN.

DECLARE
    CURSOR cursorProfesores IS
        SELECT apellido2 || ' ' || apellido1 || ', ' || nombre AS nombreApellidos
        FROM persona
        WHERE tipo = 'profesor'
        ORDER BY nombreApellidos;
        
    v_nombreApellidos VARCHAR2(200);

BEGIN
    OPEN cursorProfesores;
    LOOP
        FETCH cursorProfesores INTO v_nombreApellidos;
        EXIT WHEN cursorProfesores % NOTFOUND;
        dbms_output.put_line(v_nombreApellidos);
    END LOOP;
    CLOSE cursorProfesores;
END;


-- 15.- Crea una variante del cursor anterior, empleando FOR - IN.

DECLARE
    CURSOR cursorProfesores IS
        SELECT apellido2 || ' ' || apellido1 || ', ' || nombre AS nombreApellidos
        FROM persona
        WHERE tipo = 'profesor'
        ORDER BY nombreApellidos;

BEGIN
    FOR v_registro IN cursorProfesores LOOP 
        dbms_output.put_line(v_registro.nombreApellidos);
    END LOOP;
END;
