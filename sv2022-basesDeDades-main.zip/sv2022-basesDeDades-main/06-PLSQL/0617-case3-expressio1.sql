-- Mostra la quantitat de jocs que tenim de la plataforma amb codi 
-- "ps3"... usant números romans! (d'1 a 5). Has d'emprar un script PL/SQL 
-- i la sentència CASE en format d'expressió.

DECLARE
    quantitatPS3 NUMBER (3);
    quantitatText VARCHAR2(20);

BEGIN
    SELECT COUNT(*)
    INTO quantitatPS3
    FROM jocs
    WHERE codiPlataforma = 'ps3';

    quantitatText := CASE quantitatPS3
        WHEN 0 THEN 'cap'
        WHEN 1 THEN 'I'
        WHEN 2 THEN 'II'
        WHEN 3 THEN 'III'
        WHEN 4 THEN 'IV'
        WHEN 5 THEN 'V'
        ELSE 'més de V'
    END;
    
    dbms_output.put_line('Hi ha ' || quantitatText || ' joc(s) de PS3.');
    
END;
