-- Ens han demanat crear una base de dades per a anotar programes informàtics que pertanyen a diferents categories:

-- - Taula CATEGORIA (codi, nom, codCategPare)
-- - Taula PROGRAMA (codi, nom, descripc, codCategoria)

-- Com a dades de prova pots usar (almenys) el següents:

-- INSERT INTO CATEGORIA VALUES ('so', 'Sistemes operatius', NULL);
-- INSERT INTO CATEGORIA VALUES ('soca', 'Sistemes operatius de codi obert', 'so');
-- INSERT INTO CATEGORIA VALUES ('sop', 'Sistemes operatius propietaris', 'so');

-- INSERT INTO PROGRAMA VALUES ('wi10', 'Windows 10', 'Windows 10', 'sop');
-- INSERT INTO PROGRAMA VALUES ('WP55', 'WordPerfect 5.5', NULL, NULL);

-- 1.- Crea una vista PROGRAMESICATEGORIES que permeta saber el nom de 
-- cada programa i el nom de la categoria a la qual pertany, ordenats per 
-- nom de programa i, en cas de coincidir, per nom de categoria. Afig 
-- algunes dades de prova i comprova que es comporta correctament.

CREATE TABLE Categoria ( 
    codi VARCHAR2(5) PRIMARY KEY,
    nom VARCHAR2(50),
    codCategPare VARCHAR2(5)
);

CREATE TABLE Programa (
    codi VARCHAR2(5) PRIMARY KEY,
    nom VARCHAR2(50),
    descripc VARCHAR2(50),
    codCategoria VARCHAR2(5)
);

INSERT INTO CATEGORIA VALUES ('so', 'Sistemes operatius', NULL);
INSERT INTO CATEGORIA VALUES ('soca', 'Sistemes operatius de codi obert', 'so');
INSERT INTO CATEGORIA VALUES ('sop', 'Sistemes operatius propietaris', 'so');

INSERT INTO PROGRAMA VALUES ('wi10', 'Windows 10', 'Windows 10', 'sop');
INSERT INTO PROGRAMA VALUES ('WP55', 'WordPerfect 5.5', NULL, NULL);

-- Prova prèvia

SELECT p.nom AS nomPrograma, c.nom AS nomCategoria
FROM programa p LEFT JOIN categoria c
ON codCategoria = c.codi
ORDER BY p.nom, c.nom;

-- View

CREATE VIEW ProgramesICategories AS
    SELECT p.nom AS nomPrograma, c.nom AS nomCategoria
    FROM programa p LEFT JOIN categoria c
    ON codCategoria = c.codi
    ORDER BY p.nom, c.nom;


-- 2.- Crea un procediment LlistarProgramesICategories, que, per a cada 
-- programa, mostre el seu nom i el nom de la categoria a la qual 
-- pertany(o "(Sense categoritzar)", si és el cas). Usa la vista 
-- anterior. En el teu cursor, hauràs d'emprar un bucle FOR.

-- Procedure

CREATE OR REPLACE PROCEDURE LlistarProgramesICategories AS
    CURSOR c IS
    SELECT nomPrograma, nomCategoria
    FROM ProgramesICategories;
BEGIN
    FOR programCursor IN c LOOP
        IF(programCursor.nomCategoria IS NULL) THEN
            dbms_output.put_line(programCursor.nomPrograma ||' (Sense categoritzar)');
        ELSE
            dbms_output.put_line(programCursor.nomPrograma || ' ' || programCursor.nomCategoria);
        END IF;
    END LOOP;
END LlistarProgramesICategories;

-- Prova del Procedure

BEGIN
    LlistarProgramesICategories();
END;


-- 3.- Crea un procediment anomenat LlistarCategories, que, per a cada 
-- categoria, escriga el seu codi, el seu nom i, en cas de tractar-se 
-- d'una subcategoria d'una altra (existir una categoria pare), el nom de 
-- la categoria pare (en cas contrari, no s'escriurà res). En cas de 
-- necessitar un bucle, hauràs d'emprar LOOP.

-- Prova prèvia

SELECT cSub.codi, csub.Nom, cPare.nom
FROM categoria cSub LEFT JOIN categoria cPare
ON cSub.codCategPare = cPare.codi;

-- Procediment

CREATE OR REPLACE PROCEDURE LlistarCategories IS
    CURSOR c IS
        SELECT cSub.codi, csub.Nom, cPare.nom
        FROM categoria cSub LEFT JOIN categoria cPare
        ON cSub.codCategPare = cPare.codi;
    
    v_codiSub categoria.codi % TYPE;
    v_nomSub categoria.nom % TYPE;
    v_nomPare categoria.nom % TYPE;

BEGIN
    OPEN c;
    LOOP
        FETCH c INTO v_codiSub, v_nomSub, v_nomPare;
        EXIT WHEN c % NOTFOUND;
        IF v_nomPare IS NULL THEN
            dbms_output.put_line(v_codiSub || ' ' || v_nomSub);
        ELSE
            dbms_output.put_line(v_codiSub || ' ' || v_nomSub || ' ' ||v_nomPare);
        END IF;
    END LOOP;
    CLOSE c;
END LlistarCategories;

-- Prova del procediment

BEGIN
    LlistarCategories;
END;


-- 4.- Crea una funció "QuantitatDeSubcategories", que retorne la 
-- quantitat de subcategories que existeixen per a una categoria donada, 
-- el nom de la qual s'indique com a paràmetre. Per exemple, amb les dades 
-- de prova inicials, per a "Sistemes operatius" hauria de retornar 2.

-- Prova prèvia

SELECT COUNT(cSub.codi)
FROM categoria cSub LEFT JOIN categoria cPare
ON cSub.codCategPare = cPare.codi
GROUP BY cSub.codCategPare
HAVING cSub.codCategPare = 'so';

SELECT COUNT(*)
FROM categoria
GROUP BY codCategPare
HAVING codCategPare = 'so';

-- Funció

CREATE OR REPLACE FUNCTION QuantitatDeSubcategories 
    (v_nom categoria.nom%TYPE) RETURN NUMBER 
IS
    v_quantitatSub NUMBER(10);
BEGIN

    SELECT COUNT(cSub.codi)
    INTO v_quantitatSub
    FROM categoria cSub LEFT JOIN categoria cPare
    ON cSub.codCategPare = cPare.codi
    GROUP BY cSub.codCategPare
    HAVING cSub.codCategPare = v_nom;
    
    RETURN v_quantitatSub;
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN 
            RETURN 0;
END QuantitatDeSubcategories;

BEGIN
    dbms_output.put_line(QuantitatDeSubcategories('so'));
END;


-- 5.- Crea una funció "QuantitatDeProgrames", que, a partir d'un codi de 
-- categoria (per exemple, "sop"), retorne la quantitat de programes que 
-- tenim d'aqueixa categoria (sense comptar les seues subcategories), en 
-- format un text dels següents textos: "Cap", "Un", "Entre 2 i 5" o "Més 
-- de 5", Has d'emprar CASE.

-- Prova prèvia

SELECT COUNT(*)
FROM categoria RIGHT JOIN programa
ON codCategoria = categoria.codi
WHERE categoria.codi = 'sop';

-- Funció

CREATE OR REPLACE FUNCTION QuantitatDeProgrames
    (v_codi categoria.codi%TYPE) RETURN VARCHAR2 IS
    
    v_quantitat NUMBER(5);
BEGIN
    SELECT COUNT(*)
    INTO v_quantitat
    FROM categoria RIGHT JOIN programa
    ON codCategoria = categoria.codi
    WHERE categoria.codi = v_codi;
    
    RETURN CASE v_quantitat
        WHEN 0 THEN 'Cap'
        WHEN 1 THEN 'Un'
        WHEN 2 THEN 'Entre 2 i 5'
        WHEN 3 THEN 'Entre 2 i 5'
        WHEN 4 THEN 'Entre 2 i 5'
        WHEN 5 THEN 'Entre 2 i 5'
        ELSE 'Mes de 5'
    END;
END QuantitatDeProgrames;

/* Alternativa:

    CASE
        WHEN v_quantitat = 0 THEN
            RETURN 'Cap';
        WHEN v_quantitat = 1 THEN
            RETURN 'Un';
        WHEN v_quantitat >= 2 AND v_quantitat <= 5 THEN 
            RETURN 'Entre 2 i 5';
        ELSE
            RETURN 'Mes de 5';
    END CASE;
*/

-- Prova

BEGIN
    dbms_output.put_line(QuantitatDeProgrames('sop'));
END;

-- 6.- Crea un TRIGGER anomenat "CompletarPrograma" que, quan s'inserisca 
-- un programa, si la descripció està buida, bolque en ella el mateix text 
-- que s'havia introduït per al nom.

CREATE OR REPLACE TRIGGER CompletarPrograma
BEFORE INSERT ON programa
FOR EACH ROW
BEGIN
    IF :NEW.descripc IS NULL THEN
        :NEW.descripc := :NEW.nom;
    END IF;
END CompletarPrograma;

-- -------

Nos han pedido crear una base de datos para anotar programas informáticos que pertenecen a distintas categorías:

- Tabla CATEGORIA (código, nombre, codCategPadre)
- Tabla PROGRAMA (código, nombre, descripc, codCategoria)

Como datos de prueba puedes usar (al menos) lo siguientes:

INSERT INTO CATEGORIA VALUES ('so', 'Sistemas operativos', NULL);
INSERT INTO CATEGORIA VALUES ('soca', 'Sistemas operativos de código abierto', 'so');
INSERT INTO CATEGORIA VALUES ('sop', 'Sistemas operativos propietarios', 'so');

INSERT INTO PROGRAMA VALUES ('wi10', 'Windows 10', 'Windows 10', 'sop');
INSERT INTO PROGRAMA VALUES ('WP55', 'WordPerfect 5.5', NULL, NULL);

1.- Crea una vista PROGRAMASYCATEGORIAS que permita saber el nombre de cada programa y el nombre de la categoría a la que pertenece, ordenados por nombre de programa y, en caso de coincidir, por nombre de categoría. Añade algunos datos de prueba y comprueba que se comporta correctamente.

2.- Crea un procedimiento ListarProgramasYCategorias, que, para cada programa, muestre su nombre y el nombre de la categoría a la que pertenece (o "(Sin categorizar)", si es el caso). Apóyate en la vista anterior. En tu cursor, deberás emplear un bucle FOR.

3.- Crea un procedimiento llamado ListarCategorias, que, para cada categoría, escriba su código, su nombre y, en caso de tratarse de una subcategoría de otra (existir una categoría padre), el nombre de la categoría padre (en caso contrario, no se escribirá nada). En caso de necesitar un bucle, deberás emplear LOOP.

4.- Crea una función "CantidadDeSubcategorias", que devuelva la cantidad de subcategorías que existen para una categoría dada, cuyo nombre se indique como parámetro. Por ejemplo, con los datos de prueba iniciales, para "Sistemas operativos" debería devolver 2.

5.- Crea una función "CantidadDeProgramas", que, a partir de un código de categoría (por ejemplo, "sop"), devuelva la cantidad de programas que tenemos de esa categoría (sin contar sus subcategorías), en formato uno texto de los siguientes textos:  "Ninguno", "Uno", "Entre 2 y 5" o "Más de 5", Debes emplear CASE.

6.- Crea un TRIGGER llamado "CompletarPrograma" que, cuando se inserte un programa, si la descripción está vacía, vuelque en ella el mismo texto que se había introducido para el nombre.

