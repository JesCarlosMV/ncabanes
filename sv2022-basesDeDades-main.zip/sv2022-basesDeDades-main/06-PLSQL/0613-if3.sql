-- Crea un script PL/SQL que escriga en pantalla "Tenim més plataformes 
-- amb jocs que plataformes sense jocs", o bé "Tenim més plataformes sense 
-- jocs que plataformes amb jocs", segons corresponga.

DECLARE
    quantitatPlataformes NUMBER(5);
    quantitatPlataformesAmbJocs NUMBER(5);
    quantitatPlataformesSenseJocs NUMBER(5);

BEGIN
    SELECT COUNT(*)
    INTO quantitatPlataformes
    FROM plataformes;
   
    SELECT COUNT(DISTINCT codiPlataforma)
    INTO quantitatPlataformesAmbJocs
    FROM jocs
    WHERE codiPlataforma IS NOT NULL;
    
    quantitatPlataformesSenseJocs := 
		quantitatPlataformes - quantitatPlataformesAmbJocs;
  
    IF quantitatPlataformesSenseJocs > quantitatPlataformesAmbJocs THEN
        dbms_output.put_line('Tenim més plataformes sense jocs que plataformes amb jocs');
    ELSE
        dbms_output.put_line('Tenim més plataformes amb jocs que plataformes sense jocs');
    END IF;
END;
