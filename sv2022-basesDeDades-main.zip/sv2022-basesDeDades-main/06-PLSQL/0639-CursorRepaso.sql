-- Usando un cursor, muestra el nombre de cada plataforma y el nombre de
-- juego que menos ocupa para ella.

-- Puedes emplear WHILE, LOOP, FOR... o probar las tres estructuras.

DECLARE
    v_reg_plataforma plataformes % ROWTYPE;

    CURSOR jocs_cursor IS
        SELECT plataformes.nom AS nomPlataforma, j.nom AS nomJoc
        FROM plataformes, jocs j
        WHERE j.codiPlataforma = plataformes.codi
        AND j.espaiOcupatMb = (
            SELECT MIN(espaiOcupatMb)
            FROM jocs j2
            WHERE j.codiPlataforma = j2.codiPlataforma
        );
BEGIN
    FOR v_reg_plataforma IN jocs_cursor
    LOOP
        dbms_output.put_line(v_reg_plataforma.nomPlataforma
            || ' - ' || v_reg_plataforma.nomJoc);
    END LOOP;
END;

