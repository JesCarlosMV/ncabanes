-- Crea una vista llamada "registros5letras", que permita consultar de 
-- forma rápida el código y el nombre de los registros de la tabla 
-- anterior, para aquellos que tienen una longitud de exactamente 5 
-- letras, ordenados alfabéticamente.

CREATE VIEW registros5letras AS
	SELECT codigo, nombre
	FROM registro
	WHERE LENGTH(nombre) = 5
	ORDER BY nombre;

-- A partir de la vista llamada "registros5letras", obtén los nombres de 
-- los registros cuyo nombre tiene 5 letras y que empiezan por A (quizá en 
-- minúsculas), ordenados alfabéticamente.

SELECT nombre
FROM registros5letras
WHERE LOWER(nombre) LIKE 'a%';
