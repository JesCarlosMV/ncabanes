-- Afig, des de PL/SQL, una nova plataforma de jocs, el codi 
-- de la qual serà "nds" i el nom de la qual serà "Nintendo DS".

DECLARE
    v_codi plataformes.codi % TYPE := 'nds';
    v_nom plataformes.nom % TYPE := 'Nintendo DS';

BEGIN 
    INSERT INTO plataformes (codi,nom) VALUES (v_codi,v_nom);
END;
