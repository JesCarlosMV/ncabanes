/* Crea un script PL/SQL que empre cursors per a obtindre la següent informació 
a partir de la nostra base de dades de jocs i plataformes: per a cada joc de la 
base de dades, mostra el seu nom (ordenats alfabèticament) i, al seu costat, el 
nom de la plataforma a la qual pertany. Si el nom d'algun joc està repetit 
(coincideix amb l'anterior), escriuràs quatre espais en blanc en comptes 
d'aquest nom. Usa un bucle FOR. */

DECLARE
    CURSOR cursorJocsPlataformes IS
        SELECT j.nom, p.nom as plataf
        FROM jocs j INNER JOIN plataformes p
        ON p.codi = codiPlataforma
        ORDER BY j.nom;
    v_nomJocAnterior jocs.nom % TYPE := '(Ninguno)';

BEGIN
    FOR joc in cursorJocsPlataformes LOOP
        IF v_nomJocAnterior = joc.nom THEN
            dbms_output.put_line('     - ' || joc.plataf);
        ELSE
            dbms_output.put_line(joc.nom || ' -' || joc.plataf);
        END IF;
        v_nomJocAnterior := joc.nom;
    END LOOP;
END;
