DECLARE
	v_joc jocs % ROWTYPE;

BEGIN
	SELECT *
	INTO v_joc
	FROM jocs
	WHERE codi = 'aa';

	dbms_output.put_line(v_joc.codi || ' ' || v_joc.nom);
END;
