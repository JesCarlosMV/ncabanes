DECLARE
    v_nomMesGran VARCHAR2(50);
    v_espaiMax NUMBER(9,3);

BEGIN
    SELECT MAX(espaiOcupatMb) INTO v_espaiMax FROM jocs;
    
    SELECT nom INTO v_nomMesGran FROM jocs
    WHERE espaiOcupatMb = v_espaiMax;
    
    dbms_output.put_line(v_nomMesGran);
END;
