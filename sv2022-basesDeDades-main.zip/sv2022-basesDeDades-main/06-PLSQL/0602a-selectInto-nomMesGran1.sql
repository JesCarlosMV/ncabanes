DECLARE
    nomMesGran VARCHAR2(50);

BEGIN
    SELECT nom
    INTO nomMesGran
    FROM jocs
    WHERE espaiOcupatMb = (SELECT MAX(espaiOcupatMb) FROM jocs);
    
    dbms_output.put_line(nomMesGran);
END;
