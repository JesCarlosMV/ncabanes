/*
A partir de les taules de jocs i plataformes:

- Crea una vista (VIEW), que permet obtindre totes les dades que 
estigues relacionats.

- Usa aqueixa vista per a obtindre, de cada joc, el seu nom, el seu 
codi i el nom de plataforma a la qual pertany.

- Mostra els noms de les plataformes per a les quals tenim més d'un joc.
*/

CREATE VIEW jocsPlataf AS 
    SELECT jocs.codi AS codiJoc, jocs.nom AS nomJoc, 
        jocs.descripcio, jocs.anyLlancament, 
        jocs.espaiOcupatMb, jocs.codiPlataforma, 
        plataformes.nom AS nomPlataforma
    FROM jocs, plataformes
    WHERE plataformes.codi = jocs.codiPlataforma;


SELECT nomJoc, codiJoc, nomPlataforma
FROM jocsPlataf;

SELECT nomPlataforma
FROM jocsPlataf
GROUP BY nomPlataforma
HAVING COUNT(*) > 1;
