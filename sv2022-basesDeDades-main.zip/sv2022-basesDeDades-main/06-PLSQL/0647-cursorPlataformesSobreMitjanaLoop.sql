/* Crea un script PL/SQL que empre cursors per a obtindre la següent 
informació a partir de la nostra base de dades de jocs i plataformes: 
mostra el nom de les plataformes per a les quals tenim més jocs que la 
mitjana, així com quants jocs més que la mitjana tenim per a ella. 
Fes-ho amb dues consultes encadenades i emprant un bucle LOOP, 
juntament amb la clàusula EXIT */

DECLARE
    CURSOR c IS
        SELECT p.nom, COUNT(codiPlataforma)
        FROM plataformes p LEFT JOIN jocs j
        ON p.codi = codiPlataforma
        GROUP BY p.nom
        ORDER BY nom;
    
    v_nomPlataforma plataformes.nom%TYPE;
    v_quantitatEstaPlat NUMBER;
    
    v_quantitatJocs NUMBER;
    v_quantitatPlataformes NUMBER;
    v_mitjana NUMBER;

BEGIN
    SELECT COUNT(*) INTO v_quantitatJocs FROM jocs;
    SELECT COUNT(*) INTO v_quantitatPlataformes FROM plataformes;
    v_mitjana := v_quantitatJocs / v_quantitatPlataformes;
    -- dbms_output.put_line(' Mitjana: ' ||  v_mitjana);
    
    OPEN c;
    LOOP
        FETCH c INTO v_nomPlataforma, v_quantitatEstaPlat;
        EXIT WHEN c % NOTFOUND;
        -- dbms_output.put_line(v_nomPlataforma || ' - '  || v_quantitatEstaPlat );
        IF v_quantitatEstaPlat > v_mitjana THEN
            dbms_output.put_line(v_nomPlataforma || ': ' 
                || (v_quantitatEstaPlat - v_mitjana));
        END IF;
        FETCH c INTO v_nomPlataforma, v_quantitatEstaPlat;
    END LOOP;
    CLOSE c;
END;
