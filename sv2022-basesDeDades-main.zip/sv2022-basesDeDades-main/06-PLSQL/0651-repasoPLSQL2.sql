-- Exercici 6.51: Repaso 2 de PL/SQL y cursores

-- 1.- Crea una sentencia SELECT que obtenga (y muestre) los años en los 
-- que tenemos algún juego (sin duplicados).

SELECT DISTINCT anyLlancament 
FROM jocs 
WHERE anyLlancament IS NOT NULL
ORDER BY anyLlancament;


-- 2.- Crea una sentencia SELECT que obtenga (y muestre) los años en los 
-- que tenemos juegos, junto con la cantidad de juegos que tenemos de cada 
-- año.

SELECT anyLlancament, COUNT(*)
FROM jocs 
WHERE anyLlancament IS NOT NULL
GROUP BY anyLlancament
ORDER BY anyLlancament;


-- 3.- Crea un script PL/SQL que use una SELECT para obtener el año del 
-- juego más antiguo que tenemos en nuestra base de datos, lo guarde en 
-- una variable llamada "v_anyPrimerJoc" y muestre el valor de esa 
-- variable.

DECLARE
    v_anyPrimerJoc jocs.anyLlancament%TYPE;
    
BEGIN
    SELECT anyLlancament
    INTO v_anyPrimerJoc
    FROM jocs 
    WHERE anyLlancament IS NOT NULL
    ORDER BY anyLlancament ASC
    FETCH NEXT 1 ROWS ONLY;
    
    dbms_output.put_line(v_anyPrimerJoc);
    
END;


-- 4.- Crea un script PL/SQL que contenga un bloque anónimo, que utilice 
-- un cursor y un bucle LOOP para mostrar los años en los que tenemos 
-- juegos, junto con la cantidad de juegos que tenemos de cada año.

DECLARE CURSOR CursorAny IS

    SELECT anyLlancament,COUNT(*)
    FROM jocs 
    WHERE anyLlancament IS NOT NULL
    AND anyLlancament > 0
    GROUP BY anyLlancament
    ORDER BY anyLlancament;
    
    v_quantitatAnys NUMBER;
    v_anys jocs.anyLlancament % TYPE;
BEGIN 
    OPEN CursorAny;
    LOOP
        FETCH CursorAny INTO v_anys, v_quantitatAnys;
        EXIT WHEN CursorAny % NOTFOUND;
        dbms_output.put_line(v_anys|| ' - ' || v_quantitatAnys);
    END LOOP;
    CLOSE CursorAny;
END;


-- 5.- Crea un script PL/SQL que contenga un bloque anónimo, que utilice 
-- un cursor y un bucle LOOP para mostrar los años en los que tenemos 
-- juegos, junto con la cantidad de juegos que tenemos de cada año. Si 
-- sólo hay un juego, en vez de escribir el número, escribirá "Solo uno". 
-- En caso contrario, escribirá el número.

DECLARE CURSOR CursorAny IS

    SELECT anyLlancament,COUNT(*)
    FROM jocs 
    WHERE anyLlancament IS NOT NULL
    AND anyLlancament > 0
    GROUP BY anyLlancament
    ORDER BY anyLlancament;
    
    v_quantitatAnys NUMBER;
    v_anys jocs.anyLlancament % TYPE;
BEGIN 
    OPEN CursorAny;
    LOOP
        FETCH CursorAny INTO v_anys, v_quantitatAnys;
        EXIT WHEN CursorAny % NOTFOUND;
        IF v_quantitatAnys = 1 THEN
            dbms_output.put_line(v_anys|| ' - ' || 'Solo uno');
        ELSE
            dbms_output.put_line(v_anys|| ' - ' || v_quantitatAnys);
        END IF;
    END LOOP;
    CLOSE CursorAny;
END;


-- 6.- Crea una variante del ejercicio anterior usando WHILE.

DECLARE CURSOR CursorAny IS

    SELECT anyLlancament,COUNT(*)
    FROM jocs 
    WHERE anyLlancament IS NOT NULL
    AND anyLlancament > 0
    GROUP BY anyLlancament
    ORDER BY anyLlancament;
    
    v_quantitatAnys NUMBER;
    v_anys jocs.anyLlancament % TYPE;

BEGIN 
    OPEN CursorAny;
    FETCH CursorAny INTO v_anys, v_quantitatAnys;
    WHILE CursorAny % FOUND LOOP
        IF v_quantitatAnys = 1 THEN
            dbms_output.put_line(v_anys|| ' -  Solo uno');
        ELSE
            dbms_output.put_line(v_anys|| ' - ' || v_quantitatAnys);
        END IF;
        FETCH CursorAny INTO v_anys, v_quantitatAnys;
    END LOOP;
    CLOSE CursorAny;
END;


-- 7.- Crea una variante del ejercicio anterior usando FOR.

DECLARE CURSOR CursorAny IS

    SELECT anyLlancament,COUNT(*) AS quantitat
    FROM jocs 
    WHERE anyLlancament IS NOT NULL
    AND anyLlancament > 0
    GROUP BY anyLlancament
    ORDER BY anyLlancament;

BEGIN 
    FOR joc in CursorAny LOOP
        IF joc.quantitat = 1 THEN
            dbms_output.put_line(joc.anyLlancament 
                || ' - Solo uno');
        ELSE
            dbms_output.put_line(joc.anyLlancament
                || ' - ' || joc.quantitat);
        END IF;
    END LOOP;
END;


-- 8- Crea un script PL/SQL que muestre todos los años desde 1980 hasta 
-- 2020, junto con la cantidad de juegos que tenemos en ese año (quizá 0).

DECLARE
    quantitat NUMBER;

BEGIN
    FOR anyJoc IN 1980..2020 LOOP
    
        SELECT COUNT(*)
        INTO quantitat
        FROM jocs
        WHERE anyLlancament = anyJoc;
        
        dbms_output.put_line(anyJoc || ': ' || quantitat);
    END LOOP;
END;

-- 9.- Crea un función llamada "QuantitatDeJocsPerAny", que devuelva la 
-- cantidad de juegos que tenemos de un cierto año que se indique como 
-- parámetro. Pruébala desde un bloque anónimo de PL/SQL.

CREATE OR REPLACE FUNCTION QuantitatDeJocsPerAny(anyJoc IN NUMBER)
RETURN NUMBER
AS
    quantitat NUMBER;

BEGIN 
    SELECT COUNT(*)
        INTO quantitat
        FROM jocs
        WHERE anyLlancament = anyJoc;

    RETURN quantitat;

END QuantitatDeJocsPerAny;

-- Prueba 1

EXECUTE dbms_output.put_line(QuantitatDeJocsPerAny(2017));

-- Prueba 2

BEGIN
    dbms_output.put_line(QuantitatDeJocsPerAny(2019));
END;


-- 10.- Crea una tabla BackupJocs, que contenga sólo los campos codi, nom. 
-- codiPlataforma. Crea un procedimiento llamado "FerBackupJocs", que 
-- reciba como parámetro un código de plataforma, y que vuelque de la 
-- tabla "jocs" a la tablaBackupJocs los juegos que sean de esa 
-- plataforma.

-- Prueba, sin clave primaria ni ajerna, permitirá duplicados

CREATE TABLE backupJocs(
    codi CHAR(5), 
    nom VARCHAR2(50), 
    codiPlataforma CHAR(4)
);

-- Ejemplo con cursores

CREATE OR REPLACE PROCEDURE FerBackupJocs(v_plat IN jocs.codiPlataforma%TYPE) 
AS
    CURSOR jocs_cursor IS
    SELECT codi, nom, codiPlataforma
    FROM jocs
    WHERE codiPlataforma = v_plat
    ORDER BY nom;
    
BEGIN 
    FOR joc IN jocs_cursor LOOP
        INSERT INTO backupJocs VALUES(joc.codi, joc.nom, joc.codiPlataforma);  
    END LOOP;
END FerBackupJocs;

-- Prueba

EXECUTE FerBackupJocs('cpc');

SELECT * FROM backupJocs;


-- 11.- Crea una nueva versión de la función "ObtindreAny", que devuelva 
-- el año de lanzamiento en un cierto juego, cuyo nombre se indicará como 
-- parámetro. Si el juego no existe, devolverás el valor -1. Prueba la 
-- función desde un bloque anónimo de PL/SQL. Esta versión debe emplear un 
-- único SELECT y control de excepciones.

CREATE OR REPLACE FUNCTION ObtindreAny(v_nom IN jocs.nom%TYPE)
RETURN NUMBER
AS
    anyJoc NUMBER;

BEGIN 
    SELECT anyLlancament
        INTO anyJoc
        FROM jocs
        WHERE nom = v_nom
        FETCH FIRST 1 ROWS ONLY;

    RETURN anyJoc;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN -1;

END ObtindreAny;

-- Prueba 1 (un dato)

EXECUTE dbms_output.put_line(ObtindreAny('Fortnite'));

-- Prueba 2 (más de un dato, se toma el primero)

EXECUTE dbms_output.put_line(ObtindreAny('Manic Miner'));

-- Prueba 3 (ningún dato, salta excepción)

EXECUTE dbms_output.put_line(ObtindreAny('Super Mario Galaxy'));

