/* Crea un script PL/SQL similar a l'anterior (nom de cada plataforma i 
quantitat de jocs o, si és zero, la paraula "Cap"), però en aquesta 
ocasió hauràs d'utilitzar un bucle LOOP, juntament amb la clàusula EXIT 
*/

DECLARE
    CURSOR jocs_cursor IS
        SELECT p.nom, COUNT(codiPlataforma)
        FROM plataformes p LEFT JOIN jocs j
        ON p.codi = codiPlataforma
        GROUP BY p.nom
        ORDER BY nom;

    v_nomPlataforma plataformes.nom%TYPE;
    v_quantitat NUMBER;

BEGIN
    OPEN jocs_cursor;

    LOOP
        FETCH jocs_cursor INTO v_nomPlataforma, v_quantitat;

        EXIT WHEN jocs_cursor % NOTFOUND;

        IF v_quantitat = 0 THEN
            dbms_output.put_line(v_nomPlataforma || ' - Cap');
        ELSE
            dbms_output.put_line(v_nomPlataforma || ' - ' || v_quantitat);
        END IF;

    END LOOP;
    CLOSE jocs_cursor;
END;
