/*
Crea un procediment "InserirJoc", que afija un nou joc a la base de 
dades. Rebrà com a paràmetres el codi del joc, el nom del joc i el codi 
de la plataforma. Si la plataforma no existeix, es limitarà a escriure 
l'avís de "No existeix aqueixa plataforma", i si existeix, guardarà el 
joc i avisarà "Joc guardat correctament".
*/

CREATE OR REPLACE PROCEDURE InserirJoc(
    codiJoc IN CHAR, 
    nomJoc IN VARCHAR2, 
    codiPlataformaJoc IN CHAR) 
IS
    quantitat NUMBER(1);

BEGIN
    SELECT COUNT(*)
    INTO quantitat
    FROM plataformes
    WHERE codi = codiPlataformaJoc;   

    IF quantitat > 0 THEN
        INSERT INTO jocs (codi,nom,codiPlataforma)
            VALUES (codiJoc,nomJoc,codiPlataformaJoc);
        dbms_output.put_line('Joc guardat correctament');
    ELSE
        dbms_output.put_line('No existeix aqueixa plataforma');
    END IF;
END InserirJoc;

-- Ús (que fallarà: no existeix la plataforma)

EXECUTE InserirJoc('jsw', 'Jet Set Willy', 'acpc');

-- Ús (que hauria de funcionar correctament)

EXECUTE InserirJoc('jsw', 'Jet Set Willy', 'cpc');

-- Per a comprovar que ha funcionat

SELECT * FROM jocs WHERE nom LIKE 'J%';
