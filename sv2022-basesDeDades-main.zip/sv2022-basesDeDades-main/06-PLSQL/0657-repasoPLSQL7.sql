-- A partir de estas tablas y de estos datos de ejemplo:

CREATE TABLE productos (
  codigo VARCHAR(6) PRIMARY KEY,
  nombre VARCHAR(30),
  precioCoste NUMBER(7,2)
);

CREATE TABLE categoriasProd (
  codigo VARCHAR(4) PRIMARY KEY,
  nombre VARCHAR(30)
);

CREATE TABLE perteneceA (
  codigoProd VARCHAR(6),
  codigoCateg VARCHAR(4),
  PRIMARY KEY (codigoProd, codigoCateg)
);

INSERT INTO productos VALUES ('p1','Producto 1', 23);
INSERT INTO productos VALUES ('p2','Producto 2', 32.5);
INSERT INTO productos VALUES ('p3','Producto 3', NULL);

INSERT INTO categoriasProd VALUES ('c1','Categoría 1');
INSERT INTO categoriasProd VALUES ('c2','Categoría 2');
INSERT INTO categoriasProd VALUES ('c3','Categoría 3');

INSERT INTO perteneceA VALUES ('p1','c1');
INSERT INTO perteneceA VALUES ('p1','c2');
INSERT INTO perteneceA VALUES ('p2','c2');

-- 1.- Crea una vista "prodCateg" que muestre código y nombre de todos los 
-- productos, así como código y nombre de las categorías a que pertenecen, 
-- en caso de que pertenezcan a alguno.

CREATE VIEW prodCateg AS 
    SELECT productos.codigo as codiproducto, 
        productos.nombre as nombreProducto, 
        categoriasProd.codigo as codiCategoria, 
        categoriasProd.nombre as nombreCategoria 
    FROM productos 
        LEFT JOIN perteneceA ON perteneceA.codigoProd = productos.codigo 
        LEFT JOIN categoriasProd on perteneceA.codigoCateg = categoriasProd.codigo;
        
-- Prova

SELECT * FROM prodCateg;

-- 2.- Crea una función "CantidadProdCategoria", que reciba como parámetro 
-- el nombre de un categoría y devuelva la cantidad de productos que hay 
-- en esa categoría, o -1 en caso de que la categoría no exista.

-- Prova prèvia 1: per categories

SELECT c.nombre, COUNT(*)
FROM categoriasProd c 
    LEFT JOIN perteneceA ON codigoCateg = c.codigo
    LEFT JOIN productos p ON codigoProd = p.codigo
GROUP BY c.nombre;

-- Prova prèvia 2: una categoria

SELECT COUNT(p.codigo)
FROM categoriasProd c 
    LEFT JOIN perteneceA ON codigoCateg = c.codigo
    LEFT JOIN productos p ON codigoProd = p.codigo
WHERE c.nombre = 'Categoría 1';

-- Prova prèvia 3: una categoria que no existeix
-- (retorna 0, en comptes de no retornar registres)

SELECT COUNT(p.codigo)
FROM categoriasProd c 
    LEFT JOIN perteneceA ON codigoCateg = c.codigo
    LEFT JOIN productos p ON codigoProd = p.codigo
WHERE c.nombre = 'Categoría 7';

-- Funció

CREATE OR REPLACE FUNCTION CantidadProdCategoria (v_nomCateg VARCHAR) 
RETURN NUMBER 
IS

    v_cantidad NUMBER(5);

BEGIN

    SELECT COUNT(*)
    INTO v_cantidad
    FROM categoriasProd c 
    WHERE c.nombre = v_nomCateg;

    IF v_cantidad = 0 THEN
        RETURN -1;
    END IF;

    SELECT COUNT(p.codigo)
    INTO v_cantidad
    FROM categoriasProd c 
        LEFT JOIN perteneceA ON codigoCateg = c.codigo
        LEFT JOIN productos p ON codigoProd = p.codigo
    WHERE c.nombre = v_nomCateg;

    RETURN v_cantidad;
END CantidadProdCategoria;

-- Prova 1: Categoria existent

BEGIN
    dbms_output.put_line(CantidadProdCategoria('Categoría 2'));
END;

-- Prova 2: Categoria inexistent

EXECUTE dbms_output.put_line(CantidadProdCategoria('Categoria 7'));


-- 3.- Crea un procedimiento "MostrarProdCategoria", que, a partir del 
-- nombre de una categoría que recibirá como parámetros, muestre todos los 
-- códigos y nombres de los productos que pertenecen a esa categoría, o el 
-- mensaje "Categoría inexistente", según corresponda. Usa un bucle FOR.

CREATE OR REPLACE PROCEDURE MostrarProdCategoria (v_nomCateg VARCHAR) 
IS
    CURSOR c IS 
        SELECT p.codigo AS codiProducto, p.nombre AS nombreProducto
        FROM productos p, categoriasProd c, perteneceA
        WHERE p.codigo = codigoProd
        AND c.codigo = codigoCateg
        AND c.nombre = v_nomCateg;
    v_cantidad NUMBER(5);
BEGIN
    SELECT COUNT(*)
    INTO v_cantidad
    FROM categoriasProd c 
    WHERE c.nombre = v_nomCateg;

    IF v_cantidad = 0 THEN
        dbms_output.put_line('Categoría inexistente');
        RETURN;
    END IF;
    
    FOR prodCursor IN c LOOP
        dbms_output.put_line(prodCursor.codiProducto 
            || ' ' || prodCursor.nombreProducto);
    END LOOP;;
END MostrarProdCategoria;

-- Prova amb categoria existent

BEGIN
    MostrarProdCategoria('Categoría 2');
END;

-- Prova amb categoria inexistent

BEGIN
    MostrarProdCategoria('Categoría 7');
END;


-- 4.- Crea un procedimiento "MostrarProdsRapido", que use una orden 
-- "case" para mostrar cada producto junto al nombre de la categoría a la 
-- que pertenece, sin consultar la tabla "categorías", mirando sólo 
-- "productos" y "perteneceA". Si un producto está en varias categorías, 
-- aparecerán varias líneas que comiencen por su nombre.

CREATE OR REPLACE PROCEDURE MostrarProdsRapido IS
    CURSOR c IS
        SELECT productos.nombre AS nombreProducto, 
            perteneceA.codigoCateg AS categoria
        FROM productos, perteneceA
        WHERE codigo = codigoProd;
BEGIN
    FOR categCursor IN c LOOP
        CASE categCursor.categoria
            WHEN 'c1' THEN
                dbms_output.put_line(categCursor.nombreProducto || ' Categoría 1');
            WHEN 'c2' THEN
                dbms_output.put_line(categCursor.nombreProducto || ' Categoría 2');
            WHEN 'c3' THEN 
                dbms_output.put_line(categCursor.nombreProducto || ' Categoría 3');
        END CASE;
    END LOOP;
END MostrarProdsRapido;

EXECUTE MostrarProdsRapido;


-- 5.- Crea una tabla auxiliar "productosBorrados" (sin clave primaria) y 
-- un trigger "BorrandoProducto", que permitan que, cada vez que se borre 
-- un producto, sus datos se guarden en una tabla auxiliar, junto con la 
-- fecha en que se ha borrado.

CREATE TABLE productosBorrados(
    codigo VARCHAR(6),
    nombre VARCHAR(30),
    precioCoste NUMBER(7,2),
    fechaBorrado DATE
);
    
CREATE OR REPLACE TRIGGER BorrandoProducto
BEFORE DELETE ON productos
FOR EACH ROW
BEGIN
    INSERT INTO productosBorrados 
    VALUES(:OLD.codigo, :OLD.nombre, :OLD.precioCoste, SYS_DATE);
END;
