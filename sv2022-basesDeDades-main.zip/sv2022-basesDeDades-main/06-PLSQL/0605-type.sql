-- Crea un bloc PL/SQL que mostre el nom del primer joc en ordre
-- alfabètic, usant %TYPE

DECLARE 
    primerJoc jocs.nom%TYPE;

BEGIN
    SELECT nom
    INTO primerJoc
    FROM jocs
    ORDER BY nom ASC
    FETCH NEXT 1 ROWS ONLY;

    dbms_output.put_line(primerJoc);
END;
