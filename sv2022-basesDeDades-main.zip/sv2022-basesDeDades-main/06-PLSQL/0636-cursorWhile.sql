/* Crea un script PL/SQL que empre cursors per a obtindre la següent 
informació a partir de la nostra base de dades de jocs i plataformes: 
per a cadascuna de les plataformes, es mostrarà el seu nom i la 
quantitat de jocs que tenim emmagatzemats. En cas que aqueixa quantitat 
siga 0 per a alguna plataforma, no es mostrarà el número 0, sinó el 
text "Cap". Usa un bucle WHILE, com en l'exemple. */

DECLARE
    CURSOR jocs_cursor IS
        SELECT p.nom, COUNT(codiPlataforma)
        FROM plataformes p LEFT JOIN jocs j
        ON p.codi = codiPlataforma
        GROUP BY p.nom
        ORDER BY nom;

    v_nomPlataforma plataformes.nom%TYPE;
    v_quantitat NUMBER;

BEGIN
    OPEN jocs_cursor;

    FETCH jocs_cursor INTO v_nomPlataforma, v_quantitat;
    WHILE jocs_cursor % FOUND LOOP

        IF v_quantitat = 0 THEN
            dbms_output.put_line(v_nomPlataforma || ' - Cap');
        ELSE
            dbms_output.put_line(v_nomPlataforma || ' - ' || v_quantitat);
        END IF;
        FETCH jocs_cursor INTO v_nomPlataforma, v_quantitat;

    END LOOP;

    CLOSE jocs_cursor;
END;
