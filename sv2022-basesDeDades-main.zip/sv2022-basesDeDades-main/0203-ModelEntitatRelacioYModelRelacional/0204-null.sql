INSERT INTO mascotas3 VALUES (3, "Daisy", "");  -- Poco razonable

INSERT INTO mascotas3 VALUES (4, "Thor", NULL); -- NULL en vez de un valor
INSERT INTO mascotas3 (codigo, nombre) VALUES (5, "Nieve"); -- Sólo algunos campos
INSERT INTO mascotas3 (nombre, codigo) VALUES ("Golfo", 6); -- Orden cambiado
