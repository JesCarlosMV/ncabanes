
REPARACIONS

CLIENT(codi, nom, CarrerPis, ciutat)
CP: codi

TELEFON(codi_client, nombre)
CP: codi_client, nombre
CAj: codi_client --> client

EQUIP(codi_client, num, descripcio)
CP: codi_client, num
CAj: codi_client --> client

ELEMENT(codi, nom, codi_client, num_equip)
CP: codi
CAj: codi_client, num_equip --> equip
VNN: codi_client, num_equip

COMPONENT(codi_element, marca, model, codi_client, num_equip)
CP: codi_element
CAj: codi_element --> element
CAj: codi_client, num_equip --> equip

MA_D_OBRA(codi_element, tipusServei)
CP: codi_element
CAj: codi_element --> element
