-- MASCOTAS(nombre,raza)
.open mascotas
CREATE TABLE mascotas(nombre VARCHAR(50), raza VARCHAR(100));
.tables
