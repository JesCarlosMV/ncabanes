# sv2022-basesDeDades
## 0203-ModelEntitatRelacioYModelRelacional

Exercicis de Bases de dades, 1r DAW, SV 22/23

Bloc: Model Entitat-Relació y model relacional
