-- Grupo: Elizabeth García, Alejandro Barriel, Borja Coronado 
-- Fecha: (20/02/23)

-- Bomber (codi, nom)
-- CP: codi
-- VNN: nom

-- Incendi (codi, nom)
-- CP: codi

-- Brigada (codi, nom, codiBomberCap)
-- CP: codi
-- C.Alt: codiBomberCap
-- C.Aj: codiBomberCap -> Bomber

-- Participa(codiBomber, codiIncendi, codiBrigada)
-- CP: codiBomber, codiIncendi
-- VNN: codiBrigada
-- C.Aj: codiBomber -> Bomber
-- C.Aj: codiIncendi -> Incendi
-- C.Aj: codiBrigada -> Brigada

-- Especialitat(codiBomber, nom)
-- CP: codiBomber, nom
-- C.Aj: codiBomber -> Bomber

-- Delinqüent(codi, nom)
-- CP: codi

-- Provocar(codiDelinqüent, codiIncendi)
-- CP: codiDelinqüent, codiIncendi
-- C.Aj: codiIncendi -> Incendi
-- C.Aj: codiDelinqüent -> Delinqüent

