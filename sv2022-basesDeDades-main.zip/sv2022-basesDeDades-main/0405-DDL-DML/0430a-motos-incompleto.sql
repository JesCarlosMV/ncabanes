-- 1. Crea una tabla de marcas, retocando el siguiente esquema, de modo que el 
-- código tenga reservadas exactamente 5 letras y sea clave primaria, y el nombre 
-- (único) tenga reservadas un máximo de 30.
-- 
-- CREATE TABLE marcas (
--     codigo XXX,
--     nombre YYY
-- );

CREATE TABLE marcas (
    codigo CHAR(5) PRIMARY KEY,
    nombre VARCHAR(30) UNIQUE
);


-- 2. Crea una tabla de categorías, con la misma estructura que la de marcas. Crea 
-- una tabla de motos, con los campos que se muestan a continuación, en la que la 
-- potencia y la cilindrada sean datos numéricos con 4 cifras antes de la coma y 
-- una cifra después. El modelo no debe ser nulo. No indiques de forma explícita 
-- las claves ajenas, para que podamos añadir cualquier dato de prueba, incluso si 
-- no está conectado con las demás tablas.
-- 
-- CREATE TABLE categorias (
--     codigo XXX,
--     nombre YYY
-- );
-- 
-- CREATE TABLE motos (
--     codigo ???,
--     modelo ???,
--     potencia ???,
--     cilindrada ???,
--     codigoMarca XXX,
--     codigoCategoria XXX
-- );


CREATE TABLE categorias (
    codigo CHAR(5) PRIMARY KEY,
    nombre VARCHAR(30) UNIQUE
);

CREATE TABLE motos (
    codigo CHAR(5) PRIMARY KEY,
    modelo VARCHAR(30) NOT NULL,
    potencia NUMERIC(5,1),
    cilindrada NUMERIC(5,1),
    codigoMarca CHAR(5),
    codigoCategoria CHAR(5)
);


-- 2b. (Sin puntuación) Vuelca los siguientes datos:

INSERT INTO marcas VALUES ( 'H', 'Honda');
INSERT INTO marcas VALUES ( 'Y', 'Yamaha');
INSERT INTO marcas VALUES ( 'S', 'Suzuki');
INSERT INTO marcas VALUES ( 'K', 'Kawasaki');
INSERT INTO marcas VALUES ( 'MV', 'MV Agusta');

INSERT INTO categorias VALUES ( '125', '125cc');
INSERT INTO categorias VALUES ( 'N', 'Naked');
INSERT INTO categorias VALUES ( 'D', 'Deportiva');
INSERT INTO categorias VALUES ( 'T', 'Trail');
INSERT INTO categorias VALUES ( 'S', 'Scooter');

INSERT INTO motos VALUES ( 'V125', 'Varadero 125', 15, 124.9, 'H', '125');
INSERT INTO motos VALUES ( 'C125', 'CB125R', 15, 124.9, 'H', '125');
INSERT INTO motos VALUES ( 'C700', 'CB 700 Hornet', 92, 700, 'H', 'N');
INSERT INTO motos VALUES ( 'R6R', 'R6 Race', NULL, 600, 'Y', 'D');


-- 3. Nombres de todas las marcas, ordenados alfabéticamente.

SELECT nombre
FROM marcas
ORDER BY nombre;


-- 4. Nombres de todos los modelos, sin duplicados, ordenados alfabéticamente de 
-- la Z a la A.

SELECT DISTINCT modelo
FROM motos
ORDER BY modelo DESC;


-- 5. Nombre de la marca y nombre del modelo para las motos cuya cilindrada no es 
-- 124,9.

SELECT marcas.nombre, motos.modelo
FROM marcas, motos
WHERE motos.codigoMarca = marcas.codigo
AND cilindrada <> 124.9;


-- 6. Marca y modelo para las motos de las que no conocemos la potencia.

SELECT marcas.nombre, motos.modelo
FROM marcas, motos
WHERE motos.codigoMarca = marcas.codigo
AND potencia IS NULL;


-- 7. Modelo y categoría para las motos de marca “Honda” (quizás con mayúsculas 
-- distintas).

SELECT motos.modelo, categorias.nombre
FROM marcas, motos, categorias
WHERE motos.codigoMarca = marcas.codigo
AND motos.codigoCategoria = categorias.codigo
AND UPPER(marcas.nombre) = 'HONDA';


-- 8. Modelo y potencia redondeada sin decimales, para las motos cuya cilindrada 
-- es 600.

SELECT modelo, ROUND(potencia)
FROM motos
WHERE cilindrada = 600;


-- 9. Potencia media de las motos que tenemos registradas en nuestra base de 
-- datos. Debes usar el alias “potenciaMedia”. 

SELECT AVG(potencia) AS potenciaMedia
FROM motos;


-- 10. Cantidad de motos que tenemos de cada cilindrada.

SELECT cilindrada, COUNT(*)
FROM motos
GROUP BY cilindrada;


-- 11. Cantidad de motos que tenemos de cada categoría, 
-- solo para las categorías en las que realmente aparece alguna moto.

SELECT categorias.nombre, COUNT(*)
FROM motos, categorias
WHERE motos.codigoCategoria = categorias.codigo
GROUP BY categorias.nombre;


-- 12. Nombres de las marcas y cantidad de motos que tenemos
--de cada marca, incluso si en alguna marca no tenemos ninguna moto.

SELECT marcas.nombre, COUNT(motos.modelo)
FROM marcas LEFT JOIN motos
ON motos.codigoMarca = marcas.codigo
GROUP BY marcas.nombre;


-- 13. Motos de las marcas Honda o Yamaha, de 2 formas distintas.

SELECT marcas.nombre, motos.modelo
FROM marcas, motos
WHERE motos.codigoMarca = marcas.codigo
AND (marcas.nombre = 'Honda' OR marcas.nombre = 'Yamaha');

SELECT marcas.nombre, motos.modelo
FROM marcas, motos
WHERE motos.codigoMarca = marcas.codigo
AND marcas.nombre IN ('Honda', 'Yamaha');


-- 14. Motos de la misma marca que la moto más potente que tenemos registrada.

-- Previo 1: moto más potente

SELECT MAX(potencia) FROM motos;

-- Previo 2: (código de) marca de la moto más potente

SELECT codigoMarca FROM motos
WHERE potencia =
(
    SELECT MAX(potencia) FROM motos
);

-- Paso final: motos de esa(s) marca(s)

SELECT modelo 
FROM motos
WHERE codigoMarca IN
(
    SELECT codigoMarca FROM motos
    WHERE potencia =
    (
        SELECT MAX(potencia) FROM motos
    )
);


-- 15. Motos de la misma marca que la CB125R.

SELECT modelo 
FROM motos
WHERE codigoMarca =
(
    SELECT codigoMarca FROM motos
    WHERE modelo = 'CB125R'
);


-- 16. Marca y modelo de las motos que pertenecen a alguna marca en la que existe 
-- algún modelo de 600 cm3 de cilindrada.

-- Previo 1: Codigo de marca para las motos de 600 cc

SELECT codigoMarca FROM motos WHERE cilindrada = 600;

-- Modelos de esas motos

SELECT modelo FROM motos WHERE
codigoMarca IN (SELECT codigoMarca FROM motos WHERE cilindrada = 600);

-- Consulta completa

SELECT marcas.nombre, motos.modelo 
FROM motos, marcas 
WHERE motos.codigoMarca = marcas.codigo
AND codigoMarca IN 
(
    SELECT codigoMarca 
    FROM motos 
    WHERE cilindrada = 600
);


-- 17. Potencia de la moto más potente de cada marca, ordenada alfabéticamente.

-- Previo: código de marca

SELECT codigoMarca, MAX(potencia)
FROM motos
GROUP BY codigoMarca;

-- Consulta, cruzando con "marcas"

SELECT marcas.nombre, MAX(potencia)
FROM motos, marcas
WHERE motos.codigoMarca = marcas.codigo
GROUP BY marcas.nombre;

-- 17b. Marca y modelo de la moto más potente de cada marca, 
-- ordenada por marca y modelo.

-- ############# Pendiente ###########


-- 18. Modelos cuya primera letra sea una C, tras quitar los posibles espacios 
-- redundantes iniciales y finales. Bonus: modelos cuya segunda letra sea una B.

-- 18a

SELECT modelo 
FROM motos
WHERE UPPER(TRIM(modelo)) LIKE 'C%';

SELECT modelo 
FROM motos
WHERE UPPER(TRIM(SUBSTRING(modelo,1,1))) ='C';

-- 18b

SELECT modelo 
FROM motos
WHERE UPPER(TRIM(modelo)) LIKE '_B%';

SELECT modelo 
FROM motos
WHERE UPPER(TRIM(SUBSTRING(modelo,2,1))) ='B';


-- 19. Muestra todos los códigos que aparecen en la base de datos, ya sean de 
-- modelos, de marcas o de categorías.

SELECT codigo FROM motos
UNION
SELECT codigo FROM marcas
UNION
SELECT codigo FROM categorias ;

-- Versión mejorada: ordenado

SELECT codigo FROM 
(
    SELECT codigo FROM motos
    UNION
    SELECT codigo FROM marcas
    UNION
    SELECT codigo FROM categorias
)
ORDER BY codigo DESC;


-- 20. Marcas en las que aparecen tanto modelos de la categoría “Scooter” como 
-- modelos de la categoría “Naked”. 

-- ############# Pendiente ###########


-- 21. Bonus: marca y modelo de la segunda moto más potente. 

-- ############# Pendiente ###########

