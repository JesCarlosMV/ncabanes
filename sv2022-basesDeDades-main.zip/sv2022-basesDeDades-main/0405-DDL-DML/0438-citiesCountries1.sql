-- 1. Nom de cada ciutat i nom del país al qual pertany, ordenat per ciutat i , en cas que dues ciutats tinguen el mateix nom, per nom del país.

SELECT city.name, country.name 
FROM city, country
WHERE city.CountryCode = country.Code
ORDER BY city.name, country.name;

-- 2. Països dels quals no tenim cap ciutat, ordenats de manera descendent.

SELECT country.name 
FROM country LEFT JOIN city
ON country.Code = city.CountryCode
GROUP BY country.name
HAVING COUNT(city.name) = 0
ORDER BY country.name;

-- 3. Països el nom dels quals coincideix amb el d'una ciutat.

SELECT country.name 
FROM country 

INTERSECT

SELECT city.name 
FROM city;


-- 4. Nom de cada país al costat del nom de la seua capital, si existeix.

SELECT country.name, city.name 
FROM country LEFT JOIN city
ON country.capital = city.id;


-- 5. País, capital i governant, per als països el governant dels quals tinga 3 o més paraules, ordenat per país.

SELECT country.name, city.name, headOfState
FROM city, country
WHERE country.capital = city.id
AND headOfState LIKE '% % %'
ORDER BY country.name;


-- 6. Capitals i noms de països el producte interior brut dels quals siga inferior a tots els d'Europa.

SELECT city.name, country.name
FROM city, country
WHERE country.capital = city.id
AND GNP < 
(
    SELECT MIN(gnp) FROM country
    WHERE continent = 'Europe'
);


-- 7. Per a cada país: nom, població i suma de les poblacions de les ciutats que ens apareixen d'aqueix país.

SELECT country.name, country.population, sum(city.population)
FROM country, city
WHERE city.CountryCode = country.Code
GROUP BY country.name, country.population;


-- 8. Països la població dels quals és menys de la meitat de la ciutat més poblada de tota la base de dades.

SELECT country.name, country.population
FROM country WHERE population < 
(
    SELECT MAX(population)/2 FROM city
);


-- 9. Capitals que tinguen la meitat (o més) de la població del seu país.

SELECT city.name, city.population
FROM country, city
WHERE country.capital = city.id
AND city.population >= country.population / 2;


-- 10. Ciutats el nom de les quals està repetit, i nom dels països en els quals estan aqueixes ciutats.

SELECT city.name, city.id, country.name 
FROM city, country
WHERE city.CountryCode = country.Code
AND city.name IN
(
    SELECT name FROM city
    GROUP BY name
    HAVING COUNT(*) >= 2
)
ORDER BY city.name, country.name;

-- -----------------------------------

-- 1. Nombre de cada ciudad y nombre del país al que pertenece, ordenado por ciudad y , en caso de que dos ciudades se llamen igual, por nombre del país.
-- 2. Países de los que no tenemos ninguna ciudad, ordenados de forma descendente.
-- 3. Países cuyo nombre coincide con el de una ciudad.
-- 4. Nombre de cada país junto al nombre de su capital, si existe.
-- 5. País, capital y gobernante, para los países cuyo gobernante tenga 3 o más palabras, ordenado por país.
-- 6. Capitales y nombres de países cuyo producto interior bruto sea inferior a todos los de Europa.
-- 7. Para cada país: nombre, población y suma de las poblaciones de las ciudades que nos aparecen de ese país.
-- 8. Países cuya población es menos de la mitad de la ciudad más poblada de toda la base de datos.
-- 9. Capitales que tengan la mitad (o más) de la población de su país.
-- 10. Ciudades cuyo nombre está repetido, y nombre de los países en los que están esas ciudades.
