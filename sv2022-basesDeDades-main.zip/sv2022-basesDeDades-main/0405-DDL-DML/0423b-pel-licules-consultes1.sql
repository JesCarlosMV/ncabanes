-- 1. Llista ordenada de pel·lícules (títol, any i valoració).

SELECT titol, anyLlancament, valoracio
FROM pellicules
ORDER BY titol;

-- 2. Pel·lícula (títol i any) posteriors al 2000 (però que no 
-- siguen de 2005) amb una valoració superior a 8.5.

SELECT titol, anyLlancament
FROM pellicules
WHERE anyLlancament > 2000
AND anyLlancament <> 2005
AND valoracio > 8.5;


-- 3. Llista de directors (per als quals realment coneguem pel·lícules), 
-- ordenats alfabèticament, i quantitat de pel·lícules que han dirigit.

SELECT directors.nom, COUNT(*)
FROM directors, pellicules
WHERE pellicules.codiDirector = directors.codi
GROUP BY directors.nom
ORDER BY directors.nom;

