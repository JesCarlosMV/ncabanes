CREATE TABLE viatges ( 
  codi VARCHAR(5) PRIMARY KEY, 
  nom VARCHAR(25),
  preu NUMERIC(5),
  dies NUMERIC(3)
);

INSERT INTO viatges VALUES ('dp', 'Disneyland Paris', 118, 3);
INSERT INTO viatges VALUES ('pr', 'Praga', 194, 3);
INSERT INTO viatges VALUES ('na', 'Nápoles', NULL, NULL);
INSERT INTO viatges VALUES ('ro', 'Roma', 191, 3);
INSERT INTO viatges VALUES ('lp', 'Laponia', 1730, 5);
INSERT INTO viatges VALUES ('ri', 'Riviera Maya', 772, 9);
INSERT INTO viatges VALUES ('rm', 'Roma', 460, 4);

-- 1. Mostra els viatges (nom i preu) de 5 dies o més.

SELECT nom, preu 
FROM viatges 
WHERE dies >= 5;

-- 2. Mostra el codi i el nom dels viatges que no siguen de 3 dies.

SELECT codi, nom
FROM viatges 
WHERE dies <> 3;

-- 3. Obtingues el nom dels viatges per als quals no coneixem preu.

SELECT nom
FROM viatges 
WHERE preu IS NULL;

-- 4. Mostra els viatges que siguen a Roma o a Nápoles.

SELECT *
FROM viatges 
WHERE nom = 'Roma' OR nom = 'Nápoles';


-- 5. Mostra els viatges a ciutats que comencen per P i que costen no més de 200 euros.

SELECT *
FROM viatges 
WHERE nom LIKE 'P%' AND preu <= 200;

-- 6. Mostra la quantitat de viatges i la seua duració mitjana.

SELECT COUNT(*) AS quantitat, AVG(dies)
FROM viatges;

-- 7. Mostra els noms de les ciutats en majúscules, juntament amb el preu per dia.

SELECT UPPER(nom), preu / dies
FROM viatges;


-- 8. Mostra la quantitat de viatges que tenim a cada ciutat.

SELECT nom, COUNT(*)
FROM viatges 
GROUP BY nom;


-- 9. Mostra la quantitat de viatges que tenim a cada ciutat, però només per a les ciutats en les quals hi haja més d'un viatge disponible.

SELECT nom, COUNT(*)
FROM viatges 
GROUP BY nom
HAVING COUNT(*) > 1;


-- 10. Mostra els viatges en els quals el codi de viatge coincidisca amb les dues primeres lletres de la ciutat (potser amb majúscules diferents).

SELECT *
FROM viatges 
WHERE UPPER(codi) = UPPER(SUBSTR(nom, 1, 2));
