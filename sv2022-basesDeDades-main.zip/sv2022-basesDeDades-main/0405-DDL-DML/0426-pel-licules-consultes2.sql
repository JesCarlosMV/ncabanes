-- Consultes:

-- 1. Any de llançament i valoració de la pel·lícula anomenada "Titanic"

SELECT anyLlancament, valoracio FROM pellicules WHERE titol = 'Titanic';


-- 2. Títol de les pel·lícules el nom de les quals acaba en "R", ordenades.

SELECT titol FROM pellicules WHERE UPPER(titol) LIKE '%R' ORDER BY titol;


-- 3. Nom i any de les pel·lícules llançades entre els anys 2000 i 2020, 
-- inclusivament, ordenades per any.

SELECT titol, anyLlancament 
FROM pellicules 
WHERE anyLlancament BETWEEN 2000 AND 2020 
ORDER BY anyLlancament;

SELECT titol, anyLlancament 
FROM pellicules 
WHERE anyLlancament >= 2000 AND anyLlancament <= 2020 
ORDER BY anyLlancament;


-- 4. Títol, nom del director i valoració de les pel·lícules la valoració 
-- de les quals no siga 7,9, ordenades per títol.

SELECT titol, nom, valoracio 
FROM directors, pellicules 
WHERE pellicules.codiDirector = directors.codi 
    AND valoracio <> 7.9 
ORDER BY titol;


-- 5. Pel·lícules dirigides per "JAMES CAMERON" (potser amb majúscules 
-- diferents), ordenades per any.

SELECT pellicules.titol 
FROM pellicules, directors 
WHERE pellicules.codiDirector = directors.codi 
    AND UPPER(directors.nom) = 'JAMES CAMERON' 
ORDER BY anyLlancament;


-- 6. Títol de les pel·lícules en les quals participa Sigourney Weaver.

SELECT pellicules.titol 
FROM pellicules, actors, actuen 
WHERE actuen.codiActor = actors.codi 
    AND actuen.codiPelicula = pellicules.codi
    AND UPPER(actors.nom) = 'SIGOURNEY WEAVER'; 

-- 7. Títol i any de les pel·lícules en les quals participen 
-- Sigourney Weaver o Harrison Ford, de més recent a més antiga.

SELECT pellicules.titol, pellicules.anyLlancament 
FROM pellicules, actors, actuen 
WHERE actuen.codiActor = actors.codi 
    AND actuen.codiPelicula = pellicules.codi
    AND (UPPER(actors.nom) = 'SIGOURNEY WEAVER' 
        OR UPPER(actors.nom) = 'HARRISON FORD') 
ORDER BY pellicules.anyllancament;

-- 8. Nom dels persones que han treball sota els ordes de Christopher Nolan com a director, ordenats alfabèticament, sense duplicats.

SELECT DISTINCT actors.nom 
FROM actors, directors, actuen, pellicules 
WHERE actuen.codiActor = actors.codi 
    AND actuen.codiPelicula = pellicules.codi 
    AND pellicules.codiDirector = directors.codi 
    AND directors.nom = 'Christopher Nolan'
ORDER BY actors.nom;


-- 9. Nom de cada actor i quantitat de pel·lícules en les quals 
-- ens consta que ha participat, ordenat del qual més al qual menys 
-- (només per als que realment han participat en alguna pel·lícula).

SELECT actors.nom, COUNT(*) 
FROM actors, actuen 
WHERE actors.codi = actuen.codiactor 
GROUP BY actors.nom
ORDER BY COUNT(*) DESC;

-- 10. Nom de tots els persones i quantitat de pel·lícules en les quals 
-- ens consta que ha participat cadascun, ordenat alfabèticament.

SELECT actors.nom, COUNT(codiPelicula) 
FROM actors LEFT JOIN actuen 
ON actors.codi = actuen.codiactor 
GROUP BY actors.nom
ORDER BY COUNT(codiPelicula) DESC;

-----------------------------------

-- Consultas:

-- 1. Año de lanzamiento y valoración de la película llamada "Titanic"
-- 2. Título de las películas cuyo nombre termina en "R", ordenadas.
-- 3. Nombre y año de las películas lanzadas entre los años 2000 y 2020, inclusive, ordenadas por año.
-- 4. Título, nombre del director y valoración de las películas cuya valoración no sea 7,9, ordenadas por título.
-- 5. Películas dirigidas por "JAMES CAMERON" (quizá con mayúsculas distintas), ordenadas por año.
-- 6. Título de las películas en las que participa Sigourney Weaver.
-- 7. Título y año de las películas en las que participan Sigourney Weaver o Harrison Ford, de más reciente a más antigua.
-- 8. Nombre de los actores que han trabajo bajo las órdenes de Christopher Nolan como director, ordenados alfabéticamente, sin duplicados.
-- 9. Nombre de cada actor y cantidad de películas en las que nos consta que ha participado, ordenado del que más al que menos (sólo para los que realmente han participado en alguna película).
-- 10. Nombre de todos los actores y cantidad de películas en las que nos consta que ha participado cada uno, ordenado alfabéticamente.

