-- Crea una taula Revistes, per a anotar dades d'antigues revistes en paper que tenim guardes:
-- 
-- - Codi, de 5 lletres
-- - Nom, de fins a 20 lletres, no nul, únic
-- - Categoria, de fins a 30 lletres,
-- - Any, número de 4 xifres, entre 1940 i 2040.
    -- - Mes, número de 2 xifres, entre 1 i 12
-- 
-- Crea també una taula Articles, amb camps:
-- 
-- - Codi, de fins a 15 lletres
-- - Títol, de fins a 30 lletres
-- - Descripció, de fins a 1000 lletres
-- - Subcategoria, de fins a 20 lletres
-- - Valoració, d'1 a 10, amb un decimal.
-- - Codi de revista, clau aliena a la taula anterior.
-- 
-- Usa la sintaxi de Oracle.

CREATE TABLE revistes(
    codi CHAR(5), 
    nom VARCHAR2(20) NOT NULL,
    categ VARCHAR2(30),
    anyPubli NUMBER(4),
    mesPubli NUMBER(2),
    CONSTRAINT pk_revistes PRIMARY KEY (codi),
    CONSTRAINT uk_revistes_num UNIQUE (nom),
    CONSTRAINT ck_revistes_any CHECK(anyPubli BETWEEN 1940 AND 2040),
    CONSTRAINT ck_revistes_mes CHECK(mesPubli BETWEEN 1 AND 12)
);

CREATE TABLE articles(
    codi VARCHAR2(15), 
    titol VARCHAR2(50),
    descripcio VARCHAR2(1000),
    subCateg VARCHAR2(20),
    valoracio NUMBER(3,1), 
    codiRevista CHAR(5), 
    CONSTRAINT pk_articles PRIMARY KEY (codi),
    CONSTRAINT fk_articles 
        FOREIGN KEY (codiRevista) REFERENCES revistes(codi)
); 


-- ---------------

-- Crea una tabla Revistas, para anotar datos de antiguas revistas en papel que tenemos guardas:
-- 
-- - Código, de 5 letras
-- - Nombre, de hasta 20 letras, no nulo, único
-- - Categoría, de hasta 30 letras, 
-- - Año, número de 4 cifras, entre 1940 y 2040.
-- - Mes, número de 2 cifras, entre 1 y 12
-- 
-- Crea también una tabla Artículos, con campos:
-- 
-- - Código, de hasta 15 letras
-- - Título, de hasta 30 letras
-- - Descripción, de hasta 1000 letras
-- - Subcategoría, de hasta 20 letras
-- - Valoración, de 1 a 10, con un decimal.
-- - Código de revista, clave ajena a la tabla anterior.
-- 
-- Usa la sintaxis de Oracle.
-- 
