CREATE TABLE propietaris (
    codi_propietari NUMERIC(5) PRIMARY KEY, 
    nom_propietari VARCHAR(50), 
    cognoms_propietari VARCHAR(100), 
    telefon_propietari NUMERIC (9));
CREATE TABLE mascotes (
    codi_mascota NUMERIC(5) PRIMARY KEY, 
    nom_mascota VARCHAR(50), 
    tipus_mascota VARCHAR(100), 
    codi_propietari NUMERIC (5));

INSERT INTO propietaris VALUES (1,'Fernando','Garcia',654123851);
INSERT INTO propietaris VALUES (2,'Andrea','Perez',654165851);
INSERT INTO propietaris VALUES (3,'Angel','Rodriguez',663175851);
INSERT INTO propietaris VALUES (4,'Raul','Sanchez',663167851);

INSERT INTO mascotes VALUES (1,'Nieve','Pastor aleman',2);
INSERT INTO mascotes VALUES (2,'Pluto','Mezcla',1);
INSERT INTO mascotes VALUES (3,'Coco','Pastor Belga',3);
INSERT INTO mascotes VALUES (4,'Tara','Podenco',4);

SELECT nom_mascota, nom_propietari
FROM mascotes NATURAL JOIN propietaris;
