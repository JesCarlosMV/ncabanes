CREATE TABLE estudiantsData ( 
  nia NUMERIC(10) PRIMARY KEY, 
  nom VARCHAR(25), 
  cognoms VARCHAR(50), 
  dataNaixement DATE,
  email VARCHAR(100)
);

INSERT INTO estudiantsData VALUES (23, 'Michael', 'Jordan', '1963-02-17', 'michael@jordan.com'); 
INSERT INTO estudiantsData VALUES (32, 'Earvin', 'Johnson', '1959-08-14', 'magic@johnson.com');

-- Afig tres (o més) dades d'exemple

INSERT INTO estudiantsData VALUES (34, 'Hakeem', 'Olajuwon', '1963-01-21', 'hakeem@olaju.com');
INSERT INTO estudiantsData VALUES (11, 'Isaiah', 'Thomas', NULL, NULL);
INSERT INTO estudiantsData (nia, nom, cognoms) VALUES (33, 'Larry', 'Bird');
INSERT INTO estudiantsData (nom, cognoms, nia, dataNaixement ) VALUES ('Dominique', 'Wilkins', 21, '1960-01-12');

-- Mostra totes les dades

SELECT * FROM estudiantsData;

-- Mostra nom, cognoms i data de naixement, ordenats del més jove al més vell

SELECT nom, cognoms, nia, dataNaixement FROM estudiantsData ORDER BY dataNaixement DESC;
