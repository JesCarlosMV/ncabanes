-- A partir del diagrama EER de l'exercici 02.20 (articles i peces):

-- https://github.com/ncabanes/sv2022-basesDeDades/blob/main/0203-ModelEntitatRelacioYModelRelacional/0220a-almacen1-eer.png

-- 1. Crea les taules corresponents i les restriccions que siguen necessàries, usant la sintaxi de Oracle.

CREATE TABLE articles (
    codi VARCHAR2 (5), 
    nom VARCHAR2 (60),
    CONSTRAINT pk_articles PRIMARY KEY (codi) 
);
    
CREATE TABLE peces (
    codi VARCHAR2 (5), 
    nom VARCHAR2 (60),
    CONSTRAINT pk_peces PRIMARY KEY (codi)
); 

CREATE TABLE conte (
    codi_article VARCHAR2 (5), 
    codi_peca VARCHAR2 (5),
    CONSTRAINT pk_conte PRIMARY KEY (codi_article, codi_peca),
    CONSTRAINT fk_conte_articles FOREIGN KEY (codi_article) REFERENCES articles(codi),
    CONSTRAINT fk_conte_peces FOREIGN KEY (codi_peca) REFERENCES peces(codi)
);

-- 2. Afig un camp que permeta anotar el preu de compra, en la taula de peces. Afig un camp "quantitat" en la relació "conté". 

-- Versió per a SQLite

ALTER TABLE peces ADD COLUMN preu_compra NUMERIC(6,2); 

ALTER TABLE conte ADD COLUMN quantitat NUMERIC(4); 

-- Versió per a Oracle

ALTER TABLE peces ADD preu_compra NUMERIC(6,2); 

ALTER TABLE conte ADD quantitat NUMERIC(4); 


-- 3. Afig un camp "nom2" a la taula d'articles, i després canvia'l de nom a "descripció".

-- Versió per a SQLite

ALTER TABLE articles ADD COLUMN nom2 VARCHAR2(100); 

ALTER TABLE articles RENAME COLUMN nom2 TO descripcio; 

-- Versió per a Oracle

ALTER TABLE articles ADD nom2 VARCHAR2(100); 

ALTER TABLE articles RENAME COLUMN nom2 TO descripcio; 


-- 4. Esborra el camp "descripció".

ALTER TABLE articles DROP COLUMN descripcio; 



-- 5. Introdueix les següents dades: Peces (p1, Peça 1, 0.26), (p2, Peça 2, 0.37), (p3, Peça 3, 0.48), (p4, Peça 4, 1.05). Articles (a1, Article 1) i (a2, Article 2). L'article a1 està format per 4 peces p1 i una peça p4. L'article a2 està format per 6 peces p2 i dues peces p4. 

INSERT INTO peces VALUES ('p1', 'Peça 1', 0.26);
INSERT INTO peces VALUES ('p2', 'Peça 2', 0.37);
INSERT INTO peces VALUES ('p3', 'Peça 3', 0.48);
INSERT INTO peces VALUES ('p4', 'Peça 4', 1.05);

INSERT INTO articles VALUES ('a1', 'Article 1');
INSERT INTO articles VALUES ('a2', 'Article 2');

INSERT INTO conte VALUES ('a1', 'p1', 4);
INSERT INTO conte VALUES ('a1', 'p4', 1);
INSERT INTO conte VALUES ('a2', 'p2', 6);
INSERT INTO conte VALUES ('a2', 'p4', 2);


-- 6. Mostra els noms de les peces el nom de les quals acaba en 4, ordenades alfabèticament. 

SELECT nom
FROM peces
WHERE nom LIKE '%4'
ORDER BY nom;


-- 7. Mostra les peces per a les quals sabem el preu de compra, ordenades de la més cara a la més barata. 

SELECT *
FROM peces
WHERE preu_compra IS NOT NULL
ORDER BY preu_compra DESC;


-- 8. Mostra els noms de les peces que formen l'article a1, ordenades alfabèticament.

SELECT nom
FROM peces, conte
WHERE conte.codi_peca = peces.codi
AND conte.codi_article = 'a1'
ORDER BY nom;


-- 9. Calcula el cost de fabricació de l'article a2.

SELECT SUM(preu_compra)
FROM peces, conte
WHERE conte.codi_peca = peces.codi
AND conte.codi_article = 'a2';


-- 10. Mostra cada article i les peces que conté (fins i tot per als articles dels quals no coneixem peces), ordenat per nom d'article i nom de peça.

-- Dada addicional, per a comprovar que funciona

INSERT INTO articles VALUES ('a3', 'Article 3');

-- Aproximació incorrecta: WHERE

SELECT articles.nom, peces.nom
FROM peces, conte, articles
WHERE conte.codi_peca = peces.codi
AND conte.codi_article = articles.codi;

-- Correcta:

SELECT articles.nom, peces.nom
FROM articles LEFT JOIN conte 
  ON conte.codi_article = articles.codi
LEFT JOIN peces
  ON conte.codi_peca = peces.codi;


-- 11. Mostra els noms de les peces que actualment no estem usant com a part de cap article.
-- 12. Mostra els noms dels articles i també els de les peces, tot això ordenat alfabèticament.
-- 13. Mostra els noms d'articles que no coincideixen amb el nom de cap peça.
-- 14. Mostra el nom dels articles que tenen 2 o més peces.
-- 15. Mostra el nom de l'article amb el major cost de fabricació.
-- 16. Obtingues els noms de les peces que s'usen en l'article 2 però no en l'article 1.
-- 17. Mostra els articles en els quals s'usa la peça més cara.
-- 18. Mostra el nom de cada article i el nom de cadascun dels seus components. Han d'aparéixer totes les peces, fins i tot les que no s'usen en cap article.
-- 19. Mostra la diferència de preu entre la peça més cara i la més barata.
-- 20. Mostra el preu de la segona peça més cara.

-- ---------------------

-- A partir del diagrama EER del ejercicio 02.20 (artículos y piezas) :
-- 1. Crea las tablas correspondientes y refleja las restricciones que sean necesarias, usando la sintaxis de Oracle.
-- 2. Añade un campo que permita anotar el precio de compra, en la tabla de piezas. Añade un campo "cantidad" en la relación "contiene". 
-- 3. Añade un campo "nombre2" a la tabla de artículos, y luego renómbralo a "descripción".
-- 4. Borra el campo "descripción".
-- 5. Introduce los siguientes datos: Piezas (p1, Pieza 1, 0. 26), (p2, Pieza 2, 0. 37), (p3, Pieza 3, 0. 48), (p4, Pieza 4, 1.05). Artículos (a1, Artículo 1) y (a2, Artículo 2). El artículo a1 está formado por 4 piezas p1 y una pieza p4. El artículo a2 está formado por 6 piezas p2 y dos piezas p4. 
-- 6. Muestra los nombres de las piezas cuyo nombre termina en 4, ordenadas alfabéticamente. 
-- 7. Muestra las piezas para las que sabemos el precio de compra, ordenadas de la más cara a la más barata. 
-- 8. Muestra los nombres de las piezas que forman el artículo a1, ordenadas alfabéticamente.
-- 9. Calcula el coste de fabricación del artículo a2.
-- 10. Muestra cada artículo y las piezas que contiene (incluso para los artículos de los que no conocemos piezas), ordenado por nombre de artículo y nombre de pieza.
-- 11. Muestra los nombres de las piezas que actualmente no estamos usando como parte de ningún artículo.
-- 12. Muestra los nombres de los artículos y también los de las piezas, todo ello ordenado alfabéticamente.
-- 13. Muestra los nombres de artículos que no coinciden con el nombre de ninguna pieza.
-- 14. Muestra el nombre de los artículos que tienen 2 o más piezas.
-- 15. Muestra el nombre del artículo con el mayor coste de fabricación.
-- 16. Obtén los nombres de las piezas que se usan en el artículo 2 pero no en el artículo 1.
-- 17. Muestra los artículos en los que se usa la pieza más cara.
-- 18. Muestra el nombre de cada artículo y el nombre de cada uno de sus componentes. Deben aparecer todas las piezas, incluso las que no se usan en ningún artículo.
-- 19. Muestra la diferencia de precio entre la pieza más cara y la más barata.
-- 20. Muestra el precio de la segunda pieza más cara.
