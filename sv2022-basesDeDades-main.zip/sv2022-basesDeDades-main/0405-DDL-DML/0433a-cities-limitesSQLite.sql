-- LIMIT + SQLite

-- A partir de les dades de ciutats, mostra les 10 primeres alfabèticament.

SELECT Name FROM city
ORDER BY Name
LIMIT 10;

-- A partir de les dades de ciutats, ordenades alfabèticament, salta les 20 primeres i mostra les 10 següents.

SELECT Name FROM city
ORDER BY Name
LIMIT 10 OFFSET 20;
