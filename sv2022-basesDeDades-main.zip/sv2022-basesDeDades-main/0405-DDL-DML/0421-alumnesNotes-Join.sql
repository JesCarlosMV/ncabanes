CREATE TABLE alumnesNotes (
    nom VARCHAR(50), 
    tema VARCHAR(20), 
    nota NUMERIC (5,2),
    PRIMARY KEY (nom, tema));

INSERT INTO alumnesNotes VALUES ('Abraham', 'Tema 1', 9.8);
INSERT INTO alumnesNotes VALUES ('Basilio', 'Tema 1', 7.7);
INSERT INTO alumnesNotes VALUES ('Cecilia', 'Tema 1', 9.8);
INSERT INTO alumnesNotes VALUES ('David', 'Tema 1', 4.3);
INSERT INTO alumnesNotes VALUES ('Elena', 'Tema 1', 8.5);

INSERT INTO alumnesNotes VALUES ('Abraham', 'Tema 2', 10.0);
INSERT INTO alumnesNotes VALUES ('Basilio', 'Tema 2', 7.5);
INSERT INTO alumnesNotes VALUES ('Cecilia', 'Tema 2', 9.4);
INSERT INTO alumnesNotes VALUES ('David', 'Tema 2', 4.1);
INSERT INTO alumnesNotes VALUES ('Elena', 'Tema 2', 8.9);

INSERT INTO alumnesNotes VALUES ('Abraham', 'Tema 3', 8.8);
INSERT INTO alumnesNotes VALUES ('Basilio', 'Tema 3', 7.1);
INSERT INTO alumnesNotes VALUES ('Cecilia', 'Tema 3', 9.9);
INSERT INTO alumnesNotes VALUES ('Elena', 'Tema 3', 9.5);
INSERT INTO alumnesNotes VALUES ('Gerardo', 'Tema 3', 2.1);

-- 1. Noms d'alumnes, sense duplicats.

SELECT DISTINCT nom FROM alumnesNotes;

-- 2. Nota mitjana de tots els exàmens.

SELECT AVG(nota) FROM alumnesNotes;

-- 3. Nota mitjana dels exàmens del Tema 1.

SELECT AVG(nota) 
FROM alumnesNotes
WHERE tema = "Tema 1";

-- 4. Nota mitjana de cada examen.

SELECT tema, AVG(nota)
FROM alumnesNotes
GROUP BY tema;

-- 5. Nota mitjana de cada alumne.

SELECT nom, AVG(nota)
FROM alumnesNotes
GROUP BY nom;

-- 6. Nota mitjana dels alumnes, la mitjana dels quals és un suspens.

SELECT nom, AVG(nota)
FROM alumnesNotes
GROUP BY nom
HAVING AVG(nota) < 5;

-- 7. Notes del tema 1 i del tema 2 (usant OR).

SELECT nota
FROM alumnesNotes
WHERE tema = "Tema 1"
OR tema = "Tema 2";

-- 8. Notes del tema 1 i del tema 2 (usant IN).

SELECT nota
FROM alumnesNotes
WHERE tema IN ( "Tema 1", "Tema 2" );

-- 9. Nota més alta.

SELECT MAX(nota)
FROM alumnesNotes;

-- 10. Alumne(s) que ha(n) obtingut la nota més alta.

SELECT nom
FROM alumnesNotes
WHERE nota = ( SELECT MAX(nota)
FROM alumnesNotes );

-- -----------

-- 1. Nombres de alumnos, sin duplicados.
-- 2. Nota media de todos los exámenes.
-- 3. Nota media de los exámenes del Tema 1.
-- 4. Nota media de cada examen.
-- 5. Nota media de cada alumno.
-- 6. Nota media de los alumnos cuya media es un suspenso.
-- 7. Notas del tema 1 y del tema 2 (usando OR).
-- 8. Notas del tema 1 y del tema 2 (usando IN).
-- 9. Nota más alta.
-- 10. Alumno(s) que ha(n) sacado la nota más alta.

