-- LIMIT + SQLite

-- A partir de les dades de ciutats, mostra les 10 primeres alfabèticament.

SELECT Name FROM city
ORDER BY Name
FETCH NEXT 10 ROWS ONLY;

-- A partir de les dades de ciutats, ordenades alfabèticament, salta les 20 primeres i mostra les 10 següents.

SELECT Name FROM city
ORDER BY Name
OFFSET 20 ROWS
FETCH NEXT 10 ROWS ONLY;
