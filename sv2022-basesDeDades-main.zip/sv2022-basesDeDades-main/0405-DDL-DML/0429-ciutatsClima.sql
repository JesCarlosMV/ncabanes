-- Ciutats i climes

-- Basat en el exercici 02.82

CREATE TABLE climes (
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(50)
);

CREATE TABLE comunitats (
    codi VARCHAR(2) PRIMARY KEY,
    nom VARCHAR(50)
);

CREATE TABLE provincies (
    codi VARCHAR(2) PRIMARY KEY,
    nom VARCHAR(50),
    codiComunitat VARCHAR(2),
    FOREIGN KEY (codiComunitat) REFERENCES comunitats(codi)
);

CREATE TABLE ciutats (
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(50),
    codiProvincia VARCHAR(2),
    codiClima VARCHAR(5),
    FOREIGN KEY (codiProvincia) REFERENCES provincies(codi),
    FOREIGN KEY (codiClima) REFERENCES climes(codi)
);

INSERT INTO climes VALUES ( 'MSA', 'Mediterrani semiàrid');
INSERT INTO climes VALUES ( 'OL', 'Oceànic litoral');
INSERT INTO climes VALUES ( 'OC', 'Oceànic continental');
INSERT INTO climes VALUES ( 'MC', 'Mediterrani continental');
INSERT INTO climes VALUES ( 'ML', 'Mediterrani litoral');

INSERT INTO comunitats VALUES ( 'CV', 'Comunitat Valenciana');
INSERT INTO comunitats VALUES ( 'RM', 'Regió de Múrcia');
INSERT INTO comunitats VALUES ( 'G', 'Galícia');
INSERT INTO comunitats VALUES ( 'M', 'Madrid');
INSERT INTO comunitats VALUES ( 'C', 'Catalunya');

INSERT INTO provincies VALUES ( 'A', 'Alacant', 'CV');
INSERT INTO provincies VALUES ( 'MU', 'Múrcia', 'RM');
INSERT INTO provincies VALUES ( 'C', 'A Coruña', 'G');
INSERT INTO provincies VALUES ( 'OU', 'Ourense', 'G');
INSERT INTO provincies VALUES ( 'M', 'Madrid', 'M');
INSERT INTO provincies VALUES ( 'B', 'Barcelona', 'C');

INSERT INTO ciutats VALUES('A01', 'Alacant', 'A', 'MSA');
INSERT INTO ciutats VALUES('MU02', 'Cartagena', 'MU', 'MSA');
INSERT INTO ciutats VALUES('C11', 'Fisterra', 'C', 'OL');
INSERT INTO ciutats VALUES('C01', 'A Coruña', 'C', 'OL');
INSERT INTO ciutats VALUES('OU01', 'Ourense', 'OU', 'OC');
INSERT INTO ciutats VALUES('M47', 'Leganés', 'M', 'MC');
INSERT INTO ciutats VALUES('B91', 'El Prat de Llobregat', 'B', 'ML');
INSERT INTO ciutats VALUES('CC01', 'Cáceres', 'CC', NULL);

-- ---------------------------------

-- Consultes:

-- 0. Codi de ciutat, nom de ciutat, nom de província, nom de comunitat, nom de clima.

SELECT ciutats.codi, ciutats.nom, provincies.nom, comunitats.nom, climes.nom
FROM ciutats, provincies, comunitats, climes
WHERE ciutats.codiClima = climes.codi
AND ciutats.codiProvincia = provincies.codi
AND provincies.codiComunitat = comunitats.codi;

-- 1. Nom de les províncies que comencen per a.

SELECT nom
FROM ciutats
WHERE nom LIKE 'A%'
ORDER BY nom;

-- 2. Nom de les ciutats la comunitat de les quals no és 'Madrid', 
-- ordenades alfabèticament.

SELECT ciutats.codi, ciutats.nom, provincies.nom, comunitats.nom
FROM ciutats, provincies, comunitats
WHERE ciutats.codiProvincia = provincies.codi
AND provincies.codiComunitat = comunitats.codi
AND comunitats.nom <> 'Madrid';

-- 3. Nom de les comunitats el nom de les quals conté més d'una paraula.

SELECT nom
FROM comunitats
WHERE nom LIKE '% %';

-- 4. Nom de les ciutats per a les quals no coneixem el clima.

SELECT nom
FROM ciutats
WHERE codiClima IS NULL;

-- 5. Nom de les ciutats el clima de les quals siga 'Mediterrani litoral' 
-- (potser amb majúscules diferents).

SELECT ciutats.nom, climes.nom
FROM ciutats, climes
WHERE ciutats.codiClima = climes.codi
AND UPPER(climes.nom) = 'MEDITERRANI LITORAL';

-- 6. Nom de totes les ciutats, juntament amb nom de la província a la qual 
-- pertanyen, fins i tot si d'alguna no coneixem la província, ordenat per nom de 
-- ciutat.

SELECT ciutats.nom, provincies.nom
FROM ciutats LEFT JOIN provincies
ON ciutats.codiProvincia = provincies.codi;

-- 7. Quantitat de ciutats que coneixem per a cada tipus de clima.

SELECT climes.nom, COUNT(*)
FROM ciutats, climes
WHERE ciutats.codiClima = climes.codi
GROUP BY climes.nom;

-- 8. Nom de cada comunitat i quantitat de ciutats que coneixem en ella.

SELECT comunitats.nom, COUNT(*)
FROM ciutats, provincies, comunitats
WHERE ciutats.codiProvincia = provincies.codi
AND provincies.codiComunitat = comunitats.codi
GROUP BY comunitats.nom;

-- 9. Nom de les ciutats per a les quals no s'ha creat 
-- el registre de la seua província.

SELECT ciutats.nom
FROM ciutats
WHERE ciutats.codiProvincia NOT IN
(
    SELECT codi
    FROM provincies
);

-- 10. Nom de les províncies per a les quals coneixem 2 o més ciutats.

SELECT provincies.nom, COUNT(*)
FROM ciutats, provincies
WHERE ciutats.codiProvincia = provincies.codi
GROUP BY provincies.nom
HAVING COUNT(*) >= 2;


-----------------------------------

-- Consultas:

-- 0. Código de ciudad, nombre de ciudad, nombre de provincia, nombre de comunidad, nombre de clima.
-- 1. Nombre de las provincias que comienzan por A.
-- 2. Nombre de las ciudades cuya comunidad no es 'Madrid', ordenadas alfabéticamente.
-- 3. Nombre de las comunidades cuyo nombre contiene más de una palabra.
-- 4. Nombre de las ciudades para las que no conocemos el clima.
-- 5. Nombre de las ciudades cuyo clima sea 'Mediterrani litoral' (quizá con mayúsculas distintas).
-- 6. Nombre de todas las ciudades, junto con nombre de la provincia a la que pertenecen, incluso si de alguna no conocemos la provincia, ordenado por nombre de ciudad.
-- 7. Cantidad de ciudades que conocemos para cada tipo de clima.
-- 8. Nombre de cada comunidad y cantidad de ciudades que conocemos en ella.
-- 9. Nombre de las ciudades para las cuales no se ha creado el registro de su provincia.
-- 10. Nombre de las provincias para las que conocemos 2 o más ciudades.
