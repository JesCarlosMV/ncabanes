CREATE TABLE estudiantsData ( 
  nia NUMERIC(10) PRIMARY KEY, 
  nom VARCHAR(25), 
  cognoms VARCHAR(50), 
  dataNaixement DATE,
  email VARCHAR(100)
);

INSERT INTO estudiantsData VALUES (23, 'Michael', 'Jordan', TO_DATE( '1963-02-17', 'YYYY-MM-DD'), 'michael@jordan.com'); 
INSERT INTO estudiantsData VALUES (32, 'Earvin', 'Johnson', TO_DATE( '1959-08-14','YYYY-MM-DD'), 'magic@johnson.com');

