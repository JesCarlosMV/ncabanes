-- Streamers y temáticas (relación M:M)

CREATE TABLE streamers (
  codi VARCHAR(6) PRIMARY KEY,
  nom VARCHAR(30),
  pais VARCHAR(20)
);

CREATE TABLE tematiques (
  codi VARCHAR(4) PRIMARY KEY,
  nom VARCHAR(30)
);

CREATE TABLE parlaSobre (
  codiStreamer VARCHAR(6),
  codiTematica VARCHAR(4),
  idioma VARCHAR2(10),
  mitja VARCHAR2(20),
  milersSeguidors NUMERIC(6,1),
  PRIMARY KEY (codiStreamer, codiTematica)
);

INSERT INTO streamers VALUES ('ill','Ibai Llanos', 'Espanya');
INSERT INTO streamers VALUES ('ap','AuronPlay', 'Espanya');
INSERT INTO streamers VALUES ('ng','Nate Gentile', 'Espanya');
INSERT INTO streamers VALUES ('ltt','Linus Tech Tips', 'Canadá');
INSERT INTO streamers VALUES ('dyip','DYI Perks', NULL);
INSERT INTO streamers VALUES ('ach','Alexandre Chappel', 'Noruega');
INSERT INTO streamers VALUES ('tkn','Tekendo','Espanya');
INSERT INTO streamers VALUES ('cad','Caddac Tech',NULL);

INSERT INTO tematiques VALUES ('inf','Informàtica');
INSERT INTO tematiques VALUES ('tec','Tecnologia en general');
INSERT INTO tematiques VALUES ('gam','Gaming');
INSERT INTO tematiques VALUES ('var','Variat');
INSERT INTO tematiques VALUES ('bri','Bricolatge');
INSERT INTO tematiques VALUES ('via','Viatges');
INSERT INTO tematiques VALUES ('hum','Humor');

INSERT INTO parlaSobre VALUES ('ap','gam','Espanyol','YouTube',29200);
INSERT INTO parlaSobre VALUES ('ill','var','Espanyol','Twitch',12800);;
INSERT INTO parlaSobre VALUES ('ap','var','Espanyol','Twitch',14900);
INSERT INTO parlaSobre VALUES ('ng','inf','Espanyol','YouTube',2450);
INSERT INTO parlaSobre VALUES ('ltt','inf','Anglés','YouTube',15200);
INSERT INTO parlaSobre VALUES ('dyip','bri','Anglés','YouTube',4140);
INSERT INTO parlaSobre VALUES ('ach','bri','Anglés','YouTube',370);
INSERT INTO parlaSobre VALUES ('cad','inf','Anglés','YouTube',3);

-- 01. Nom de les temàtiques que tenim emmagatzemades, ordenades alfabèticament.
-- 02. Quantitat de streamers el país de la qual és "Espanya".
-- 03, 04, 05. Noms de streamers la segona lletra dels quals no siga una "B" (potser en minúscules), de 3 formes diferents.
-- 06. Mitjana de subscriptors per als canals l'idioma dels quals és "Espanyol".
-- 07. Mitjana de seguidors per als canals que el seu streamer és del país "Espanya".
-- 08. Nom de cada streamer i mitjà en el qual parla, per a aquells que tenen entre 5.000 i 15.000 milers de seguidors, usant BETWEEN.
-- 09. Nom de cada streamer i mitjà en el qual parla, per a aquells que tenen entre 5.000 i 15.000 milers de seguidors, sense usar BETWEEN.
-- 10. Nom de cada temàtica i nom dels idiomes en què tenim canals d'aqueixa temàtica (potser cap), sense duplicats.
-- 11. Nom de cada streamer, nom de la temàtica de la qual parla i del mitjà en el qual parla d'aqueixa temàtica, usant INNER JOIN.
-- 12. Nom de cada streamer, nom de la temàtica de la qual parla i del mitjà en el qual parla d'aqueixa temàtica, usant WHERE.
-- 13. Nom de cada streamer, del mitjà en el qual parla i de la temàtica de la qual parla en aqueix mitjà, fins i tot si d'algun streamer no tenim dada del mitjà o de la temàtica.
-- 14. Nom de cada mitjà i quantitat de canals que tenim anotats en ell, ordenat alfabèticament pel nom del mitjà.
-- 15, 16, 17, 18. Mig en el qual s'emet el canal de més seguidors, de 4 formes diferents.
-- 19. Categories de les quals tenim 2 o més canals.
-- 20. Categories de les quals no tenim anotat cap canal, ordenades alfabèticament, emprant COUNT.
-- 21. Categories de les quals no tenim anotat cap canal, ordenades alfabèticament, emprant IN / NOT IN.
-- 22. Categories de les quals no tenim anotat cap canal, ordenades alfabèticament, emprant ALL / ANY.
-- 23. Categories de les quals no tenim anotat cap canal, ordenades alfabèticament, emprant EXISTS / NOT EXISTS.
-- 24. Tres primeres lletres de cada país i tres primeres lletres de cada idioma, en una mateixa llista.
-- 25, 26, 27, 28. Tres primeres lletres de països que coincidisquen amb les tres primeres lletres d'un idioma, sense duplicats, de quatre formes diferents.
-- 29. Nom de streamer, nom de mitjà i nom de temàtica, per als canals que estan per damunt de la mitjana de subscriptors.
-- 30. Nom de streamer i mitjà, per als canals que parlen de la temàtica "Bricolatge".
-- 31. Crea una taula de "jocs". Per a cada joc voldrem un codi (5 xifres, clau primària), un nom (fins a 20 lletres, no nul) i una referència al streamer que més parla d'ell (clau aliena a la taula "streamers"). Usa sintaxi de Oracle.
-- 32. Afig a la taula de jocs la restricció que el codi ha de ser 1000 o superior.
-- 33. Afig 3 dades d'exemple en la taula de jocs. Per a un indicaràs tots els camps, per a un altre no indicaràs el streamer, ajudant-te de NULL, i per al tercer no indicaràs el streamer perquè no detallaràs tots els noms dels camps.
-- 34. Esborra la segona dada d'exemple que has afegit en la taula de jocs, a partir del seu codi.
-- 35. Mostra el nom de cada joc al costat del nom del streamer que més parla d'ell, si existeix. Les dades apareixeran ordenats per nom de joc i, en cas de coincidir aquest, per nom de streamer.
-- 36. Modifica l'última dada d'exemple que has afegit en la taula de jocs, perquè sí que tinga associat un streamer que parle d'ell.
-- 37. Crea una taula "jocsStreamers", bolcant en ella el nom de cada joc (amb l'àlies "jugue") i el nom del streamer que parla d'ell (amb l'àlies "streamer").
-- 38. Afig a la taula "jocsStreamers" un camp "dataProva".
-- 39. Posa la data de hui (prefixada, sense usar SYSDATE) en el camp "dataProva" de tots els registres de la taula "jocsStreamers".
-- 40. Mostra joc, streamer i data d'ahir (dia anterior al valor del camp "dataProva") per a tots els registres de la taula "jocsStreamers".
-- 41. Mostra totes les dades dels registres de la taula "jocsStreamers" que siguen de l'any actual de 2 formes diferents (per exemple, usant comodins o funcions de cadenes).
-- 42. Elimina la columna "streamer" de la taula "jocsStreamers".
-- 43. Buida la taula de "jocsStreamers", conservant la seua estructura.
-- 44. Elimina per complet la taula de "jocsStreamers".
-- 45. Esborra els canals del streamer "Caddac Tech".
-- 46. Mostra la diferència entre el canal amb més seguidors i la mitjana, mostrada en milions de seguidors. Usa l'àlies "diferenciaMillions".
-- 47. Mitjans en els quals tenen canals els creadors de codi "ill", "ng" i "ltt", sense duplicats, usant IN (però no en una subconsulta).
-- 48. Mitjans en els quals tenen canals els creadors de codi "ill", "ng" i "ltt", sense duplicats, sense usar IN.
-- 49. Nom de streamer i nom del mitjà en el qual parla, per a aquells dels quals no coneixem el país.
-- 50. Nom del streamer i mitjà dels canals que siguen del mateix mitjà que el canal de Ibai Llanos que té 12800 milers de seguidors (pot aparéixer el propi Ibai Llanos).
-- 51. Nom del streamer i mitjà dels canals que siguen del mateix mitjà que el canal de Ibai Llanos que té 12800 milers de seguidors (sense incloure a Ibai Llanos).
-- 52. Nom de cada streamer, mitjà i temàtica, fins i tot si per a algun streamer no apareix cap canal o per a alguna temàtica no apareix cap canal.
-- 53. Nom de mitjà i nom de cada temàtica, com a part d'una única llista (potser desordenada).
-- 54. Nom de mitjà i nom de cada temàtica, com a part d'una única llista ordenada alfabèticament.
-- 55. Nom de mitjà i quantitat mitjana de subscriptors en aqueix mitjà, per als quals estan per damunt de la mitjana de subscriptors dels canals.
-- 56. Nom dels streamers que emeten en YouTube i que o bé parlen en espanyol o bé els seus milers de seguidors estan per damunt de 12.000.
-- 57. Afig informació fictícia sobre tu: dades com streamer, temàtica sobre la qual suposadament i mitjà en el qual parles sobre ella, sense indicar quantitat de seguidors. Crea una consulta que mostre totes aqueixes dades a partir del teu codi.
-- 58. Mostra el nom de cada streamer, mitjà en el qual emet i quantitat de seguidors, en milions, arredonits a 1 decimal.
-- 59. Mostra el nom de cada streamer i el país d'origen. Si no se sap aquesta dada, haurà d'aparéixer "(País desconegut)".
-- 60. Mostra, per a cada streamer, el seu nom, el mitjà en el qual emet (precedit per "Emet en: ") i l'idioma del seu canal (precedit per "Idioma: ")
