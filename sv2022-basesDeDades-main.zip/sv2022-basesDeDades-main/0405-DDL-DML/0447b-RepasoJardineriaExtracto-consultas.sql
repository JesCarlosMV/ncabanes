-- Inspirado en:
-- https://josejuansanchez.org/bd/ejercicios-consultas-sql/index.html#jardiner%C3%ADa


-- 1. Devuelve el puesto, nombre, apellido y ciudad en la que trabaja el empleado 1, empleando INNER JOIN.

-- 2. Devuelve el puesto, nombre, apellido y ciudad en la que trabaja el empleado 1, empleando WHERE.

-- 3. Nombre de cada puesto y cantidad de empleados que ocupan ese puesto, ordenado alfabéticamente.

-- 5. Nombre de cada ciudad y cantidad de empleados que trabajan en ella (quizá 0), ordenado de mayor a menor cantidad de empleados, y en caso de coincidir esta, por nombre de ciudad (de al A a la Z)..

-- 6. Nombre y apellido de los empleados cuyo código está entre el 10 y el 20, y cuyo puesto además contiene el fragmento "repre" (quizá con mayúsculas distintas).

-- 7. Nombre y apellido de los empleados, cuyo apellido coincida con el nombre de una ciudad, usando IN.

-- 8. Nombre y apellido de los empleados, cuyo apellido coincida con el nombre de una ciudad, usando ANY.

-- 9. Nombre y apellido de los empleados, cuyo apellido coincida con el nombre de una ciudad, usando EXISTS.

-- 10. Nombre y apellido de los empleados, cuyo apellido coincida con el nombre de una ciudad, usando INNER JOIN.

-- 11, 12, 13. Nombre de las ciudades en las que aún no nos aparezcan ningún empleado, de 3 formas distintas.

-- 14. Nombre y apellido de cada empleado, junto con el nombre de la ciudad, usando NATURAL JOIN.

-- 15. Nombre (y apellido) de cada empleado junto con el nombre (y apellido) de su jefe, si existe.

-- 16. Nombre (y apellido) de cada empleado junto con el nombre (y apellido) de su jefe, si existe, y el nombre (y apellido) del jefe de su jefe, si existe.

-- 17, 18, 19. Nombre de las ciudades que coincidan con el nombre o apellido de algún empleado, de 3 formas distintas.

-- 20. Nombre de los países en los que trabajen al menos 5 personas.

-- 21. Ciudad de cada oficina y cantidad de empleados que trabajan en ella.

-- 22. Cantidad media de empleados que trabajan en cada ciudad.

-- 23. Ciudad y país de las oficinas en las que no tenemos ningún empleado todavía.

-- 24. Ciudad y país de las dos oficinas con más empleados.

-- 25, 26, 27, 28. Nombre de la ciudad en la que está la oficina que tiene la valoración más alta, de 4 formas distintas

-- 29. Código y ciudad de las oficinas que están en el mismo país que la oficina que tiene la valoración más alta.

-- 30. código y ciudad de las oficinas que tengan la misma valoración que alguna otra.

-- 31. código y ciudad de las oficinas cuya valoración esté por encima de la media de su país.

-- 32. Nombre y apellidos de los empleados que tienen jefe, pero cuyo jefe no tiene otro jefe por encima.

-- 33. Crea una tabla de "productos". Para cada producto querremos un código (5 letras), una descripción (hasta 50 letras), un importe (5 cifras a la izquierda de la coma decimal y 2 a su derecha) y una fecha de alta. El código actuará como clave primaria. Usa sintaxis de Oracle.

-- 34. Añade a la tabla de productos la restricción de que la descripción debe ser única.

-- 35. Añade 3 datos de ejemplo en la tabla de productos. Para uno indicarás todos los campos, para otro no indicarás la fecha ayudándote de NULL y para el tercero no indicarás la fecha porque no detallarás todos los nombres de los campos.

-- 36. Borra el tercer dato de ejemplo que has añadido en la tabla de productos, a partir de su código.

-- 37. Modifica el segundo dato de ejemplo que has añadido en la tabla de productos, a partir de su código, para que su fecha de alta sea la de hoy.

-- 38. Crea una tabla "backup_productos", volcando en ella el código la descripción y el importe de los datos que hay en la tabla de productos.

-- 39. Vacía la tabla de productos, conservando su estructura.

-- 40. Elimina la tabla de productos.

