-- .open mascotes1mJoin

--propietaris (codi,nom,cognoms, telefon)
--CP: codi
--mascotes (codi,nom,tipo,codi_propietari)
--CP: codi

CREATE TABLE propietaris (
    codi NUMERIC(5) PRIMARY KEY, 
    nom VARCHAR(50), 
    cognoms VARCHAR(100), 
    telefon NUMERIC (9));
CREATE TABLE mascotes (
    codi NUMERIC(5) PRIMARY KEY, 
    nom VARCHAR(50), 
    tipus VARCHAR(100), 
    codi_propietari VARCHAR (5));

INSERT INTO propietaris VALUES (1,'Fernando','Garcia',654123851);
INSERT INTO propietaris VALUES (2,'Andrea','Perez',654165851);
INSERT INTO propietaris VALUES (3,'Angel','Garcia',663175851);
INSERT INTO propietaris VALUES (4,'Raul','Sanchez',663167851);
INSERT INTO propietaris VALUES (5,'Sonia','Sanchez',6123456);

INSERT INTO mascotes VALUES (1,'Nieve','Pastor aleman',2);
INSERT INTO mascotes VALUES (2,'Pluto','Mezcla',1);
INSERT INTO mascotes VALUES (3,'Coco','Pastor Belga',3);
INSERT INTO mascotes VALUES (4,'Tara','Podenco',4);
INSERT INTO mascotes VALUES (5,'Pio','canario',4);

-- 1. Nom de cada propietari i nom de la seua mascota (1: utilitzant WHERE).

SELECT propietaris.nom, mascotes.nom
FROM propietaris, mascotes
WHERE propietaris.codi = mascotes.codi_propietari;

-- 2. Nom de cada propietari i nom de la seua mascota (2: utilitzant JOIN).

SELECT propietaris.nom, mascotes.nom
FROM propietaris INNER JOIN mascotes
ON propietaris.codi = mascotes.codi_propietari;

-- 3. Nom de tots els propietaris i de les seues mascotes (fins i tot si algun propietari realment no té mascota).

SELECT propietaris.nom, mascotes.nom
FROM propietaris LEFT OUTER JOIN mascotes
ON propietaris.codi = mascotes.codi_propietari;

-- 4. Nom dels propietaris i de totes les mascotes (fins i tot si alguna mascota no té propietari).

SELECT propietaris.nom, mascotes.nom
FROM propietaris RIGHT OUTER JOIN mascotes
ON propietaris.codi = mascotes.codi_propietari;

SELECT propietaris.nom, mascotes.nom
FROM mascotes LEFT OUTER JOIN propietaris
ON propietaris.codi = mascotes.codi_propietari;

-- 5. Nom de tots els propietaris i de totes les mascotes (fins i tot si alguna mascota no té propietari o si algun propietari no té mascota).

SELECT propietaris.nom, mascotes.nom
FROM propietaris FULL OUTER JOIN mascotes
ON propietaris.codi = mascotes.codi_propietari;

-- 6. Noms dels propietaris i quantitat de mascotes que té cadascun (només per a qui realment tinga mascota).

SELECT propietaris.nom, COUNT(*)
FROM propietaris, mascotes
WHERE propietaris.codi = mascotes.codi_propietari
GROUP BY propietaris.nom;

-- 7. Cognoms dels propietaris i quantitat de propietaris que tenen aqueix cognom.

SELECT cognoms, COUNT(*)
FROM propietaris
GROUP BY cognoms;

-- 8. Noms dels propietaris i quantitat de mascotes que té cadascun (incloent qui no tinga mascota).

SELECT propietaris.nom, COUNT(mascotes.codi)
FROM propietaris LEFT JOIN mascotes
ON propietaris.codi = mascotes.codi_propietari
GROUP BY propietaris.nom;

-- 9. Noms dels propietaris i quantitat de mascotes que té cadascun (només per als que tinguen 2 o més mascotes).

SELECT propietaris.nom, COUNT(*)
FROM propietaris, mascotes
WHERE propietaris.codi = mascotes.codi_propietari
GROUP BY propietaris.nom;

-- 10. Nom dels propietaris el nom dels quals conté una A i el telèfon de la qual comença per 6, juntament amb els noms de les seues mascotes (fins i tot si algun propietari realment no té mascota).

SELECT propietaris.nom, mascotes.nom
FROM propietaris LEFT OUTER JOIN mascotes
ON propietaris.codi = mascotes.codi_propietari
WHERE UPPER(propietaris.nom) LIKE '%A%'
AND TO_CHAR(telefono) LIKE '6%';

-- -----------

-- 1. Nombre de cada dueño y nombre de su mascota (1: usando WHERE).
-- 2. Nombre de cada dueño y nombre de su mascota (2: usando JOIN).
-- 3. Nombre de todos los dueños y de sus mascotas (incluso si algún dueño realmente no tiene mascota).
-- 4. Nombre de los dueños y de todas las mascotas (incluso si alguna mascota no tiene dueño).
-- 5. Nombre de todos los dueños y de todas las mascotas (incluso si alguna mascota no tiene dueño o si algún dueño no tiene mascota).
-- 6. Nombres de los dueños y cantidad de mascotas que tiene cada uno (sólo para quien realmente tenga mascota).
-- 7. Apellidos de los propietarios y cantidad de propietarios que tienen ese apellido.
-- 8. Nombres de los dueños y cantidad de mascotas que tiene cada uno (incluyendo quien no tenga mascota).
-- 9. Nombres de los dueños y cantidad de mascotas que tiene cada uno (sólo para los que tengan 2 o más mascotas).
-- 10. Nombre de los dueños cuyo nombre contiene una A y cuyo teléfono empieza por 6, junto con los nombres de sus mascotas (incluso si algún dueño realmente no tiene mascota).
