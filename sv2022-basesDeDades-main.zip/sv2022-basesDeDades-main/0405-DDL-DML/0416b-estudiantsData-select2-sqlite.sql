CREATE TABLE estudiantsData ( 
  nia NUMERIC(10) PRIMARY KEY, 
  nom VARCHAR(25), 
  cognoms VARCHAR(50), 
  dataNaixement DATE,
  email VARCHAR(100)
);

INSERT INTO estudiantsData VALUES (23, 'Michael', 'Jordan', '1963-02-17', 'michael@jordan.com'); 
INSERT INTO estudiantsData VALUES (32, 'Earvin', 'Johnson', '1959-08-14', 'magic@johnson.com');

-- Afig tres (o més) dades d'exemple

INSERT INTO estudiantsData VALUES (34, 'Hakeem', 'Olajuwon', '1963-01-21', 'hakeem@olaju.com');
INSERT INTO estudiantsData VALUES (11, 'Isaiah', 'Thomas', NULL, NULL);
INSERT INTO estudiantsData (nia, nom, cognoms) VALUES (33, 'Larry', 'Bird');
INSERT INTO estudiantsData (nom, cognoms, nia, dataNaixement ) VALUES ('Dominique', 'Wilkins', 21, '1960-01-12');

-- ==========================================

-- Funcions de data en SQLite: https://www.sqlite.org/lang_datefunc.html

-- Mostra els cognoms, el nom i la data que era 10 dies després que nasquera cada alumne.

SELECT nom, cognoms, date( julianday(dataNaixement) + 10) FROM estudiantsData;

-- Mostra (els cognoms, el nom i) la data que era 2 mesos després que nasquera cada alumne.

SELECT nom, cognoms, date( dataNaixement,'+2 months')  FROM estudiantsData;

-- Mostra els mesos que han transcorregut entre la data actual i la data de naixement de cada estudiant.

-- Aproximat, suposant 30 dies per mes
SELECT nom, cognoms, (julianday('now')-julianday(dataNaixement))/30 AS mesos  FROM estudiantsData;

-- Mostra l'edat que els alumnes tenen actualment.

SELECT nom, cognoms, (julianday('now')-julianday(dataNaixement))/365 AS edat  FROM estudiantsData;

-- Mostra (els cognoms, el nom i) l'edat que els alumnes tenien el 2 de març de 2010.
 
SELECT nom, cognoms, (julianday('2010-03-02')-julianday(dataNaixement))/365 AS edat  FROM estudiantsData;

-- Mostra quants dies faltaven fins a final de mes quan van nàixer els estudiants.

SELECT nom, cognoms, 
    julianday(date( dataNaixement,'start of month','+1 month','-1 day')) -
    julianday(dataNaixement)
FROM estudiantsData;
