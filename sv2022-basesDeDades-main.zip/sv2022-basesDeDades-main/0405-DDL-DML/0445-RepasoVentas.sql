-- Clientes, comerciales, pedidos

CREATE TABLE cliente (
  id NUMERIC(6) PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido1 VARCHAR(100) NOT NULL,
  apellido2 VARCHAR(100),
  ciudad VARCHAR(100),
  categoria NUMERIC(3)
);

CREATE TABLE comercial (
  id NUMERIC(5) PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido1 VARCHAR(100) NOT NULL,
  apellido2 VARCHAR(100),
  comisión NUMERIC(5,2)
);

CREATE TABLE pedido (
  id NUMERIC(7) PRIMARY KEY,
  total NUMERIC(12,2) NOT NULL,
  fecha DATE,
  id_cliente NUMERIC(6),
  id_comercial NUMERIC(5),
  FOREIGN KEY (id_cliente) REFERENCES cliente(id),
  FOREIGN KEY (id_comercial) REFERENCES comercial(id)
);

INSERT INTO cliente VALUES(1, 'Aarón', 'Rivero', 'Gómez', 'Almería', 100);
INSERT INTO cliente VALUES(2, 'Adela', 'Salas', 'Díaz', 'Granada', 200);
INSERT INTO cliente VALUES(3, 'Adolfo', 'Rubio', 'Flores', 'Sevilla', NULL);
INSERT INTO cliente VALUES(4, 'Adrián', 'Suárez', NULL, 'Jaén', 300);
INSERT INTO cliente VALUES(5, 'Marcos', 'Loyola', 'Méndez', 'Almería', 200);
INSERT INTO cliente VALUES(6, 'María', 'Santana', 'Moreno', 'Cádiz', 100);
INSERT INTO cliente VALUES(7, 'Pilar', 'Ruiz', NULL, 'Sevilla', 300);
INSERT INTO cliente VALUES(8, 'Pepe', 'Ruiz', 'Santana', 'Huelva', 200);
INSERT INTO cliente VALUES(9, 'Guillermo', 'López', 'Gómez', 'Granada', 225);
INSERT INTO cliente VALUES(10, 'Daniel', 'Santana', 'Loyola', 'Sevilla', 125);

INSERT INTO comercial VALUES(1, 'Daniel', 'Sáez', 'Vega', 0.15);
INSERT INTO comercial VALUES(2, 'Juan', 'Gómez', 'López', 0.13);
INSERT INTO comercial VALUES(3, 'Diego','Flores', 'Salas', 0.11);
INSERT INTO comercial VALUES(4, 'Marta','Herrera', 'Gil', 0.14);
INSERT INTO comercial VALUES(5, 'Antonio','Carretero', 'Ortega', 0.12);
INSERT INTO comercial VALUES(6, 'Manuel','Domínguez', 'Hernández', 0.13);
INSERT INTO comercial VALUES(7, 'Antonio','Vega', 'Hernández', 0.11);
INSERT INTO comercial VALUES(8, 'Alfredo','Ruiz', 'Flores', 0.05);

INSERT INTO pedido VALUES(1, 150.5, '2017-10-05', 5, 2);
INSERT INTO pedido VALUES(2, 270.65, '2016-09-10', 1, 5);
INSERT INTO pedido VALUES(3, 65.26, '2017-10-05', 2, 1);
INSERT INTO pedido VALUES(4, 110.5, '2016-08-17', 8, 3);
INSERT INTO pedido VALUES(5, 948.5, '2017-09-10', 5, 2);
INSERT INTO pedido VALUES(6, 2400.6, '2016-07-27', 7, 1);
INSERT INTO pedido VALUES(7, 5760, '2015-09-10', 2, 1);
INSERT INTO pedido VALUES(8, 1983.43, '2017-10-10', 4, 6);
INSERT INTO pedido VALUES(9, 2480.4, '2016-10-10', 8, 3);
INSERT INTO pedido VALUES(10, 250.45, '2015-06-27', 8, 2);
INSERT INTO pedido VALUES(11, 75.29, '2016-08-17', 3, 7);
INSERT INTO pedido VALUES(12, 3045.6, '2017-04-25', 2, 1);
INSERT INTO pedido VALUES(13, 545.75, '2019-01-25', 6, 1);
INSERT INTO pedido VALUES(14, 145.82, '2017-02-02', 6, 1);
INSERT INTO pedido VALUES(15, 370.85, '2019-03-11', 1, 5);
INSERT INTO pedido VALUES(16, 2389.23, '2019-03-11', 1, 5);


-- Consultas sobre una tabla

-- 1. Devuelve un listado con todos los pedidos que se han realizado,
-- ordenados de más reciente a más antiguo.

-- 2. Devuelve todos los datos de los dos pedidos de mayor valor.

-- 3. Devuelve un listado con los identificadores de los clientes que han 
-- realizado algún pedido. No muestres los que estén repetidos.

-- 4. Devuelve un listado de todos los pedidos que se realizaron durante el
-- año 2017, cuya importe total sea superior a 500€.

-- 5. Devuelve un listado con el nombre y los apellidos de los comerciales que 
-- tienen una comisión entre 0.05 y 0.11, de dos formas distintas.

-- 6. Devuelve el valor de la comisión de mayor valor que existe en la 
-- tabla comercial.

-- 7. Identificador, nombre y primer apellido de aquellos clientes cuyo
-- segundo apellido conocemos. Ordénalo por apellidos y nombre.

-- 8. Nombres de clientes que empiezan por A y terminan por n, junto con 
-- los nombres que empiezan por P, ordenado alfabéticamente.


-- Consultas multitabla (Composición interna)

-- 9. Listado con el identificador, nombre y los apellidos de todos los 
-- clientes que han realizado algún pedido. El listado debe estar ordenado
-- alfabéticamente y se deben eliminar los elementos repetidos.

-- 10. Listado de todos los clientes, con los pedidos que han realizado y 
-- con los datos de los comerciales asociados a cada pedido.

-- 11. Nombre y apellidos de todos los comerciales que ha participado en 
-- algún pedido realizado por María Santana Moreno.


-- Consultas multitabla (Composición externa)

-- 12. Devuelve un listado con todos los clientes junto con los datos de los pedidos 
-- que han realizado. Este listado también debe incluir los clientes que no han 
-- realizado ningún pedido. El listado debe estar ordenado alfabéticamente por el 
-- primer apellido, segundo apellido y nombre de los clientes.

-- 13. Clientes que no han realizado ningún pedido, de (al menos) 2 formas distintas.

-- 14. Devuelve un listado con los clientes que no han realizado ningún pedido y de 
-- los comerciales que no han participado en ningún pedido. Ordene el listado 
-- alfabéticamente por los apellidos y el nombre. En en listado deberá diferenciar 
-- de algún modo los clientes y los comerciales.


-- Consultas resumen

-- 15. Calcula el importe total que suman todos los pedidos que aparecen en 
-- la tabla pedido.

-- 16. Calcula el número total de comerciales distintos que aparecen en la 
-- tabla pedido.

-- 17. Calcula cuál es el mayor importe que aparece en la tabla pedido.

-- 18. Calcula cuál es el máximo valor de los pedidos realizados durante el
-- mismo día para cada uno de los clientes. Muestra el identificador del
-- cliente, nombre, apellidos, la fecha y el valor de la cantidad.

-- 19. Devuelve un listado con el identificador de cliente, nombre y apellidos y
-- el número total de pedidos que ha realizado cada uno de clientes durante el
-- año 2017.


-- Subconsultas

-- 20. Devuelve el número de pedidos en los que ha participado el comercial
-- Daniel Sáez Vega, de 3 formas distintas.

-- 21. Devuelve los datos del cliente que realizó el pedido más caro en el
-- año 2019.

-- 22. Devuelve un listado con los datos de los clientes y los pedidos, de todos los 
-- clientes que han realizado un pedido durante el año 2017 con un valor mayor o 
-- igual al valor medio de los pedidos realizados durante ese mismo año.

-- 23. Devuelve el pedido más caro que existe en la tabla pedido, 
-- de 3 formas distintas.

-- 24. Devuelve un listado de los clientes que no han realizado ningún pedido,
-- de al menos 2 formas distintas.
