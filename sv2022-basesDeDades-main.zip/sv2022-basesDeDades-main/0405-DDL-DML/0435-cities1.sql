-- 1. Ciutat més poblada

SELECT Name
FROM city
WHERE population = 
(
    SELECT MAX(Population)
    FROM city
);

-- 2. Ciutats del mateix país que la ciutat més poblada

SELECT Name 
FROM city 
WHERE CountryCode = 
(
    SELECT CountryCode
    FROM city
    WHERE Population = 
    (
        SELECT MAX(Population)
        FROM city
    )
); 

-- 3. Ciutat menys poblada d'Espanya

SELECT Name, Population
FROM city 
WHERE CountryCode = 'ESP'
AND Population =
(
    SELECT MIN(Population)
    FROM city
    WHERE CountryCode = 'ESP'
);

-- 4. Ciutats menys poblades que totes les d'Espanya

SELECT Name, Population
FROM city 
WHERE Population <
(
    SELECT MIN(Population)
    FROM city
    WHERE CountryCode = 'ESP'
);

-- 5. Ciutats que tenen una X després d'una Z en el seu nom

SELECT Name
FROM city
WHERE LOWER(Name) LIKE '%z%x%';
