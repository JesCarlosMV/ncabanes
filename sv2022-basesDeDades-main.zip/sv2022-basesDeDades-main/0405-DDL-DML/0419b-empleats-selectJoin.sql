CREATE TABLE departaments ( 
  codiDepartament NUMERIC(3) PRIMARY KEY, 
  nom VARCHAR(20)
);

INSERT INTO departaments VALUES ('31', 'Vendes');
INSERT INTO departaments VALUES ('33', 'Enginyeria');
INSERT INTO departaments VALUES ('34', 'Producció');
INSERT INTO departaments VALUES ('35', 'Màrqueting');

CREATE TABLE empleats ( 
  codiEmpleat VARCHAR(5) PRIMARY KEY, 
  cognom VARCHAR(25),
  codiDepartament NUMERIC(3),
  FOREIGN KEY (codiDepartament) REFERENCES departaments(codiDepartament)
);

INSERT INTO empleats VALUES ('ra', 'Rafferty', 31);
INSERT INTO empleats VALUES ('jo', 'Jordan', 33);
INSERT INTO empleats VALUES ('st', 'Steinberg', 33);
INSERT INTO empleats VALUES ('ro', 'Robinson', 34);
INSERT INTO empleats VALUES ('s', 'Smith', 34);
INSERT INTO empleats VALUES ('ga', 'Gaspar', 36);  -- No vàlid si es defineix una Foreign Key
INSERT INTO empleats VALUES ('ry', 'Ryan', NULL);

-- Consulta "normal"

SELECT * 
FROM empleats, departaments 
WHERE empleats.codiDepartament = departaments.codiDepartament;

-- Versió amb JOIN

SELECT * 
FROM empleats INNER JOIN departaments 
ON empleats.codiDepartament = departaments.codiDepartament;

-- Empleats i departaments (fins i tot els empleats sense departament)

SELECT * 
FROM empleats LEFT OUTER JOIN departaments 
ON empleats.codiDepartament = departaments.codiDepartament;

-- Empleats i departaments (fins i tot els departaments sense empleats)

SELECT * 
FROM empleats RIGHT OUTER JOIN departaments 
ON empleats.codiDepartament = departaments.codiDepartament;

-- Sintaxi alternativa

SELECT * 
FROM departaments LEFT OUTER JOIN empleats
ON empleats.codiDepartament = departaments.codiDepartament;

-- Empleats (fins i tot sense departament)
-- i departaments (fins i tot sense empleats)

SELECT * 
FROM empleats FULL JOIN departaments 
ON empleats.codiDepartament = departaments.codiDepartament;

-- Producte cartesià

SELECT * 
FROM empleats CROSS JOIN departaments;

-- Sintaxi alternativa a INNER JOIN, si els noms dels camps coincideixen

SELECT * FROM empleats NATURAL JOIN departaments;

