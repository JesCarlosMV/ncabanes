-- En la taula de Jocs (04.28):
-- 
-- - Afig un camp horesJugades (número 4 + 2 xifres)

ALTER TABLE jocs
ADD horesJugades NUMBER(6, 2);

ALTER TABLE jocs
ADD COLUMN horesJugades NUMBER(6, 2);

-- Amb parèntesi: vàlid en Oracle però no en SQLite
ALTER TABLE jocs
ADD (horesJugades NUMBER(6, 2));


-- - Canvia de nom el camp dataLlancament a dataLlanc

ALTER TABLE jocs
RENAME dataLlancament TO dataLlanc;

ALTER TABLE jocs
RENAME COLUMN dataLlancament TO dataLlanc;


-- - Canvia la quantitat de lletres de la descripció: ha de ser 500 en comptes de 1000

-- No en SQLite
ALTER TABLE jocs
MODIFY (descripcio VARCHAR2(500));


-- - Afig una restricció al camp horesJugades: ha de ser menor de 5000

-- No en SQLite
ALTER TABLE jocs
ADD CONSTRAINT ck_jocs_horesJugades CHECK (horesJugades < 5000);


-- - Esborra el camp horesJugades

ALTER TABLE jocs
DROP COLUMN horesJugades;

-- No en Oracle
ALTER TABLE jocs
DROP horesJugades;


-- Comprovar resultats, en Oracle:

DESCRIBE jocs;

-- ---------------

-- En la tabla de Juegos:
-- 
-- - Añade un campo horasJugadas (número 4 + 2 cifras)
-- - Renombra el campo anyoLanzamiento a anyoLanz
-- - Cambia la cantidad de letras de la descripción: debe ser 500 en vez de 1000
-- - Añade una restricción al campo horasJugadas: debe ser menor de 5000
-- - Borra el campo horasJugadas
