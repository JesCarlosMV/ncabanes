-- Crea una taula Plataformes, per a anotar dades de plataformes de videojocs (per exemple, consoles), amb camps:
-- 
-- - Codi, de 4 lletres, clau
-- - Nom, de fins a 30 lletres, no nul
-- 
-- Crea també una taula Jocs, amb camps:
-- 
-- - Codi, de 5 lletres, clau
-- - Nom, de fins a 50 lletres, no nul
-- - Descripció, de fins a 1000 lletres
-- - Data de llançament, data
-- - Espai ocupat en GB, 4 xifres abans de la coma i 3 després
-- - Codi de plataforma, clau aliena a la taula anterior.
-- 
-- Usa la sintaxi de Oracle.

CREATE TABLE plataformes(
    codi CHAR(4), 
    nom VARCHAR2(30),
    CONSTRAINT pk_plataformes PRIMARY KEY (codi)
);

CREATE TABLE jocs(
    codi CHAR(5), 
    nom VARCHAR2(50),
    descripcio VARCHAR2(1000),
    dataLlancament DATE,
    espaiOcupat NUMBER(7,3), 
    codiPlataforma CHAR(4), 
    CONSTRAINT pk_jocs PRIMARY KEY (codi),
    CONSTRAINT fk_plataformes 
        FOREIGN KEY (codiPlataforma) REFERENCES plataformes(codi)
); 


-- ---------------

-- Crea una tabla Plataformas, para anotar datos de plataformas de videojuegos (por ejemplo, consolas), con campos:
-- 
-- - Código, de 4 letras
-- - Nombre, de hasta 30 letras
-- 
-- Crea también una tabla Juegos, con campos:
-- 
-- - Código, de 5 letras
-- - Nombre, de hasta 50 letras
-- - Descripción, de hasta 1000 letras
-- - Fecha de lanzamiento, fecha
-- - Espacio ocupado en GB, 4 cifras antes de la coma y 3 después
-- - Código de plataforma, clave ajena a la tabla anterior.
-- 
-- Usa la sintaxis de Oracle.
