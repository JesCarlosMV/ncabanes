-- A partir de la taula de revistes i la taula d'articles que tens detallades més a baix, i de les seues dades d'exemple, troba:
-- 
-- 1. Nom de les revistes de l'any 1988.

SELECT nom FROM revistes WHERE anyPubli = 1988;

-- 2. Títol dels articles la valoració dels quals no siga 10.

SELECT titol FROM articles WHERE valoracio <> 10;

-- 3. Nom, any i mes de les revistes el nom de les quals continga la paraula "Amstrad".

SELECT nom, anyPubli, mesPubli FROM revistes WHERE nom LIKE '%Amstrad%';

-- 4. Títol dels articles per als quals encara no tenim una descripció.

SELECT titol FROM articles WHERE descripcio IS NULL;

-- 5. Nom de les revistes que tenim dels anys 1987 a 1989, tots dos inclusivament, ordenades alfabèticament.

SELECT nom
FROM revistes 
WHERE anyPubli BETWEEN 1987 AND 1989
ORDER BY nom;

-- 6. Títol dels articles al costat del nom, mes i any de la revista en què apareixen, ordenat de més recent a més antic (per any i per mes, descendent).

SELECT titol, nom, mesPubli, anyPubli 
FROM articles, revistes
WHERE articles.codiRevista = revistes.codi
ORDER BY anyPubli DESC, mesPubli DESC;

-- 7. Valoració mitjana dels articles que tenim (amb l'àlies valoracMitjana).

SELECT AVG(valoracio) AS valoracMitajana 
FROM articles;

-- 8. Quantitat de revistes de cada categoria.

SELECT categ, COUNT(*)
FROM revistes
GROUP BY categ;

-- 9. Quantitat d'articles en cada revista, per a les quals tenen 2 o més, ordenat de major a menor quantitat d'article.

SELECT nom, COUNT(*)
FROM articles, revistes
WHERE articles.codiRevista = revistes.codi
GROUP BY nom
ORDER BY COUNT(*) DESC;

-- 10. Nom, mes i any de la revista que té l'article més ben valorat.

SELECT nom, mesPubli, anyPubli 
FROM revistes
WHERE codi = 
(
    SELECT codiRevista FROM articles
    WHERE valoracio = 
        (
            SELECT MAX(valoracio) FROM articles
        )
);

-- -----------------------------------

-- Creacio de taules

CREATE TABLE revistes(
    codi CHAR(5), 
    nom VARCHAR2(30) NOT NULL,
    categ VARCHAR2(20),
    anyPubli NUMBER(4),
    mesPubli NUMBER(2),
    CONSTRAINT pk_revistes PRIMARY KEY (codi),
    CONSTRAINT uk_revistes_num UNIQUE (nom),
    CONSTRAINT ck_revistes_any CHECK(anyPubli BETWEEN 1940 AND 2040),
    CONSTRAINT ck_revistes_mes CHECK(mesPubli BETWEEN 1 AND 12)
);

CREATE TABLE articles(
    codi VARCHAR2(15), 
    titol VARCHAR2(50),
    descripcio VARCHAR2(1000),
    subCateg VARCHAR2(20),
    valoracio NUMBER(3,1), 
    codiRevista CHAR(5), 
    CONSTRAINT pk_articles PRIMARY KEY (codi),
    CONSTRAINT fk_articles 
        FOREIGN KEY (codiRevista) REFERENCES revistes(codi)
); 

INSERT INTO revistes VALUES(
    'AU34', 'Amstrad User 34', 'Informática personal', 1988, 7);
INSERT INTO revistes VALUES(
    'MIO2', 'Muy Interesante Ordenadores 2', 'Divulgación', 1984, NULL);
    
INSERT INTO articles VALUES(
    'IJK', 'Interface de Joystick Kempston', NULL, 'Hardware', 8.5, 'AU34');
INSERT INTO articles VALUES(
    'RC64', 'Radiografía del Commodore 64', NULL, 'Hardware', 10, 'MIO2');
INSERT INTO articles VALUES(
    '80186', 'El 16 bits más potente del mundo', 
    'Detalles de arquitectura del Intel 80186', 'Hardware', 9, 'MIO2');
INSERT INTO articles VALUES(
    'CM00', 'Chessmaster 2000', 
    'Review de la versión de Chessmaster 2000 para PC', 
    'Reviews de juegos', 9, 'AU34');

-- ---------------

-- A partir de la tabla de revistas y la tabla de artículos que tienes detalladas más abajo, y de sus datos de ejemplo, halla:
-- 
-- 1. Nombre de las revistas del año 1988.
-- 2. Título de los artículos cuya valoración no sea 10.
-- 3. Nombre, año y mes de las revistas cuyo nombre contenga la palabra "Amstrad".
-- 4. Título de los artículos para los cuales aún no tenemos una descripción.
-- 5. Nombre de las revistas que tenemos de los años 1987 a 1989, ambos inclusive, ordenadas alfabéticamente.
-- 6. Título de los artículos junto al nombre, mes y año de la revista en que aparecen, ordenado de más reciente a más antiguo (por año y por mes, descendente).
-- 7. Valoración media de los artículos que tenemos (con el alias valoracMedia).
-- 8. Cantidad de revistas de cada categoría.
-- 9. Cantidad de artículos en cada revista, para las que tienen 2 o más, ordenado de mayor a menor cantidad de artículo.
-- 10. Nombre, mes y año de la revista que tiene el artículo mejor valorado.

