CREATE TABLE fabricantes (
  id number PRIMARY KEY,
  nombre VARCHAR2(100) NOT NULL
);

CREATE TABLE productos (
  id number PRIMARY KEY,
  nombre VARCHAR2(100) NOT NULL,
  precio number NOT NULL,
  id_fabricante number NOT NULL,
  FOREIGN KEY (id_fabricante) REFERENCES fabricantes(id)
);

INSERT INTO fabricantes VALUES(1, 'Asus');
INSERT INTO fabricantes VALUES(2, 'Lenovo');
INSERT INTO fabricantes VALUES(3, 'Hewlett-Packard');
INSERT INTO fabricantes VALUES(4, 'Samsung');
INSERT INTO fabricantes VALUES(5, 'Seagate');
INSERT INTO fabricantes VALUES(6, 'Crucial');
INSERT INTO fabricantes VALUES(7, 'Gigabyte');
INSERT INTO fabricantes VALUES(8, 'Huawei');
INSERT INTO fabricantes VALUES(9, 'Xiaomi');

INSERT INTO productos VALUES(1, 'Disco duro SATA3 1TB', 86.99, 5);
INSERT INTO productos VALUES(2, 'Memoria RAM DDR4 8GB', 120, 6);
INSERT INTO productos VALUES(3, 'Disco SSD 1 TB', 150.99, 4);
INSERT INTO productos VALUES(4, 'GeForce GTX 1050Ti', 185, 7);
INSERT INTO productos VALUES(5, 'GeForce GTX 1080 Xtreme', 755, 6);
INSERT INTO productos VALUES(6, 'Monitor 24 LED Full HD', 202, 1);
INSERT INTO productos VALUES(7, 'Monitor 27 LED Full HD', 245.99, 1);
INSERT INTO productos VALUES(8, 'Portátil Yoga 520', 559, 2);
INSERT INTO productos VALUES(9, 'Portátil Ideapd 320', 444, 2);
INSERT INTO productos VALUES(10, 'Impresora HP Deskjet 3720', 59.99, 3);
INSERT INTO productos VALUES(11, 'Impresora HP Laserjet Pro M26nw', 180, 3);

-- 1.Lista el nombre de todos los productos que hay en la tabla producto.

select nombre from productos;

-- 2.Lista los nombres y los precios de todos los productos de la tabla producto.

select nombre,precio from productos;

-- 3.Lista todas las columnas de la tabla producto.

select * from productos;

-- 4.Lista el nombre de los productos, el precio en euros y el precio en 
-- dólares estadounidenses (USD).

select nombre, precio, precio*1.07 from productos;

-- 5.Lista el nombre de los productos, el precio en euros y el precio en 
-- dólares estadounidenses (USD). Utiliza los siguientes alias para las columnas: 
-- nombre de producto, euros, dólares.

select nombre as nombreDeProducto, precio as euros, precio*1.07 as dolares from productos;

-- 6.Lista los nombres y los precios de todos los productos de la tabla 
-- producto, convirtiendo los nombres a mayúscula.

select upper(nombre) as producto, precio from productos;

-- 7.Lista los nombres y los precios de todos los productos de la tabla 
-- producto, convirtiendo los nombres a minúscula.

select lower(nombre) as producto, precio from productos;

-- 8.Lista el nombre de todos los fabricantes en una columna, y en otra columna 
-- obtenga en mayúsculas los dos primeros caracteres del nombre del fabricante.

select nombre, upper(substr(nombre,1,2)) from fabricantes;

-- 9.Lista los nombres y los precios de todos los productos de la tabla 
-- producto, redondeando el valor del precio.

select nombre, round(precio) from productos;

-- 10.Lista los nombres y los precios de todos los productos de la tabla 
-- producto, truncando el valor del precio para mostrarlo sin ninguna cifra 
-- decimal.

select nombre, trunc(precio) from productos;

-- 11.Lista el identificador de los fabricantes que tienen productos en la 
-- tabla producto.

select id_fabricante from productos where id_fabricante is not null;

-- 12.Lista el identificador de los fabricantes que tienen productos en la 
-- tabla producto, eliminando los identificadores que aparecen repetidos.

select distinct id_fabricante from productos where id_fabricante is not null;

-- 13.Lista los nombres de los fabricantes ordenados de forma ascendente.

select nombre from fabricantes order by nombre;

-- 14.Lista los nombres de los fabricantes ordenados de forma descendente.

select nombre from fabricantes order by nombre desc;

-- 15.Lista los nombres de los productos ordenados en primer lugar por el 
-- nombre de forma ascendente y en segundo lugar por el precio de forma 
-- descendente.

select nombre from productos order by nombre asc, precio desc;

-- 16.Devuelve una lista con las 5 primeras filas de la tabla fabricante.

select * from fabricantes where rownum <= 5;

select * from fabricantes fetch next 5 rows only;

select * from fabricantes limit 5;

-- 17.Devuelve una lista con 2 filas a partir de la cuarta fila de la tabla 
-- fabricante. La cuarta fila también se debe incluir en la respuesta.

select *
from fabricantes
offset 3 rows fetch next 2 rows only;

select *
from fabricantes
limit 2 offset 3;

-- 18.Lista el nombre y el precio del producto más barato. (Utilice solamente 
-- las cláusulas ORDER BY y LIMIT)

select nombre, precio from productos
order by precio
rows fetch next 1 rows only;

select nombre, precio from productos
order by precio
limit 1;

-- 19.Lista el nombre y el precio del producto más caro. (Utilice solamente las 
-- cláusulas ORDER BY y LIMIT)

select nombre,precio from productos
order by precio desc
offset 0 rows fetch next 1 rows only;

select nombre,precio from productos
order by precio desc
limit 1;

-- 20.Lista el nombre de todos los productos del fabricante cuyo identificador 
-- de fabricante es igual a 2.

select nombre from productos where id_fabricante=2;

-- 21.Lista el nombre de los productos que tienen un precio menor o igual a 120€.

select nombre from productos where precio <= 120;

-- 22.Lista el nombre de los productos que tienen un precio mayor o igual a 400€.

select nombre from productos where precio >= 400;

-- 23.Lista el nombre de los productos que no tienen un precio mayor o igual a 400€.

select nombre from productos where not (precio >= 400);

-- 24.Lista todos los productos que tengan un precio entre 80€ y 300€. Sin 
-- utilizar el operador BETWEEN.

select * from productos where precio >= 80 and precio <= 300;

-- 25.Lista todos los productos que tengan un precio entre 60€ y 200€. 
-- Utilizando el operador BETWEEN.

select * from productos where precio between 60 and 200;

-- 26.Lista todos los productos que tengan un precio mayor que 200€ y que el 
-- identificador de fabricante sea igual a 6.

select * from productos where precio>200 and id_fabricante=6;

-- 27.Lista todos los productos donde el identificador de fabricante sea 1, 3 o 
-- 5. Sin utilizar el operador IN.

select * from productos 
where id_fabricante=1 or id_fabricante=3 or id_fabricante=5;

-- 28.Lista todos los productos donde el identificador de fabricante sea 1, 3 o 
-- 5. Utilizando el operador IN.

select * from productos where id_fabricante in(1,3,5);

-- 29.Lista el nombre y el precio de los productos en céntimos (Habrá que 
-- multiplicar por 100 el valor del precio). Cree un alias para la columna que 
-- contiene el precio que se llame céntimos.

select nombre,precio*100 as centimos from productos;

-- 30.Lista los nombres de los fabricantes cuyo nombre empiece por la letra S.

select nombre from fabricantes where nombre like 'S%';

-- 31.Lista los nombres de los fabricantes cuyo nombre termine por la vocal e.

select nombre from fabricantes where nombre like '%e';

-- 32.Lista los nombres de los fabricantes cuyo nombre contenga el carácter w.

select nombre from fabricantes where nombre like '%w%';

-- 33.Lista los nombres de los fabricantes cuyo nombre sea de 4 caracteres.

select nombre from fabricantes where length(nombre)=4;

-- 34.Devuelve una lista con el nombre de todos los productos que contienen la 
-- cadena Portátil en el nombre.

select nombre from productos where nombre like '%Portátil%';

-- 35.Devuelve una lista con el nombre de todos los productos que contienen la 
-- cadena Monitor en el nombre y tienen un precio inferior a 215 €.

select nombre from productos where nombre like '%Monitor%' and precio < 215;

-- 36.Lista el nombre y el precio de todos los productos que tengan un precio 
-- mayor o igual a 180€. Ordene el resultado en primer lugar por el precio (en 
-- orden descendente) y en segundo lugar por el nombre (en orden ascendente).

select nombre,precio from productos where precio >= 180
order by precio desc,nombre asc;
