-- Mascotas
-- Inspirado en "menagerie-db", un ejemplo de la documentación de MySQL
-- Sintaxis de SQLite / MySQL (las fechas fallarán en Oracle si no se usa TO_DATE)

CREATE TABLE mascotas
(
  codigo CHAR(3) PRIMARY KEY,
  nombre VARCHAR(20),
  propietario VARCHAR(20),
  especie VARCHAR(20),
  genero CHAR(1),
  nacimiento DATE
);

CREATE TABLE eventos
(
  codigoMascota CHAR(3),
  fecha DATE,
  tipo VARCHAR(15),
  asistentes NUMERIC(4),
  observaciones VARCHAR(255),
  PRIMARY KEY(codigoMascota, fecha),
  FOREIGN KEY(codigoMascota) REFERENCES mascotas(codigo)
);

-- Versiones para SQLite/MySQL de los INSERT:

INSERT INTO mascotas VALUES('f','Fluffy','Harold','gato','h','1993-02-04');
INSERT INTO mascotas VALUES('cl','Claws','Gwen','gato','m','1994-03-17');
INSERT INTO mascotas VALUES('bu','Buffy','Harold','perro','h','1989-05-13');
INSERT INTO mascotas VALUES('fa','Fang','Benny','perro','m','1990-08-27');
INSERT INTO mascotas VALUES('bo','Bowser','Diane','perro','m','1979-08-31');
INSERT INTO mascotas VALUES('ch','Chirpy','Gwen','pájaro','h','1998-09-11');
INSERT INTO mascotas VALUES('w','Whistler','Gwen','pájaro',NULL,'1997-12-09');
INSERT INTO mascotas VALUES('s','Slim','Benny','serpiente','m','1996-04-29');

INSERT INTO eventos VALUES('f','1995-05-15','camada',2,'3 gatitas, 1 gatito');
INSERT INTO eventos VALUES('bu','1993-06-23','camada',5,'2 perritas, 3 perritos');
INSERT INTO eventos VALUES('bu','1994-06-19','camada',5,'3 perritas');
INSERT INTO eventos VALUES('ch','1999-03-21','veterinario',1,'herida en el pico');
INSERT INTO eventos VALUES('bo','1991-10-12','caseta',NULL,NULL);
INSERT INTO eventos VALUES('fa','1991-10-12','caseta',NULL,NULL);
INSERT INTO eventos VALUES('fa','1998-08-28','cumpleaños',12,NULL);
INSERT INTO eventos VALUES('cl','1998-03-17','cumpleaños',NULL,NULL);
INSERT INTO eventos VALUES('w','1998-12-09','cumpleaños',11,'Primer cumpleaños');

-- Versiones para Oracle de los INSERT:

INSERT INTO mascotas VALUES('f','Fluffy','Harold','gato','h',TO_DATE('1993-02-04', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('cl','Claws','Gwen','gato','m',TO_DATE('1994-03-17', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('bu','Buffy','Harold','perro','h',TO_DATE('1989-05-13', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('fa','Fang','Benny','perro','m',TO_DATE('1990-08-27', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('bo','Bowser','Diane','perro','m',TO_DATE('1979-08-31', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('ch','Chirpy','Gwen','pájaro','h',TO_DATE('1998-09-11', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('w','Whistler','Gwen','pájaro',NULL,TO_DATE('1997-12-09', 'YYYY-MM-DD'));
INSERT INTO mascotas VALUES('s','Slim','Benny','serpiente','m',TO_DATE('1996-04-29', 'YYYY-MM-DD'));

INSERT INTO eventos VALUES('f', TO_DATE('1995-05-15', 'YYYY-MM-DD'),'camada',2,'3 gatitas, 1 gatito');
INSERT INTO eventos VALUES('bu',TO_DATE('1993-06-23', 'YYYY-MM-DD'),'camada',5,'2 perritas, 3 perritos');
INSERT INTO eventos VALUES('bu',TO_DATE('1994-06-19', 'YYYY-MM-DD'),'camada',5,'3 perritas');
INSERT INTO eventos VALUES('ch',TO_DATE('1999-03-21', 'YYYY-MM-DD'),'veterinario',1,'herida en el pico');
INSERT INTO eventos VALUES('bo',TO_DATE('1991-10-12', 'YYYY-MM-DD'),'caseta',NULL,NULL);
INSERT INTO eventos VALUES('fa',TO_DATE('1991-10-12', 'YYYY-MM-DD'),'caseta',NULL,NULL);
INSERT INTO eventos VALUES('fa',TO_DATE('1998-08-28', 'YYYY-MM-DD'),'cumpleaños',12,NULL);
INSERT INTO eventos VALUES('cl',TO_DATE('1998-03-17', 'YYYY-MM-DD'),'cumpleaños',NULL,NULL);
INSERT INTO eventos VALUES('w', TO_DATE('1998-12-09', 'YYYY-MM-DD'),'cumpleaños',11,'Primer cumpleaños');

-- 1. Muestra los nombres de las mascotas.

SELECT nombre FROM mascotas;


-- 2. Muestra todos los datos de las mascotas que sean hembra (el campo "genero" tenga el valor "h").

SELECT * FROM mascotas WHERE genero = 'h';


-- 3. Muestra los nombres de las mascotas que sean de especie "gato" o "perro", sin usar IN.

SELECT nombre 
FROM mascotas 
WHERE especie = 'perro' OR especie = 'gato';


-- 4. Muestra los nombres de las mascotas que sean de especie "gato" o "perro", usando IN.

SELECT nombre 
FROM mascotas 
WHERE especie IN ('perro', 'gato');


-- 5. Muestra los nombres de los propietarios, sin duplicados.

SELECT DISTINCT propietario 
FROM mascotas;


-- 6. Muestra los datos de la mascota más vieja, usando LIMIT / FETCH.

-- Versión para SQLite / MySQL

SELECT * FROM mascotas
ORDER BY nacimiento 
LIMIT 1;

-- Versión para Oracle

SELECT * FROM mascotas
ORDER BY nacimiento 
FETCH NEXT 1 ROWS ONLY;


-- 7. Muestra nombre (en mayúsculas) y propietario (en mayúsculas) de las mascotas nacidas en 1996.

-- Versión para SQLite / MySQL, que muestran las fechas como '1979-08-31'

SELECT UPPER(nombre), UPPER(propietario)
FROM mascotas
WHERE SUBSTR(nacimiento,1,4) = '1996';

SELECT UPPER(nombre), UPPER(propietario)
FROM mascotas
WHERE nacimiento LIKE '1996%';

-- Versión para Oracle, que muestra las fechas como '31/08/79' (según config. regional)

SELECT UPPER(nombre), UPPER(propietario)
FROM mascotas
WHERE SUBSTR(nacimiento,7,2) = '96';

SELECT UPPER(nombre), UPPER(propietario)
FROM mascotas
WHERE nacimiento LIKE '%96';


-- 8. Muestra nombre y propietario de las mascotas nacidas entre 1993 y 1997, ambos inclusive, ordenado por propietario, y, si éste coincide, por nombre de la mascota. Debes usar BETWEEN. 

-- Versión para SQLite / MySQL

SELECT nombre, propietario
FROM mascotas
WHERE nacimiento BETWEEN '1993-01-01' AND '1997-12-31'
ORDER BY propietario, nombre;

-- Versión para Oracle

SELECT nombre, propietario
FROM mascotas
WHERE nacimiento 
    BETWEEN TO_DATE('1993-01-01', 'YYYY-MM-DD')
    AND TO_DATE('1997-12-31', 'YYYY-MM-DD')
ORDER BY propietario, nombre;


-- 9. Muestra nombre y propietario de las mascotas nacidas entre 1993 y 1997, ambos inclusive, ordenado por propietario, y, si éste coincide, por nombre de la mascota. No debes usar BETWEEN. 

-- Versión para SQLite / MySQL

SELECT nombre, propietario
FROM mascotas
WHERE nacimiento >= '1993-01-01'
AND nacimiento <= '1997-12-31'
ORDER BY propietario, nombre;

-- Versión para Oracle

SELECT nombre, propietario
FROM mascotas
WHERE nacimiento >= TO_DATE('1993-01-01', 'YYYY-MM-DD')
AND nacimiento <= TO_DATE('1997-12-31', 'YYYY-MM-DD')
ORDER BY propietario, nombre;


-- 10. Nombre de las mascotas para las que no conocemos el género.

SELECT nombre
FROM mascotas
WHERE genero IS NULL;


-- 11. Nombres de las mascotas cuyo nombre comienza por "F".

SELECT nombre
FROM mascotas
WHERE SUBSTR(nombre,1,1) = 'F';

SELECT nombre
FROM mascotas
WHERE nombre LIKE 'F%';


-- 12. Nombres de las mascotas cuyo nombre contiene una "U" (quizá en minúsculas).

SELECT nombre
FROM mascotas
WHERE LOWER(nombre) LIKE '%u%';

SELECT nombre
FROM mascotas
WHERE INSTR(LOWER(nombre), 'u') > 0;


-- 13. Cantidad de eventos que tenemos registrados.

SELECT COUNT(*) FROM eventos;


-- 14. Cantidad de eventos para los que sabemos la cantidad de asistentes.

SELECT COUNT(asistentes) FROM eventos;


-- 15. Cantidad media de asistentes a los eventos.

SELECT AVG(asistentes) FROM eventos;


-- 16. Nombre de cada mascota, nombre del propietario y fecha en la que ha habido un evento, para las mascotas de las que tenemos anotado algún evento, usando INNER JOIN.

SELECT nombre, propietario, fecha
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota;


-- 17. Nombre de cada mascota, nombre del propietario y fecha en la que ha habido un evento, para las mascotas de las que tenemos anotado algún evento, usando WHERE.

SELECT nombre, propietario, fecha
FROM mascotas, eventos
WHERE mascotas.codigo = eventos.codigoMascota;


-- 18. Nombre de cada mascota, nombre del propietario y fecha en la que ha habido un evento, incluso para las mascotas de las que no tenemos anotado ningún evento.

SELECT nombre, propietario, fecha
FROM mascotas LEFT JOIN eventos
ON mascotas.codigo = eventos.codigoMascota;


-- 19. Nombres de propietarios, junto a la cantidad de mascotas que tiene cada uno, ordenados alfabéticamente.

SELECT propietario, COUNT(*)
FROM mascotas
GROUP BY propietario
ORDER BY propietario;


-- 20. Nombre de cada mascota y nombre del propietario, para las mascotas de las que tenemos anotados 2 o más eventos.

SELECT nombre, propietario
FROM mascotas LEFT JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
GROUP BY nombre, propietario
HAVING COUNT(*) >= 2;


-- 21. Nombres de mascotas, junto a la cantidad de eventos que tenemos de cada uno.

SELECT nombre, COUNT(fecha)
FROM mascotas LEFT JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
GROUP BY nombre;


-- 22. Nombres de mascotas y de propietarios, para las que tenemos algún evento de tipo "camada", sin duplicados.

SELECT DISTINCT nombre, propietario
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
WHERE tipo = 'camada';


-- 23. Nombre de las mascotas para las que no tenemos eventos, usando "IN".

SELECT nombre FROM mascotas WHERE codigo NOT IN 
(
    SELECT codigoMascota FROM eventos
);


-- 24. Nombre de las mascotas para las que no tenemos eventos, usando "COUNT".

SELECT nombre
FROM mascotas LEFT JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
GROUP BY nombre
HAVING COUNT(fecha) = 0;


-- 25. Nombre de la mascota para la que más gente ha asistido a un evento suyo, usando ORDER BY.

-- Versión para SQLite / MySQL

SELECT nombre
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
ORDER BY asistentes DESC LIMIT 1;

-- Versión para Oracle

SELECT nombre
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
ORDER BY asistentes DESC 
FETCH NEXT 1 ROWS ONLY;

-- Si hubiera más de un dato coincidente

SELECT nombre
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
ORDER BY asistentes DESC 
FETCH NEXT 1 ROWS WITH TIES;


-- 26. Nombre de la mascota para la que más gente ha asistido a un evento suyo, usando MAX.

-- Previo 1

SELECT MAX(asistentes) FROM eventos;

-- Previo 2

SELECT codigoMascota FROM eventos 
WHERE asistentes = 
(
    SELECT MAX(asistentes) FROM eventos
);

-- Completo

SELECT nombre
FROM mascotas WHERE codigo =
(
    SELECT codigoMascota FROM eventos 
    WHERE asistentes = 
    (
        SELECT MAX(asistentes) FROM eventos
    )
);


-- 27. Nombre de la mascota para la que más gente ha asistido a un evento suyo, usando ALL.

-- No en SQLite

SELECT nombre
FROM mascotas WHERE codigo =
(
    SELECT codigoMascota FROM eventos 
    WHERE asistentes >= ALL
    (
        SELECT asistentes FROM eventos
    )
);


-- Nota: para que funcione correctamente, todos los campos "asistente" deberían tener valor:

UPDATE eventos SET asistentes = 0 WHERE asistentes IS NULL;


-- 28. Nombre de la mascota (y de su propietario) que tuvo el evento con más visitas en 1998.

-- Versión para SQLite / MySQL

SELECT nombre, propietario
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
WHERE SUBSTR(fecha, 1, 4) = '1998'
ORDER BY asistentes DESC LIMIT 1;

-- Versión para Oracle

SELECT nombre, propietario
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
WHERE SUBSTR(fecha, 7, 2) = '98'
ORDER BY asistentes DESC 
FETCH NEXT 1 ROWS ONLY;


-- 29. Nombre de mascota, tipo de evento y observaciones, para todos los eventos de la mascota que tuvo el evento con más visitas en 1998.

-- Versión para SQLite / MySQL

SELECT nombre, tipo, fecha
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
WHERE codigo =
(
    SELECT codigo
    FROM mascotas INNER JOIN eventos
    ON mascotas.codigo = eventos.codigoMascota
    WHERE SUBSTR(fecha, 1, 4) = '1998'
    ORDER BY asistentes DESC LIMIT 1
);

-- Versión para Oracle

SELECT nombre, tipo, fecha
FROM mascotas INNER JOIN eventos
ON mascotas.codigo = eventos.codigoMascota
WHERE codigo =
(
    SELECT codigo
    FROM mascotas INNER JOIN eventos
    ON mascotas.codigo = eventos.codigoMascota
    WHERE SUBSTR(fecha, 7, 2) = '98'
    ORDER BY asistentes DESC 
    FETCH NEXT 1 ROWS ONLY
);

-- 30. Tipo y observaciones de los eventos que han tenido una cantidad de asistentes por encima de la media de los eventos de su mismo tipo.

SELECT tipo, observaciones FROM eventos e1 WHERE asistentes >
(
    SELECT AVG(asistentes) FROM eventos e2
    WHERE e1.tipo = e2.tipo
);


-- 31. Muestra todos los nombres, tanto de mascotas como de propietarios. Ordena la respuesta alfabéticamente.

-- Previo

SELECT nombre FROM mascotas
UNION
SELECT propietario as nombre FROM mascotas;

-- Completo

SELECT * FROM
(
    SELECT nombre FROM mascotas
    UNION
    SELECT propietario as nombre FROM mascotas
)
ORDER BY nombre;

-- En MySQL:

SELECT * FROM
(
    SELECT nombre FROM mascotas
    UNION
    SELECT propietario as nombre FROM mascotas
) AS resultado
ORDER BY nombre;


-- 32. Añade una nueva mascota, con código 'g' y nombre "Gwen", de la que no sabemos más datos. No debes usar NULL, sino indicar los nombres de los campos.

INSERT INTO mascotas(codigo, nombre) VALUES('g', 'Gwen');


-- 33. Muestra los nombres de mascotas que coincidan con el nombre de algún propietario, usando operaciones de conjuntos.

SELECT nombre FROM mascotas
INTERSECT
SELECT propietario AS nombre FROM mascotas;


-- 34. Muestra los nombres de mascotas que coincidan con el nombre de algún propietario, usando IN.

SELECT nombre FROM mascotas
WHERE nombre IN
(
    SELECT propietario AS nombre FROM mascotas
);


-- 35. Muestra los nombres de mascotas que coincidan con el nombre de algún propietario, usando ANY.

-- No en SQLite

SELECT nombre FROM mascotas
WHERE nombre = ANY
(
    SELECT propietario AS nombre FROM mascotas
);


-- 36. Muestra los nombres de mascotas que coincidan con el nombre de algún propietario, usando EXISTS.

SELECT nombre FROM mascotas m1
WHERE EXISTS
(
    SELECT * FROM mascotas m2
    WHERE m2.propietario = m1.nombre
);


-- 37. Añade un campo "importe" a la tabla de eventos, que será un dato numérico con hasta 4 cifras antes de la coma y de 2 cifras decimales

-- Versión para MySQL / SQLite

ALTER TABLE eventos
ADD importe NUMERIC(6,2);

-- Versión para Oracle

ALTER TABLE eventos
ADD importe NUMBER(6,2);


-- 38. Indica que el importe del evento de fecha '1999-03-21' fue de 50,25.

-- Versión para MySQL / SQLite

UPDATE eventos
SET importe = 50.25
WHERE fecha = '1999-03-21';

-- Versión para Oracle

UPDATE eventos
SET importe = 50.25
WHERE fecha = TO_DATE('1999-03-21', 'YYYY-MM-DD');

SELECT * FROM eventos;


-- 39. Elimina el campo "importe" de la tabla de eventos.

ALTER TABLE eventos DROP COLUMN importe;


-- 40. Borra el registro de la mascota llamada "Gwen".

-- Preferible evitar (el nombre no es único), pero es lo que se pide

DELETE FROM mascotas WHERE nombre = 'Gwen';

-- Deseable si es posible (el código sí es único)

DELETE FROM mascotas WHERE codigo = 'g';
