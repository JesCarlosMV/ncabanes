CREATE TABLE alumnesNotes (
    nom VARCHAR(50), 
    tema VARCHAR(20), 
    nota NUMERIC (5,2),
    PRIMARY KEY (nom, tema));

INSERT INTO alumnesNotes VALUES ('Abraham', 'Tema 1', 9.8);
INSERT INTO alumnesNotes VALUES ('Basilio', 'Tema 1', 7.7);
INSERT INTO alumnesNotes VALUES ('Cecilia', 'Tema 1', 9.8);
INSERT INTO alumnesNotes VALUES ('David', 'Tema 1', 4.3);
INSERT INTO alumnesNotes VALUES ('Elena', 'Tema 1', 8.5);

INSERT INTO alumnesNotes VALUES ('Abraham', 'Tema 2', 10.0);
INSERT INTO alumnesNotes VALUES ('Basilio', 'Tema 2', 7.5);
INSERT INTO alumnesNotes VALUES ('Cecilia', 'Tema 2', 9.4);
INSERT INTO alumnesNotes VALUES ('David', 'Tema 2', 4.1);
INSERT INTO alumnesNotes VALUES ('Elena', 'Tema 2', 8.9);

INSERT INTO alumnesNotes VALUES ('Abraham', 'Tema 3', 8.8);
INSERT INTO alumnesNotes VALUES ('Basilio', 'Tema 3', 7.1);
INSERT INTO alumnesNotes VALUES ('Cecilia', 'Tema 3', 9.9);
INSERT INTO alumnesNotes VALUES ('Elena', 'Tema 3', 9.5);
INSERT INTO alumnesNotes VALUES ('Gerardo', 'Tema 3', 2.1);



-- 1. Alumnos que han sacado la misma nota 
-- que Abraham obtuvo en el Tema 1

-- Previo:

SELECT nota
FROM alumnesNotes
WHERE nom = 'Abraham' AND tema = 'Tema 1';

-- Completo

SELECT nom
FROM alumnesNotes
WHERE nota = (SELECT nota
FROM alumnesNotes
WHERE nom = 'Abraham' AND tema = 'Tema 1');



-- 2. Alumnos que han sacado la misma nota 
-- que Abraham obtuvo en el Tema 1 (y no son Abraham)

SELECT nom
FROM alumnesNotes
WHERE nom <> 'Abraham' 
AND nota = (
    SELECT nota
    FROM alumnesNotes
    WHERE nom = 'Abraham' AND tema = 'Tema 1'
);



-- 3. Alumnos que hayan sacado más nota que la media del Tema 1

-- Previo

SELECT AVG(nota)
FROM alumnesNotes
WHERE tema = 'Tema 1';

-- Completo

SELECT nom, tema, nota
FROM alumnesNotes
WHERE nota > (
    SELECT AVG(nota)
    FROM alumnesNotes
    WHERE tema = 'Tema 1'
);



-- 4. Alumnos cuya nota coincide con alguna de Abraham

-- Previo

SELECT nota
FROM alumnesNotes
WHERE nom = 'Abraham';

-- Completo

SELECT nom, tema, nota
FROM alumnesNotes
WHERE nota IN (
    SELECT nota
    FROM alumnesNotes
    WHERE nom = 'Abraham'
)
AND nom <> 'Abraham';



-- 5. Alumnos que se han presentado al examen del Tema 1.

SELECT nom
FROM alumnesNotes
WHERE tema = 'Tema 1'
AND nota IS NOT NULL;



-- 6. Alumnos que NO se han presentado al examen del Tema 1.

SELECT DISTINCT nom
FROM alumnesNotes
WHERE nom NOT IN
(
    SELECT nom
    FROM alumnesNotes
    WHERE tema = 'Tema 1'
    AND nota IS NOT NULL
);



-- 7. Diferencia de cada nota del tema 1 con la nota media del tema 1.

SELECT nom, nota - (
    SELECT AVG(nota)
    FROM alumnesNotes
    WHERE tema = 'Tema 1'
)
FROM alumnesNotes
WHERE tema = 'Tema 1';



-- 8. Alumno, examen y nota, para las notas (de cualquier examen) 
-- que estén por encima de cualquier nota de Basilio.

-- Previo

SELECT nota 
FROM alumnesNotes
WHERE nom = 'Basilio';

-- Dos formas alternativas

SELECT nom, tema, nota
FROM alumnesNotes
WHERE nota > ALL
(
    SELECT nota 
    FROM alumnesNotes
    WHERE nom = 'Basilio'
);

SELECT nom, tema, nota
FROM alumnesNotes
WHERE nota > 
(
    SELECT MAX(nota)
    FROM alumnesNotes
    WHERE nom = 'Basilio'
);



-- 9. Nombre (sin duplicados) de los alumnos que han sacado alguna nota
-- por encima de todas las de Basilio

SELECT DISTINCT nom
FROM alumnesNotes
WHERE nota > 
(
    SELECT MAX(nota)
    FROM alumnesNotes
    WHERE nom = 'Basilio'
);

