-- Departaments i empleats(1:M)

CREATE TABLE departaments ( 
  codiDepartament NUMERIC(3) PRIMARY KEY, 
  nom VARCHAR(20)
);

INSERT INTO departaments VALUES ('31', 'Vendes');
INSERT INTO departaments VALUES ('33', 'Enginyeria');
INSERT INTO departaments VALUES ('34', 'Producció');
INSERT INTO departaments VALUES ('35', 'Màrqueting');

CREATE TABLE empleats ( 
  codiEmpleat VARCHAR(5) PRIMARY KEY, 
  cognom VARCHAR(25),
  codiDepartament NUMERIC(3),
  FOREIGN KEY (codiDepartament) REFERENCES departaments(codiDepartament)
);

INSERT INTO empleats VALUES ('ra', 'Rafferty', 31);
INSERT INTO empleats VALUES ('jo', 'Jordan', 33);
INSERT INTO empleats VALUES ('st', 'Steinberg', 33);
INSERT INTO empleats VALUES ('ro', 'Robinson', 34);
INSERT INTO empleats VALUES ('s', 'Smith', 34);
