CREATE TABLE estudiantsData ( 
  nia NUMERIC(10) PRIMARY KEY, 
  nom VARCHAR(25), 
  cognoms VARCHAR(50), 
  dataNaixement DATE,
  email VARCHAR(100)
);

INSERT INTO estudiantsData VALUES (23, 'Michael', 'Jordan', TO_DATE( '1963-02-17', 'YYYY-MM-DD'), 'michael@jordan.com'); 
INSERT INTO estudiantsData VALUES (32, 'Earvin', 'Johnson', TO_DATE( '1959-08-14','YYYY-MM-DD'), 'magic@johnson.com');

-- Afig tres (o més) dades d'exemple

INSERT INTO estudiantsData VALUES (34, 'Hakeem', 'Olajuwon', TO_DATE( '1963-01-21','YYYY-MM-DD'), 'hakeem@olaju.com');
INSERT INTO estudiantsData VALUES (11, 'Isaiah', 'Thomas', NULL, NULL);
INSERT INTO estudiantsData (nia, nom, cognoms) VALUES (33, 'Larry', 'Bird');
INSERT INTO estudiantsData (nom, cognoms, nia, dataNaixement ) VALUES ('Dominique', 'Wilkins', 21, TO_DATE( '1960-01-12','YYYY-MM-DD'));

-- ==========================================

-- Mostra els cognoms, el nom i la data que era 10 dies després que nasquera cada alumne.

SELECT nom, cognoms, dataNaixement + 10 FROM estudiantsData;

-- Mostra (els cognoms, el nom i) la data que era 2 mesos després que nasquera cada alumne.

SELECT nom, cognoms, ADD_MONTHS(dataNaixement, 2) FROM estudiantsData;

-- Mostra els mesos que han transcorregut entre la data actual i la data de naixement de cada estudiant.

SELECT nom, cognoms, MONTHS_BETWEEN(SYSDATE, dataNaixement) AS mesos FROM estudiantsData;

-- Mostra l'edat que els alumnes tenen actualment.

SELECT nom, cognoms, MONTHS_BETWEEN(SYSDATE, dataNaixement)/12 AS edat FROM estudiantsData;

SELECT nom, cognoms, (SYSDATE-dataNaixement)/365 AS edat  FROM estudiantsData;

-- Mostra (els cognoms, el nom i) l'edat que els alumnes tenien el 2 de març de 2010.
 
SELECT nom, cognoms, (TO_DATE( '2010-03-02','YYYY-MM-DD')-dataNaixement)/365 AS edat2010 FROM estudiantsData;

-- Mostra quants dies faltaven fins a final de mes quan van nàixer els estudiants.

SELECT nom, cognoms, LAST_DAY(dataNaixement)-dataNaixement FROM estudiantsData;
