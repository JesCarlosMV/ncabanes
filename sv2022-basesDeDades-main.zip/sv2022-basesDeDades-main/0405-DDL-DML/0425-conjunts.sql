-- Operacions de conjunts:
-- UNION, INTERSECT, MINUS

CREATE TABLE directors2(
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(50)
);
    
CREATE TABLE actors2(
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(50)
);

INSERT INTO directors2 VALUES ( 'JC', 'James Cameron');
INSERT INTO directors2 VALUES ( 'RZ', 'Robert Zemeckis');
INSERT INTO directors2 VALUES ( 'CN', 'Christopher Nolan');
INSERT INTO directors2 VALUES ( 'GL', 'George Lucas');
INSERT INTO directors2 VALUES ( 'RS', 'Ridley Scott');
INSERT INTO directors2 VALUES ( 'TS', 'Tony Scott');

INSERT INTO actors2 VALUES('KWI', 'Kate Winslet');
INSERT INTO actors2 VALUES('LDI', 'Leonardo DiCaprio');
INSERT INTO actors2 VALUES('SWO', 'Sam Worthington');
INSERT INTO actors2 VALUES('ZSA', 'Zoe Saldana');
INSERT INTO actors2 VALUES('SWE', 'Sigourney Weaver');
INSERT INTO actors2 VALUES('THA', 'Tom Hanks');
INSERT INTO actors2 VALUES('MFO', 'Michael J. Fox');
INSERT INTO actors2 VALUES('CLL', 'Christopher Lloyd');
INSERT INTO actors2 VALUES('CBA', 'Christian Bale');
INSERT INTO actors2 VALUES('HLE', 'Heath Ledger');
INSERT INTO actors2 VALUES('MHA', 'Mark Hamill');
INSERT INTO actors2 VALUES('HFO', 'Harrison Ford');
INSERT INTO actors2 VALUES('CFI', 'Carrie Fisher');
INSERT INTO actors2 VALUES('MMC', 'Matthew McConaughey');
INSERT INTO actors2 VALUES('AHA', 'Anne Hathaway');
INSERT INTO actors2 VALUES('JCH', 'Jessica Chastain');
INSERT INTO actors2 VALUES('RHA', 'Rutger Hauer');
INSERT INTO actors2 VALUES('MDA', 'Matt Damon');

INSERT INTO actors2 VALUES('BDH', 'Bryce Dallas Howard');
INSERT INTO directors2 VALUES('BDH', 'Bryce Dallas Howard');
INSERT INTO actors2 VALUES('QTA', 'Quentin Tarantino');
INSERT INTO directors2 VALUES('QTA', 'Quentin Tarantino');

-- Mostra tant actors com directors

SELECT nom FROM actors2
UNION
SELECT nom FROM directors2;


-- Mostra els actors que també són directors

SELECT nom FROM actors2
INTERSECT
SELECT nom FROM directors2;

-- O, utiliztant IN i subconsultes

SELECT nom FROM actors2 
WHERE codi IN 
(
    SELECT codi FROM directors2
);


-- Mostra els actors que no són directors

-- Oracle

SELECT nom FROM actors2
MINUS
SELECT nom FROM directors2;

-- SQLite

SELECT nom FROM actors2
EXCEPT
SELECT nom FROM directors2;

-- O, utiliztant IN i subconsultes

SELECT nom FROM actors2 
WHERE codi NOT IN 
(
    SELECT codi FROM directors2
);

-- Per a afegir condicions i/o ordenar, nova subconsulta:

SELECT * FROM 
(
    SELECT nom FROM actors2
    UNION
    SELECT nom FROM directors2
) 
WHERE nom LIKE 'M%'
ORDER BY nom DESC;
