-- 26 gener 2022 - Professors que potser imparteixen cursos (cada curs correspon a un únic professor), als quals potser assisteixen alumnes (cada alumne a un únic curs).
-- 
-- Tres professors: Higinio, Ignacio, Javier
-- Tres cursos: Curso 1 (d'Ignacio, 40 hores), Curso 2 (de Javier, 20 hores), Curso 3 (sense assignar, hores desconegudes), Curso 4 (d'Ignacio, 25 hores)
-- Cinc alumnes: Manuel, Nadia, Otilio, Patricia, que assisteixen al curs "Curso 1". Ramón, que assisteix al curs "Curso 2".


CREATE TABLE Professors (
    codi VARCHAR(3) PRIMARY KEY,
    nom VARCHAR(30)
);

CREATE TABLE Cursos (
    codi NUMERIC(3) PRIMARY KEY,
    nom VARCHAR(30),
    hores NUMERIC(4),
    codiProfessor VARCHAR(5),
    FOREIGN KEY (codiProfessor) REFERENCES Professors(codi)
);

CREATE TABLE Alumnes (
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(30),
    codiCurso NUMERIC(3),
    FOREIGN KEY (codiCurso) REFERENCES Cursos(codi)
);

INSERT INTO Professors VALUES('HIG', 'Higinio');
INSERT INTO Professors VALUES('IGN', 'Ignacio');
INSERT INTO Professors VALUES('JAV', 'Javier');

INSERT INTO Cursos VALUES(1, 'Curso 1', 40, 'IGN');
INSERT INTO Cursos VALUES(2, 'Curso 2', 20, 'JAV');
INSERT INTO Cursos VALUES(3, 'Curso 3', NULL, NULL);
INSERT INTO Cursos VALUES(4, 'Curso 4', 25, 'IGN');

INSERT INTO Alumnes VALUES('MANUE', 'Manuel', 1);
INSERT INTO Alumnes VALUES('NADIA', 'Nadia', 1);
INSERT INTO Alumnes VALUES('OTILI', 'Otilio', 1);
INSERT INTO Alumnes VALUES('PATRI', 'Patricia', 1);
INSERT INTO Alumnes VALUES('RAMON', 'Ramon', 2);

-- 1. Noms dels professors, juntament amb el nom dels cursos que 
-- imparteixen (només per als professors i cursos que realment estan relacionats).

SELECT p.nom, c.nom 
FROM Professors p, Cursos c
WHERE p.codi = codiProfessor;

-- 2. Noms de tots els professors, 
-- juntament amb el nom dels cursos que imparteixen (potser cap).

SELECT p.nom, c.nom
FROM Professors p LEFT OUTER JOIN Cursos c
ON p.codi = codiProfessor;

-- 3. Noms de tots els professors i tots els cursos, 
-- amb les relacions entre ells que existisquen.

SELECT p.nom, c.nom
FROM Professors p FULL OUTER JOIN Cursos c
ON p.codi = codiProfessor;

-- 4. Nom de cada professor, juntament amb el nom del curs que 
-- imparteix (si existeix), juntament amb el nom de cada alumne
-- que assisteix a aqueix curs (si existeix).

SELECT p.nom, c.nom, a.nom
FROM Professors p LEFT OUTER JOIN Cursos c 
ON p.codi = c.codiProfessor
LEFT OUTER JOIN Alumnes a
ON c.codi = a.codiCurso;

-- 5. Duració mitjana dels cursos.

SELECT AVG(hores) AS DuracioMitjana

-- 6. Nom del curs més llarg.

SELECT nom
FROM Cursos
WHERE hores =
(
    SELECT MAX(hores)
    FROM Cursos
);

-- 7. Cursos el nom dels quals conté un 1.

SELECT nom
FROM Cursos 
WHERE nom LIKE '%1%';

-- 8. Alumnes que assisteixen al curs més llarg.

-- Basat en la consulta 6:

SELECT a.nom
FROM Alumnes a, Cursos c
WHERE a.codiCurso = c.codi
AND c.nom = 
(
    SELECT nom
    FROM Cursos
    WHERE hores =
    (
        SELECT MAX(hores)
        FROM Cursos
    )
);

-- 9. Alumnes que no assisteixen al "Curso 2".

-- Previ: alumnes del "Curso 2"

SELECT a.nom
FROM Alumnes a, Cursos c
WHERE a.codiCurso = c.codi
AND c.nom = 'Curso 2';

-- I si eliminem aqueixos del total: 

SELECT nom FROM Alumnes WHERE nom NOT IN
(
    SELECT a.nom
    FROM Alumnes a, Cursos c
    WHERE a.codiCurso = c.codi
    AND c.nom = 'Curso 2'
);

-- 10. Professors que imparteixen més d'un curs.

SELECT p.nom, COUNT(*) AS CursosQuantitat
FROM Professors p, Cursos c 
WHERE p.codi = codiProfessor
GROUP BY p.nom
HAVING COUNT(*) > 1;


-------

-- 26 enero 2022 - Profesores que quizá impartan cursos (cada curso corresponde a un único profesor), a los que quizá asistan alumnos (cada alumno a un único curso).
-- 
-- Tres profesores: Higinio, Ignacio, Javier
-- Tres cursos: Curso 1 (de Ignacio, 40 horas), Curso 2 (de Javier, 20 horas), Curso 3 (sin asignar, horas desconocidas), Curso 4 (de Ignacio, 25 horas)
-- Cinco alumnos: Manuel, Nadia, Otilio, Patricia, que asisten al curso "Curso 1". Ramón, que asiste al curso "Curso 2".
-- 
-- 1. Nombres de los profesores, junto con el nombre de los cursos que imparten (sólo para los profesores y cursos que realmente están relacionados).
-- 
-- 2. Nombres de todos los profesores, junto con el nombre de los cursos que imparten (quizá ninguno).
-- 
-- 3. Nombres de todos los profesores y todos los cursos, con las relaciones entre ellos que existan.
-- 
-- 4. Nombre de cada profesor, junto con el nombre del curso que imparte (si existe), junto con el nombre de cada alumno que asiste a ese curso (si existe).
-- 
-- 5. Duración media de los cursos.
-- 
-- 6. Nombre del curso más largo.
-- 
-- 7. Cursos cuyo nombre contiene un 1.
-- 
-- 8. Alumnos que asisten al curso más largo.
-- 
-- 9. Alumnos que no asisten al curso 2.
-- 
-- 10. Profesores que imparten más de un curso.
