-- A partir de la taula de països (fitxer "wold_country.sql"), has de mostrar:

-- 1. Nom (name) dels països el continent dels quals (continent)
-- és "Africa", ordenats alfabèticament.

SELECT name FROM country
WHERE continent = 'Africa'
ORDER BY name;

-- 2. Països la regió dels quals (region) conté la paraula "Europe" 
-- i la població dels quals (population) és superior a 35 milions (35000000).

SELECT name FROM country
WHERE region LIKE '%Europe%'
AND population > 35000000;

-- 3. Esperança de vida (LifeExpectancy) mitjana dels països 
-- el continent dels quals (continent) és "Asia".

SELECT AVG(LifeExpectancy) FROM country
WHERE continent = 'Asia';

-- 4. Nom (name) i producte nacional brut (GNP) dels *paises 
-- la regió dels quals siga 'Nordic Countries' o 'Baltic Countries',
-- de 2 formes diferents.

SELECT name, gnp FROM country
WHERE region = 'Nordic Countries' OR region = 'Baltic Countries';

SELECT name, gnp FROM country
WHERE region IN ('Nordic Countries', 'Baltic Countries');

-- 5. Quantitat de països en cada continent (continent).

SElECT continent, COUNT(*)
FROM country
GROUP BY continent;

-- 6. Diferència entre el país amb major esperança de vida (LifeExpectancy) 
-- i el país amb menor esperança de vida de cada continent.

SELECT continent, MAX(LifeExpectancy)-MIN(LifeExpectancy)
FROM country
GROUP BY continent;

-- 7. Països  del continent "Asia" el producte nacional brut dels quals (GNP) 
--- està per davall de menor GNP existent en "Europe".

-- Previ: menor d'Europa

SELECT MIN(gnp) FROM country
WHERE continent = 'Europe';

-- Complet

SELECT name, gnp FROM country
WHERE gnp <= (
    SELECT MIN(gnp) FROM country
    WHERE continent = 'Europe'
);

-- 8. Continents en els quals existeix la forma de govern (GovernmentForm) 
-- anomenada "Constitutional Monarchy" però no l'anomenada "Monarchy".

SELECT DISTINCT continent
FROM country
WHERE GovernmentForm = 'Constitutional Monarchy'

EXCEPT

SELECT DISTINCT continent
FROM country
WHERE GovernmentForm = 'Monarchy';

-- 9. Països, que tenint diferent nom (name), tenen aparentment 
-- al mateix governant (HeadOfState).

SELECT c1.name, c2.name FROM country c1, country c2 
WHERE c1.HeadOfState = c2.HeadOfState
AND c1.name <> c2.name;


-- 10. Països la renda per càpita dels quals (GNP / population) o l'esperança de 
-- vida dels quals (LifeExpectancy) siguen superiors als dels Estats Units 
-- ("United States"), ordenats alfabèticament.

-- Previ: GNP superior als Estats Units

SELECT name
FROM country
WHERE gnp/population >
(
    SELECT gnp/population
    FROM country
    WHERE name = 'United States'
);

-- Complet

SELECT * FROM
(
    SELECT name
    FROM country
    WHERE gnp/population >
    (
        SELECT gnp/population
        FROM country
        WHERE name = 'United States'
    )

    UNION

    SELECT name
    FROM country
    WHERE LifeExpectancy >
    (
        SELECT LifeExpectancy
        FROM country
        WHERE name = 'United States'
    )
)
ORDER BY name;

-- -------------------------

-- 1. Nombre (name) de los países cuyo continente (continent) es "Africa", ordenados alfabéticamente.
-- 2. Países cuya región (region) contiene la palabra "Europe" y cuya población (population) es superior a 35 millones (35000000).
-- 3. Esperanza de vida (LifeExpectancy) media de los países cuyo continente (continent) es "Asia".
-- 4. Nombre (name) y producto nacional bruto (GNP) de los paises cuya región sea 'Nordic Countries' o 'Baltic Countries', de 2 formas distintas.
-- 5. Cantidad de países en cada continente (continent).
-- 6. Diferencia entre el país con mayor esperanza de vida (LifeExpectancy) y el país con menor esperanza de vida de cada continente.
-- 7. Paises del continente "Asia" cuyo producto nacional bruto (GNP) está por debajo de menor GNP existente en "Europe".
-- 8. Continentes en los que existe la forma de gobierno (GovernmentForm) llamada "Constitutional Monarchy" pero no la llamada "Monarchy".
-- 9. Paises, que teniendo distinto nombre (name), tienen aparentemente al mismo gobernante (HeadOfState).
-- 10. Paises cuya renta per cápita (GNP / population) o cuya esperanza de vida (LifeExpectancy) sean superiores a los de Estados Unidos ("United States"), ordenados alfabéticamente.
