-- 1. Empleados cuyo apellido empiece por R

SELECT * FROM empleats WHERE UPPER(cognom) LIKE 'R%';

SELECT * FROM empleats WHERE UPPER(SUBSTR(cognom,1 ,1)) = 'R';

-- 2. Nombres de departamentos que no tengan A

SELECT nom FROM departaments WHERE UPPER(nom) NOT LIKE '%A%';

SELECT nom FROM departaments WHERE INSTR(UPPER(nom), 'A') = 0;


-- 3. Departamentos y empleados

SELECT departaments.nom, empleats.cognom
FROM departaments, empleats
WHERE departaments.codiDepartament = empleats.codiDepartament
ORDER BY departaments.nom;

-- 4. Departamentos y cantidad de empleados, para los departamentos que sí tienen empleados

SELECT departaments.nom, COUNT(*)
FROM departaments, empleats
WHERE departaments.codiDepartament = empleats.codiDepartament
GROUP BY departaments.nom;


-- 5. Departamentos con más de un empleado

SELECT departaments.nom, COUNT(*) 
FROM departaments, empleats
WHERE departaments.codiDepartament = empleats.codiDepartament
GROUP BY departaments.nom
HAVING COUNT(*) > 1;

-- 6. Departamentos y empleados, incluyendo los departamentos que no tienen empleados

SELECT departaments.nom, empleats.cognom
FROM departaments LEFT JOIN empleats
ON departaments.codiDepartament = empleats.codiDepartament
ORDER BY departaments.nom;

-- 7. Departamentos que empiezan por M y empleados, incluyendo los departamentos que no tienen empleados

SELECT departaments.nom, empleats.cognom
FROM departaments LEFT JOIN empleats
ON departaments.codiDepartament = empleats.codiDepartament
WHERE UPPER(nom) LIKE 'M%'
ORDER BY departaments.nom;
