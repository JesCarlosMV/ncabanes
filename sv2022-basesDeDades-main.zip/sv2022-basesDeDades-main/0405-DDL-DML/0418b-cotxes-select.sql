-- Cotxes V2

CREATE TABLE cotxes (
  codi NUMERIC (5) primary key, 
  marca VARCHAR (20), 
  model VARCHAR (20), 
  variant VARCHAR (20),
  potencia NUMERIC (4),
  anyLlancament NUMERIC (4)
);

INSERT INTO cotxes VALUES (1, 'Ford', 'Fiesta', '1.0 Ecoboost 140', 140, 2010);
INSERT INTO cotxes VALUES (2, 'Mercedes', 'A', '200', 163, 2019);
INSERT INTO cotxes VALUES (3, 'Toyota', 'Yaris', '120H e-CVT', 120, 2019);
INSERT INTO cotxes VALUES (4, 'Hyundai', 'Kona', '1.0 T-GDI', 120, 2019);
INSERT INTO cotxes VALUES (5, 'Mini', 'Countryman', 'Cooper', 136, 2018);
INSERT INTO cotxes VALUES (6, 'Honda', 'Civic', '1.5 VTEC TURBO CVT', 182, 2020);
INSERT INTO cotxes VALUES (7, 'Honda', 'Civic', '2.0 i-MMD Hybrid', 184, 2023);
INSERT INTO cotxes VALUES (8, 'Honda', 'HR-V', '1.5 i-MMD', 131, 2023);
INSERT INTO cotxes VALUES (9, 'Ford', 'Mustang', 'GT', 450, 2023);
INSERT INTO cotxes VALUES (10, 'Ford', 'Mustang', 'Mach-E', NULL, 2023);

-------------

-- 1. Mostra marca, model i variant dels cotxes que tenim registrats amb més de 5 anys d'antiguitat, ordenats per marca, model i variant.

SELECT marca, model, variant 
FROM cotxes 
WHERE 2023 - anyLlancament > 5
ORDER BY marca, model, variant;

-- Ford|Fiesta|1.0 Ecoboost 140


-- 2. Model i nom dels cotxes, el model dels quals tinga més de 5 lletres, ordenats per model i marca.

SELECT model, variant 
FROM cotxes 
WHERE LENGTH(model) >5
ORDER BY model, marca;

-- Countryman|Cooper
-- Fiesta|1.0 Ecoboost 140
-- Mustang|GT
-- Mustang|Mach-E


-- 3. Potència mitjana dels cotxes que tenim emmagatzemats, arredonida a dues xifres decimals.

SELECT ROUND(AVG(potencia), 2)
FROM cotxes;

-- 180.67


-- 4. Marca, model i variant dels cotxes la marca dels quals comença per H o el model dels quals comença per H, ordenats de major a menys potència.

SELECT marca, model, variant 
FROM cotxes 
WHERE UPPER(marca) LIKE 'H%'
OR UPPER(model) LIKE 'H%'
ORDER BY potencia DESC;

-- Honda|Civic|2.0 i-MMD Hybrid
-- Honda|Civic|1.5 VTEC TURBO CVT
-- Honda|HR-V|1.5 i-MMD
-- Hyundai|Kona|1.0 T-GDI


-- 5. Marca i model dels cotxes l'any dels quals està entre 2005 i 2023 (inclusivament) i la marca dels quals és Mini o Ford.

SELECT marca, model
FROM cotxes 
WHERE anyLlancament BETWEEN 2005 AND 2023
AND (UPPER(marca) = 'MINI' OR UPPER(marca) = 'FORD');

-- Ford|Fiesta
-- Mini|Countryman
-- Ford|Mustang
-- Ford|Mustang


-- 6. Quantitat de cotxes que tenim registrats de cada marca.

SELECT marca, COUNT(*) 
FROM cotxes 
GROUP BY marca;

-- Ford|3
-- Honda|3
-- Hyundai|1
-- Mercedes|1
-- Mini|1
-- Toyota|1


-- 7. Quantitat de cotxes que tenim de cada model, però només per a aquells en els quals tinguem més d'un model.

SELECT model, COUNT(*) 
FROM cotxes 
GROUP BY model
HAVING COUNT(*) > 1;

-- Civic|2
-- Mustang|2


-- 8. Cotxes per als quals no coneixem la potència.

SELECT * FROM cotxes WHERE potencia IS NULL;

-- 10|Ford|Mustang|Mach-E||2023


-- 9. Cotxes la potència dels quals siga 450 i la marca dels quals acabe amb la lletra D (potser en minúscules).

SELECT * 
FROM cotxes 
WHERE potencia = 450
AND UPPER(marca) LIKE '%D';

-- 9|Ford|Mustang|GT|450|2023


-- 10. Llista de les marques que tenim registrades (sense duplicats), ordenades de la A a la Z.

SELECT DISTINCT marca 
FROM cotxes 
ORDER BY marca;

-- Ford
-- Honda
-- Hyundai
-- Mercedes
-- Mini
-- Toyota


-------------

-- (Enunciado en castellano)

-- 1. Muestra marca, modelo y variante de los coches que tenemos registrados con más de 5 años de antigüedad, ordenados por marca, modelo y variante.
-- 2. Modelo y nombre de los coches cuyo modelo tenga más de 5 letras, ordenados por modelo y marca.
-- 3. Potencia media de los coches que tenemos almacenados, redondeada a dos cifras decimales.
-- 4. Marca, modelo y variante de los coches cuya marca comienza por H o cuyo modelo empieza por H, ordenados de mayor a menos potencia.
-- 5. Marca y modelo de los coches cuyo año está entre 2005 y 2023 (incluidos) y cuya marca es Mini o Ford.
-- 6. Cantidad de coches que tenemos registrados de cada marca.
-- 7. Cantidad de coches que tenemos de cada modelo, pero sólo para aquellos en los que tengamos más de un modelo.
-- 8. Coches para los que no conocemos la potencia.
-- 9. Coches cuya potencia sea 450 y cuya marca acabe con la letra D (quizá en minúsculas).
-- 10. Lista de las marcas que tenemos registradas (sin duplicados), ordenadas de la A a la Z.

-------------

