-- 26 gener 2022 – Pel·lícules
-- 
-- Pel·lícules. Per a simplificar, suposarem que cada pel·lícula té un 
-- únic director. Cada director pot dirigir diverses pel·lícules. També 
-- volem informació sobre actors (varis en cada pel·lícula, i cadascun pot 
-- participar en més e una pel·lícula).
-- 
-- Les dades inicials que usarem per a proves són:
-- 
-- - Titanic, de James Cameron, 1997, valoració 7.9, amb Kate Winslet i Leonardo DiCaprio
-- - Avatar, de James Cameron, 2009, valoració 7.9, amb Sam Worthington, Zoe Saldana i Sigourney Weaver
-- - Forrest Gump, de Robert Zemeckis, 1994, v. 8.8, amb Tom Hanks
-- - Regreso al futuro, de Robert Zemeckis, 1985, v. 8.5, amb Michael J. Fox i Christopher Lloyd
-- - El caballero oscuro, de Christopher Nolan, 2009, v. 9.0, amb Christian Bale i Heath Ledger
-- - La guerra de las galaxias, de George Lucas, 1977, v. 8.6, amb Mark Hamill, Harrison Ford i Carrie Fisher
-- - Interstellar, de Christopher Nolan, 2014, v. 8.6, amb Matthew McConaughey, Anne Hathaway i Jessica Chastain
-- - Àlien, el huité passatger, de Ridley Scott, 1979, v. 8.5, amb Sigourney Weaver
-- - Blade Runner, de Ridley Scott, 1982, v. 8.1, amb Harrison Ford i Ruther Hauer.
-- - Seven (encara no coneixem més dades)
-- 
-- També volem anotar a l'actor Matt Damon i al director Tony Scott, si bé encara no tenim més dades sobre ells. 

-- ---------------------------------

-- 26 enero 2022 – Películas
-- 

-- Películas. Para simplificar, supondremos que cada película tiene un 
-- único director. Cada director puede dirigir varias películas. También 
-- queremos información sobre actores (varios en cada película, y cada uno 
-- puede participar en más e una película).
 
-- Los datos iniciales que usaremos para pruebas son:
-- 
-- - Titanic, de James Cameron, 1997, valoración 7.9, con Kate Winslet y Leonardo DiCaprio
-- - Avatar, de James Cameron, 2009, valoración 7.9, con Sam Worthington, Zoe Saldana y Sigourney Weaver
-- - Forrest Gump, de Robert Zemeckis, 1994, v. 8.8, con Tom Hanks
-- - Regreso al futuro, de Robert Zemeckis, 1985, v. 8.5, con Michael J. Fox y Christopher Lloyd
-- - El caballero oscuro, de Christopher Nolan, 2009, v. 9.0, con Christian Bale y Heath Ledger
-- - La guerra de las galaxias, de George Lucas, 1977, v. 8.6, con Mark Hamill, Harrison Ford y Carrie Fisher
-- - Interstellar, de Christopher Nolan, 2014, v. 8.6, con Matthew McConaughey, Anne Hathaway y Jessica Chastain
-- - Alien, el octavo pasajero, de Ridley Scott, 1979, v. 8.5, con Sigourney Weaver
-- - Blade Runner, de Ridley Scott, 1982, v. 8.1, con Harrison Ford y Ruther Hauer.
-- - Seven (aún no conocemos más datos)
-- 
-- También queremos anotar al actor Matt Damon y al director Tony Scott, aunque aún no tenemos más datos sobre ellos. 

CREATE TABLE directors(
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(50)
);
    
CREATE TABLE actors(
    codi VARCHAR(5) PRIMARY KEY,
    nom VARCHAR(50)
);

CREATE TABLE pellicules(
    codi VARCHAR(5) PRIMARY KEY,
    titol VARCHAR(50),
    anyLlancament NUMERIC(4),
    valoracio NUMERIC(3,1),
    codiDirector VARCHAR(5),
    FOREIGN KEY (codiDirector) REFERENCES directors(codi)
);

CREATE TABLE actuen(
    codiActor VARCHAR(5),
    codiPelicula VARCHAR(5),
    PRIMARY KEY(codiActor, codiPelicula),
    FOREIGN KEY (codiActor) REFERENCES actors(codi),
    FOREIGN KEY (codiPelicula) REFERENCES pellicules(codi)
);

INSERT INTO directors VALUES ( 'JC', 'James Cameron');
INSERT INTO directors VALUES ( 'RZ', 'Robert Zemeckis');
INSERT INTO directors VALUES ( 'CN', 'Christopher Nolan');
INSERT INTO directors VALUES ( 'GL', 'George Lucas');
INSERT INTO directors VALUES ( 'RS', 'Ridley Scott');
INSERT INTO directors VALUES ( 'TS', 'Tony Scott');

INSERT INTO actors VALUES('KWI', 'Kate Winslet');
INSERT INTO actors VALUES('LDI', 'Leonardo DiCaprio');
INSERT INTO actors VALUES('SWO', 'Sam Worthington');
INSERT INTO actors VALUES('ZSA', 'Zoe Saldana');
INSERT INTO actors VALUES('SWE', 'Sigourney Weaver');
INSERT INTO actors VALUES('THA', 'Tom Hanks');
INSERT INTO actors VALUES('MFO', 'Michael J. Fox');
INSERT INTO actors VALUES('CLL', 'Christopher Lloyd');
INSERT INTO actors VALUES('CBA', 'Christian Bale');
INSERT INTO actors VALUES('HLE', 'Heath Ledger');
INSERT INTO actors VALUES('MHA', 'Mark Hamill');
INSERT INTO actors VALUES('HFO', 'Harrison Ford');
INSERT INTO actors VALUES('CFI', 'Carrie Fisher');
INSERT INTO actors VALUES('MMC', 'Matthew McConaughey');
INSERT INTO actors VALUES('AHA', 'Anne Hathaway');
INSERT INTO actors VALUES('JCH', 'Jessica Chastain');
INSERT INTO actors VALUES('RHA', 'Rutger Hauer');
INSERT INTO actors VALUES('MDA', 'Matt Damon');

INSERT INTO pellicules VALUES ('TITAN', 'Titanic', 1997, 7.9, 'JC');
INSERT INTO pellicules VALUES ('AVATA', 'Avatar', 2009, 7.9, 'JC');
INSERT INTO pellicules VALUES ('FORRE', 'Forrest Gump', 1994, 8.8, 'RZ');
INSERT INTO pellicules VALUES ('REGRE', 'Regreso al futuro', 1985, 8.5, 'RZ');
INSERT INTO pellicules VALUES ('CABAL', 'El caballero oscuro', 2009, 9, 'CN');
INSERT INTO pellicules VALUES ('GUERR', 'La guerra de las galaxias', 1977, 8.6, 'CL');
INSERT INTO pellicules VALUES ('INTER', 'Interstellar', 2014, 8.6, 'CN');
INSERT INTO pellicules VALUES ('ALIEN', 'Alien', 1979, 8.5, 'RS');
INSERT INTO pellicules VALUES ('BLADE', 'Blade Runner', 1982, 8.1, 'RS');
INSERT INTO pellicules VALUES ('SEVEN', 'Seven', NULL, NULL, NULL);

INSERT INTO actuen VALUES('KWI', 'TITANIC');
INSERT INTO actuen VALUES('LDI', 'TITANIC');
INSERT INTO actuen VALUES('SWO', 'AVATA');
INSERT INTO actuen VALUES('ZSA', 'AVATA');
INSERT INTO actuen VALUES('SWE', 'AVATA');
INSERT INTO actuen VALUES('THA', 'FORRE');
INSERT INTO actuen VALUES('MFO', 'REGRE');
INSERT INTO actuen VALUES('CLL', 'REGRE');
INSERT INTO actuen VALUES('CBA', 'CABAL');
INSERT INTO actuen VALUES('HLE', 'CABAL');
INSERT INTO actuen VALUES('MHA', 'GUERR');
INSERT INTO actuen VALUES('HFO', 'GUERR');
INSERT INTO actuen VALUES('CFI', 'GUERR');
INSERT INTO actuen VALUES('MMC', 'INTER');
INSERT INTO actuen VALUES('AHA', 'INTER');
INSERT INTO actuen VALUES('JCH', 'INTER');
INSERT INTO actuen VALUES('SWE', 'ALIEN');
INSERT INTO actuen VALUES('HFO', 'BLADE');
INSERT INTO actuen VALUES('RHA', 'BLADE');
