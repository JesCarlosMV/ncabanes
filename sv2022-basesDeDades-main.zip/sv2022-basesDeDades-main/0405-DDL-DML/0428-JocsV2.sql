-- Crea una nova versió de les taules Plataformes i Jocs, amb els canvis:
-- 
-- - El nom de plataforma ha de ser únic.
-- - El codi de joc ha d'estar en majúscules
-- - L'espai ocupat ha de ser inferior o igual a 2000.

-- ---------------

-- Crea una nueva versión de las tablas Plataformas y Juegos, con los cambios:
-- 
-- - El nombre de plataforma debe ser único.
-- - El código de juego debe estar en mayúsculas
-- - El espacio ocupado debe ser inferior o igual a 2000.

CREATE TABLE plataformes(
    codi CHAR(4), 
    nom VARCHAR2(30),
    CONSTRAINT pk_plataformes PRIMARY KEY (codi),
    CONSTRAINT uk_plataformes UNIQUE (nom)
);

CREATE TABLE jocs(
    codi CHAR(5), 
    nom VARCHAR2(50),
    descripcio VARCHAR2(1000),
    dataLlancament DATE,
    espaiOcupat NUMBER(7,3), 
    codiPlataforma CHAR(4), 
    CONSTRAINT pk_jocs PRIMARY KEY (codi),
    CONSTRAINT uk_jocs UNIQUE (nom),
    CONSTRAINT ck_jocs_nom CHECK (nom = UPPER(nom)),
    CONSTRAINT ck_jocs_espai CHECK (espaiOcupat <= 2000),
    CONSTRAINT fk_plataformes 
        FOREIGN KEY (codiPlataforma) REFERENCES plataformes(codi)
); 
