# sv2022-basesDeDades
## 01-SistemesEmmagatzematge

Exercicis de Bases de dades, 1r DAW, SV 22/23

Bloc: Sistemes D'Emmagatzematge
