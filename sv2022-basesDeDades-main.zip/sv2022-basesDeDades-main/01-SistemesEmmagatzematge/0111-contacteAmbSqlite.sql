.open amistades
CREATE TABLE amigos (nombre VARCHAR(50), email VARCHAR(100));
INSERT INTO amigos VALUES ("Jose", "josito@gmail.com");
INSERT INTO amigos VALUES ("Marta", "marta@gmail.com");
INSERT INTO amigos VALUES ("Clara", "Clara@gmail.com");
SELECT * FROM amigos;
