.open amistades
SELECT * FROM amigos

INSERT INTO amigos VALUES ("Carlos", "carlos@gmail.com");
INSERT INTO amigos VALUES ("Pedro", "pedro@gmail.com");
