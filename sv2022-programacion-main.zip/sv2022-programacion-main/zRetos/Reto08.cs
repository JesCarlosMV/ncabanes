﻿// Reto 8 - Radha

/*
The digital Clock

You have a digital, 7 led segment, clock. One day, while waking up from 
a sci-fi dream, you wonder: how many times will the individual leds 
turn on after X seconds, from a 00:00:00 position?

Yeah, geeks. But as a good geek you will not that question stay on your 
mind forever, right? ;)

Take into account that every second, all leds turn off and then the 
ones for the next position will turn on.

Sample input
0
4
1000
36000

Sample output
36
172
30630
1069232
*/

using System;


class Reto8
{
    static void Main()
    {
        int contador;
        int[] arrayEnteros = { 6, 2, 5, 5, 4, 5, 6, 3, 7, 6 };
        
        string entrada = Console.ReadLine();

        while (entrada != "")
        {
            contador = 0;
            int input = Convert.ToInt32(entrada);

            int segundos = 0, minutos = 0, horas = 0;

            for (int i = 0; i < input + 1; i++)
            {

                contador += obtenerValor(arrayEnteros, segundos);
                contador += obtenerValor(arrayEnteros, minutos);
                contador += obtenerValor(arrayEnteros, horas);

                segundos++;

                if (segundos > 59)
                {
                    segundos = 0;
                    minutos++;
                }

                if (minutos > 59)
                {
                    minutos = 0;
                    horas++;
                }

            }

            Console.WriteLine(contador);
            entrada = Console.ReadLine();
        }
    }

    static int obtenerValor(int[] array, int tiempo)
    {
        int contador = 0;
        contador += (array[tiempo / 10]);
        contador += (array[tiempo % 10]);

        return contador;
    }
}

