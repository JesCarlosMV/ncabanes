﻿/*231. Crea una aplicación que permita llevar el control de una 
 * colección de música en formato MP3. De cada canción o similar 
 * (que será un objeto de la clase "Musica") querremos anotar el titulo
 * (por ejemplo, "The bell"), el intérprete ("Mike Oldfield"), 
 * el nombre del fichero ("thebell.mp3"), la ubicación 
 * ("MikeOldfield/tubularBells"), el tamaño del fichero (en MB, quizá 
 * con decimales, como en "3,070"). Otros detalles que podrían ser 
 * interesantes, como la categoría, el álbum al que pertenece o la 
 * valoración personal, hemos decidido aplazarlos para una versión 
 * posterior 2.0.

Tu aplicación debe mostrar un menú que permita:

1. Añadir un nueva canción (al final de los datos existentes).

2. Mostrar las canciones que contengan un cierto texto en el título o en el intérprete.

3. Modificar los datos de una canción a partir de su posición 
(la canción número 1 sería la primera de la lista).

4. Eliminar la canción que se encuentra en cierta posición.

5. Ordenar alfabéticamente por título.

6. Ordenar alfabéticamente por intérprete.

7. Salir

Tu aplicación debe cargar datos al comenzar y guardar datos tras cada 
cambio, empleando serialización con un formateador binario.

 Radha */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

class Coleccion
{
    const string ANYADIR = "1", MOSTRAR = "2", MODIFICAR = "3",
        ELIMINAR = "4", ORDENAR_TITULO = "5", ORDENAR_INTER = "6",
        SALIR = "7";
    static void Main()
    {
        string opcion;
        ListaDeMusica coleccion = new ListaDeMusica();

        do
        {
            MostrarMenu();
            opcion = Pedir("¿Opción? ");
            switch (opcion)
            {
                case ANYADIR: Anyadir(coleccion); break;
                case MOSTRAR: Mostrar(coleccion); break;
                case MODIFICAR: Modificar(coleccion); break;
                case ELIMINAR: Eliminar(coleccion); break;
                case ORDENAR_TITULO: OrdenarAutor(coleccion); break;
                case ORDENAR_INTER: OrdenarInterprete(coleccion); break;
                case SALIR: Console.WriteLine("¡Hasta la vista!"); break;
                default: Console.WriteLine("Opción no válida!"); break;
            }
        }
        while (opcion != SALIR);
    }

    static void MostrarMenu()
    {
        Console.WriteLine(ANYADIR + ". Añadir un nueva canción");
        Console.WriteLine(MOSTRAR + ". Mostrar las canciones que " +
            "contengan un cierto texto en el título o en el autor.");
        Console.WriteLine(MODIFICAR + ". Modificar los datos de una canción " +
            "a partir de su posición");
        Console.WriteLine(ELIMINAR + ". Eliminar la canción que se " +
            "encuentra en cierta posición.");
        Console.WriteLine(ORDENAR_TITULO + ". Ordenar alfabéticamente por título.");
        Console.WriteLine(ORDENAR_INTER + ". Ordenar alfabéticamente por intérprete.");
        Console.WriteLine(SALIR + ". Salir");
    }

    static void Anyadir(ListaDeMusica coleccion)
    {
        string titulo = Pedir("¿Título? ");
        string interprete = Pedir("¿Intérprete? ");
        string nombreFichero = Pedir("¿Nombre del fichero? ");
        string ubicacion = Pedir("¿Ubicación? ");
        double tamanyoFichero = Convert.ToDouble(
            Pedir("¿Tamaño del fichero? "));

        coleccion.Anyadir(titulo, interprete, nombreFichero, 
            ubicacion, tamanyoFichero);
    }

    static void Mostrar(ListaDeMusica coleccion)
    {
        string textoBuscar = Pedir("¿Texto a buscar?");

        for(int i = 0; i < coleccion.Cantidad; i++)
        {
            if (coleccion.Obtener(i).Contener(textoBuscar))
            {
                Console.WriteLine(coleccion.Obtener(i));
            }
        }
    }

    static void Eliminar(ListaDeMusica coleccion)
    {
        Console.Write("Numero de registro?: ");
        int numRegistro = Convert.ToInt32(Console.ReadLine()) - 1;
        if (numRegistro >= 0 && numRegistro < coleccion.Cantidad)
        {
            Console.WriteLine(coleccion.Obtener(numRegistro));

            Console.Write(
                "Seguro que quieres borrar este libro? Si/No:");
            string siNo = Console.ReadLine().ToUpper();
            if (siNo == "SI" || siNo == "S")
            {
                coleccion.Eliminar(numRegistro);
            }
        }
        else
        {
            Console.WriteLine("No se encuentra el registro");
            Console.WriteLine();
        }
    }

    static void Modificar(ListaDeMusica coleccion)
    {
        Console.Write("Número de registro?: ");
        int numRegistro = Convert.ToInt32(Console.ReadLine());

        if (numRegistro >= 1 && numRegistro <= coleccion.Cantidad)
        {
            Console.WriteLine(coleccion.Obtener(numRegistro-1));
            Console.WriteLine();

            string titulo = Pedir("¿Título?: ").Trim();
            if (titulo == "")
            {
                titulo = coleccion.Obtener(numRegistro - 1).Titulo;
            }


            string interprete = Pedir("¿Intérprete?: ").Trim();
            if (interprete == "")
            {
                interprete = coleccion.Obtener(numRegistro - 1).Interprete;
            }

            string nombreFichero = Pedir("¿Nombre del fichero?: ").Trim();
            if (nombreFichero == "")
            {
                nombreFichero = coleccion.Obtener(numRegistro - 1).NombreFichero;
            }

            string ubicacion = Pedir("¿Ubicación?: ").Trim();
            if (ubicacion == "")
            {
                ubicacion = coleccion.Obtener(numRegistro - 1).Ubicacion;
            }

            string tamanyo = Pedir("¿Tamaño del fichero?: ").Trim();
            if (tamanyo == "")
            {
                tamanyo = "" + 
                    coleccion.Obtener(numRegistro - 1).TamanyoFichero;
            }

            coleccion.Modificar(numRegistro - 1, titulo, interprete, 
                nombreFichero, ubicacion, Convert.ToDouble(tamanyo));

        }
        else
        {
            Console.WriteLine("No se encuentra el registro");
        }
    }

    static void OrdenarAutor(ListaDeMusica coleccion)
    {
        coleccion.OrdenarPorAutor();
        Console.WriteLine("Ordenado alfabéticamente por autor.");
    }

    static void OrdenarInterprete(ListaDeMusica coleccion)
    {
        coleccion.OrdenarPorInterprete();
        Console.WriteLine("Ordenado alfabéticamente por intérprete");
    }

    // FUNCIÓN AUXILIAR
    static string Pedir(string aviso)
    {
        Console.Write(aviso);
        return Console.ReadLine();
    }
}


// ---------------------------------



[Serializable]
class Musica : IComparable<Musica>
{
    public string Titulo { get; set; }
    public string Interprete { get; set; }
    public string NombreFichero { get; set; }
    public string Ubicacion { get; set; }
    public double TamanyoFichero { get; set; }

    public Musica(string titulo, string interprete, string nombreFichero,
        string ubicacion, double tamanyoFichero)
    {
        Titulo = titulo;
        Interprete = interprete;
        NombreFichero = nombreFichero;
        Ubicacion = ubicacion;
        TamanyoFichero = tamanyoFichero;
    }

    public void Modificar(string nuevoTitulo, string nuevoInterprete, 
        string nuevoNombreFichero, string nuevaUbicacion, double nuevoTamanyo)
    {
        Titulo = nuevoTitulo;
        Interprete = nuevoInterprete;
        NombreFichero = nuevoNombreFichero;
        Ubicacion = nuevaUbicacion;
        TamanyoFichero = nuevoTamanyo;
    }

    public override string ToString()
    {
        return "Titulo: " + Titulo + " - " + "Intérprete: " + Interprete +
            " - " + "Nombre del fichero: " + NombreFichero + " - " +
            "Ubicacion: " + Ubicacion + " - " + "Tamaño del fichero: " +
            TamanyoFichero;
    }

    public int CompareTo(Musica m)
    {
        return Titulo.CompareTo(m.Titulo);
    }

    public bool Contener(string busqueda)
    {
        return Titulo.ToUpper().Contains(busqueda.ToUpper()) || 
            Interprete.ToUpper().Contains(busqueda.ToUpper());
    }
}


// ---------------------------------

class MusicComparator : IComparer<Musica>
{
    public int Compare(Musica x, Musica y)
    {
        if (object.ReferenceEquals(x, y))
        {
            return 0;
        }

        if (x == null || y == null)
        {
            return -1;
        }

        return x.Interprete.CompareTo(y.Interprete);
    }
}

// ---------------------------------

class ListaDeMusica
{
    private List<Musica> coleccion;
    private const string NOMBRE_FICHERO = "coleccion.dat";

    public ListaDeMusica()
    {
        if (File.Exists(NOMBRE_FICHERO))
        {
            coleccion = Cargar();
        }
        else
        {
            coleccion = new List<Musica>();
        }
        
    }

    public int Cantidad
    {
        get { return coleccion.Count; }
    }

    public Musica Obtener(int pos)
    {
        return coleccion[pos];
    }

    public void Anyadir(string titulo, string interprete,
        string nombreFichero,
        string ubicacion, double tamanyoFichero)
    {
        Musica nuevoAlbum = new Musica
            (titulo, interprete, nombreFichero, ubicacion, tamanyoFichero);   
        coleccion.Add(nuevoAlbum);
        Guardar();
    }
    public void Eliminar(int numRegistro)
    {
        coleccion.RemoveAt(numRegistro);
        Guardar();
    }

    public void Modificar(int pos,string titulo, string interprete, 
        string nombreFichero,
        string ubicacion, double tamanyoFichero)
    {
        coleccion[pos].Modificar(titulo,interprete,nombreFichero,
            ubicacion,tamanyoFichero);
        Guardar();
    }

    public void OrdenarPorAutor()
    {
        coleccion.Sort();
    }
    public void OrdenarPorInterprete()
    {
        coleccion.Sort(new MusicComparator());
    }

    public void Guardar()
    {
        IFormatter formatter = new BinaryFormatter();
        FileStream stream = new FileStream(NOMBRE_FICHERO, FileMode.Create, 
            FileAccess.Write, FileShare.None);
        
        formatter.Serialize(stream, coleccion);
        stream.Close();

    }

    public List<Musica> Cargar()
    {
        IFormatter formatter = new BinaryFormatter();
        FileStream stream = new FileStream(NOMBRE_FICHERO,FileMode.Open,
            FileAccess.Read, FileShare.Read);
        
        coleccion = (List<Musica>)formatter.Deserialize(stream);
        stream.Close();

        return coleccion;
    }

}

