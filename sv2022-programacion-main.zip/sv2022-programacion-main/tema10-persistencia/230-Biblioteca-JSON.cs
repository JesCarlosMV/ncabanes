﻿/*
230. Crea una nueva versión del ejercicio de la biblioteca + List
(188, o su versión en 3 clases, 226), partiendo de la versión oficial,
en la que uses serialización JSON para cargar datos al comienzo de la
sesión y guardar los datos tras cada modificación.

Autor: Igor (...) 1DAW
(Usando como ejercicio base https://github.com/ncabanes/sv2022-programacion/blob/main/tema09-bibliotecas/226-ListaDeLibros-Vacaciones.cs)
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

// -------------

[Serializable]
class Libro : IComparable<Libro>
{
    public string Titulo { get; set; }
    public string Autor { get; set; }
    public short AnyoPubli { get; set; }

    public Libro(string titulo, string autor, short anyoPubli)
    {
        Modificar(titulo, autor, anyoPubli);
    }

    public void Modificar(string nuevoTitulo, string nuevoAutor, short nuevoAnyoPubli)
    {
        Titulo = nuevoTitulo;
        Autor = nuevoAutor;
        AnyoPubli = nuevoAnyoPubli;
    }

    public override string ToString()
    {
        return "Título: " + Titulo + ", Autor: " + Autor +
               ", Año de publicación: " +
               (AnyoPubli == -1 ? "Desconocido" : "" + AnyoPubli);
    }

    public int CompareTo(Libro libro)
    {
        return Titulo.CompareTo(libro.Titulo);
    }

    public bool Contains(string busqueda)
    {
        return Titulo.ToUpper().Contains(busqueda.ToUpper());
    }
}

// -------------

[Serializable]
class ListaDeLibros
{
    public List<Libro> Libros { get; set; }

    public ListaDeLibros()
    {
        Libros = new List<Libro>();
    }

    public int Cantidad
    {
        get { return Libros.Count; }
    }

    public Libro Obtener(int pos)
    {
        return Libros[pos];
    }

    public void Anyadir(string titulo, string autor, short anyoPubli)
    {
        Libro nuevoLibro = new Libro(titulo, autor, anyoPubli);
        Libros.Add(nuevoLibro);
        Libros.Sort();
        Biblioteca.Guardar(this);
    }

    public void Modificar(int pos, string autor, string titulo, short anyoPubli)
    {
        Libros[pos].Modificar(autor, titulo, anyoPubli);
        Biblioteca.Guardar(this);
    }

    public void Eliminar(int numRegistro)
    {
        Libros.RemoveAt(numRegistro);
        Biblioteca.Guardar(this);
    }
}

// -------------

class Biblioteca
{
    const string SALIR = "S",
            ANADIR = "1", VERTODO = "2", BUSCARTITULO = "3",
            BUSCARFECHA = "4", MODIFICAR = "5", BORRAR = "6",
            ORTOGRAFIA = "7", NOMBRE_FICHERO = "libros.json";
    const byte BLOQUE = 18;

    static void Main()
    {
        string opcion;
        ListaDeLibros libros = Cargar();

        do
        {
            MostrarMenu();
            opcion = PedirOpcion();
            switch (opcion)
            {
                case ANADIR: Anyadir(libros); break;
                case VERTODO: VerTodo(libros); break;
                case BUSCARTITULO: BuscarTitulo(libros); break;
                case BUSCARFECHA: BuscarFecha(libros); break;
                case MODIFICAR: Modificar(libros); break;
                case BORRAR: Borrar(libros); break;
                case ORTOGRAFIA: ComprobarOrtografia(libros); break;
                case SALIR: Console.WriteLine("¡Adiós!"); break;
                default: Console.WriteLine("Opción no válida!"); break;
            }
        }
        while (opcion != SALIR);
    }

    static void MostrarMenu()
    {
        Console.WriteLine("===============MENU===============");
        Console.WriteLine(ANADIR + "-Añadir un libro");
        Console.WriteLine(VERTODO + "-Mostrar todos los libros");
        Console.WriteLine(BUSCARTITULO + "-Buscar por título");
        Console.WriteLine(BUSCARFECHA + "-Buscar entre fechas");
        Console.WriteLine(MODIFICAR + "-Modificar libro");
        Console.WriteLine(BORRAR + "-Borrar libro");
        Console.WriteLine(ORTOGRAFIA + "-Revisar ortografía");
        Console.WriteLine(SALIR + "-Salir");
        Console.WriteLine();
    }

    static string PedirOpcion()
    {
        Console.Write("Opción?: ");
        return Console.ReadLine().ToUpper();
    }

    static void Anyadir(ListaDeLibros libros)
    {
        string titulo, autor;
        short anyoGuardar;

        titulo = PedirNoVacio("Título?: ");
        autor = PedirNoVacio("Autor?: ");
        // Año -1 si no se escribe nada
        string anyo = Pedir("Año de publicacion?: ");
        if (anyo == "")
        {
            anyoGuardar = -1;
        }
        else
        {
            anyoGuardar = Convert.ToInt16(anyo);
        }

        libros.Anyadir(titulo, autor, anyoGuardar);
    }

    static void VerTodo(ListaDeLibros libros)
    {
        if (libros.Cantidad == 0)
            Console.WriteLine("Sin datos");
        else
            for (int i = 0; i < libros.Cantidad; i++)
            {
                MostrarRegistro(libros, i);

                if ((i + 1) % BLOQUE == 0)
                {
                    Console.ReadLine();
                }
            }
        Console.WriteLine();
    }

    static void BuscarTitulo(ListaDeLibros libros)
    {
        Console.Write("BUSCAR. Título?: ");
        string buscar = Console.ReadLine();
        if (buscar != "")
        {
            for (int i = 0; i < libros.Cantidad; i++)
            {
                if (libros.Obtener(i).Contains(buscar))
                {
                    MostrarRegistro(libros, i);
                }
            }
        }
    }

    static void BuscarFecha(ListaDeLibros libros)
    {
        Console.WriteLine("BUSCAR. RANGO AÑO DE PUBLICACION");
        Console.Write("Entre año: ");
        ushort fecha1 = Convert.ToUInt16(Console.ReadLine());
        Console.Write("Y año: ");
        ushort fecha2 = Convert.ToUInt16(Console.ReadLine());

        // Invertir fechas si están al revés
        ushort fechaInicial = fecha1 > fecha2 ? fecha2 : fecha1;
        ushort fechaFinal = fecha1 < fecha2 ? fecha2 : fecha1;

        for (int i = 0; i < libros.Cantidad; i++)
        {
            if (libros.Obtener(i).AnyoPubli >= fechaInicial &&
                    libros.Obtener(i).AnyoPubli <= fechaFinal)
            {
                MostrarRegistro(libros, i);
            }
        }
    }

    static void Modificar(ListaDeLibros libros)
    {
        Console.Write("Número de registro?: ");
        int numRegistro = Convert.ToInt32(Console.ReadLine());
        if (numRegistro >= 1 && numRegistro <= libros.Cantidad)
        {
            MostrarRegistro(libros, numRegistro - 1);

            string titulo = Pedir("Título?: ").Trim();
            if (titulo == "")
            {
                titulo = libros.Obtener(numRegistro - 1).Titulo;
            }


            string autor = Pedir("Autor?:").Trim();
            if (autor == "")
            {
                autor = libros.Obtener(numRegistro - 1).Autor;
            }

            string anyo = Pedir("Año de publicacion?: ");
            if (anyo == "")
            {
                anyo = "" + libros.Obtener(numRegistro - 1).AnyoPubli;
            }

            libros.Modificar(numRegistro - 1,
                titulo, autor, Convert.ToInt16(anyo));

            // Avisos de mayúsculas, minúsculas, espacios
            if (EsMayusculas(libros.Obtener(numRegistro - 1).Autor))
            {
                Console.WriteLine("Cuidado: Autor en mayúsculas");
            }

            if (EsMayusculas(libros.Obtener(numRegistro - 1).Titulo))
            {
                Console.WriteLine("Cuidado: Título en mayúsculas");
            }

            if (EsMinusculas(libros.Obtener(numRegistro - 1).Autor))
            {
                Console.WriteLine("Cuidado: Autor en minúsculas");
            }

            if (EsMinusculas(libros.Obtener(numRegistro - 1).Titulo))
            {
                Console.WriteLine("Cuidado: Título en minúsculas");
            }

            if (libros.Obtener(numRegistro - 1).Autor.Contains("  "))
            {
                Console.WriteLine("Cuidado: Autor con espacios de sobra");
            }

            if (libros.Obtener(numRegistro - 1).Titulo.Contains("  "))
            {
                Console.WriteLine("Cuidado: Título con espacios de sobra");
            }
        }
        else
            Console.WriteLine("No se encuentra el registro.");
    }

    static void Borrar(ListaDeLibros libros)
    {
        Console.Write("Numero de registro?: ");
        int numRegistro = Convert.ToInt32(Console.ReadLine()) - 1;
        if (numRegistro >= 0 && numRegistro < libros.Cantidad)
        {
            MostrarRegistro(libros, numRegistro);

            Console.Write(
                "Seguro que quieres borrar este libro? Si/No:");
            string siNo = Console.ReadLine().ToUpper();
            if (siNo == "SI" || siNo == "S")
            {
                libros.Eliminar(numRegistro);
            }
        }
        else
        {
            Console.WriteLine("Sin datos");
            Console.WriteLine();
        }
    }

    static void ComprobarOrtografia(ListaDeLibros libros)
    {
        for (int i = 0; i < libros.Cantidad; i++)
        {
            bool fichaCorrecta = true;
            string titulo = libros.Obtener(i).Titulo;
            int longitud = titulo.Length;

            // Contiene espacios duplicados?
            if (titulo.Contains("  "))
            {
                fichaCorrecta = false;
            }

            // Empieza o termina en espacio?
            if (titulo[0] == ' ' ||
                titulo[longitud - 1] == ' ')
            {
                fichaCorrecta = false;
            }


            // Minúscula justo antes de mayúscula
            for (int l = 0; l < longitud - 1; l++)
            {

                if ((titulo[l] >= 'a') && (titulo[l] <= 'z')
                    && (titulo[l + 1] >= 'A') && (titulo[l + 1] <= 'Z'))
                {
                    fichaCorrecta = false;
                }
            }

            if (!fichaCorrecta)
            {
                string tituloCorregir;
                MostrarRegistro(libros, i);
                Console.Write("¿Desea arreglar este registro (s/n)? ");
                string corregir = Console.ReadLine().ToUpper();
                if (corregir == "S")
                {
                    // Sin espacios iniciales ni finales
                    tituloCorregir = libros.Obtener(i).Titulo.Trim();

                    // Sin espacios redundantes
                    while (tituloCorregir.Contains("  "))
                        tituloCorregir =
                            tituloCorregir.Replace("  ", " ");

                    // Mayúsculas correctas
                    // Fase 1: 1ª mayúscula, resto minúscula
                    tituloCorregir = tituloCorregir.ToUpper()[0] +
                                        tituloCorregir.ToLower().Substring(1);
                    // Fase 2: Mays tras cada punto
                    string t = tituloCorregir;
                    bool proxMayuscula = false;
                    for (int l = 1; l < t.Length - 1; l++)
                    {
                        if (t[l - 1] == '.')
                            proxMayuscula = true;

                        if ((t[l] >= 'a') && (t[l] <= 'z')
                            && proxMayuscula)
                        {
                            t = t.Insert(l, t.ToUpper().Substring(l, 1));
                            t = t.Remove(l + 1, 1);
                            proxMayuscula = false;
                        }
                    }
                    tituloCorregir = t;

                    libros.Modificar(i,
                        tituloCorregir,
                        libros.Obtener(i).Autor,
                        libros.Obtener(i).AnyoPubli);
                }
            }
        }
    }

    // --------- Cargar / guardar -------------
    public static ListaDeLibros Cargar()
    {
        ListaDeLibros listaDeLibros = new ListaDeLibros();
        if (File.Exists(NOMBRE_FICHERO))
        {
            try
            {
                string jsonString = File.ReadAllText(NOMBRE_FICHERO);
                listaDeLibros = JsonSerializer.Deserialize<ListaDeLibros>(jsonString);
            }
            catch (IOException e)
            {
                Console.WriteLine("Error cargando el fichero de datos: {0}", e.Message);
            }
        }
        return listaDeLibros;
    }

    public static void Guardar(ListaDeLibros listaDeLibros)
    {
        try
        {
            string jsonString = JsonSerializer.Serialize(listaDeLibros);
            File.WriteAllText(NOMBRE_FICHERO, jsonString);

        }
        catch (IOException e)
        {
            Console.WriteLine("Error guardando el fichero de datos: {0}", e.Message);
        }
    }

    // --------- Funciones auxiliares -------------

    static string Pedir(string aviso)
    {
        Console.Write(aviso);
        return Console.ReadLine();
    }

    static string PedirNoVacio(string aviso)
    {
        string respuesta;
        do
        {
            Console.Write(aviso);
            respuesta = Console.ReadLine();
        }
        while (respuesta == "");
        return respuesta;
    }

    static bool EsMayusculas(string texto)
    {
        return texto == texto.ToUpper();
    }

    static bool EsMinusculas(string texto)
    {
        return texto == texto.ToLower();
    }

    static void MostrarRegistro(ListaDeLibros libros, int pos)
    {
        Console.WriteLine("{0}- {1}", pos + 1, libros.Obtener(pos));
    }
}
