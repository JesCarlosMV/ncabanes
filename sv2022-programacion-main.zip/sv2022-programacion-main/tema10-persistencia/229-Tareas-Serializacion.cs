﻿//Francis (...) - 1ºDAM Semipresencial

/*
229. Crea una nueva versión del ejercicio 189 (tareas + lista), 
partiendo de la versión oficial, en la que uses serialización XML para 
cargar datos cuando arranca el programa y para guardar los datos antes 
de terminar la ejecución.
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

[Serializable]
public class Tarea : IComparable<Tarea>
{
    public Tarea() { }

    public Tarea(string descripcion, byte prioridad)
    {
        Descripcion = descripcion;
        Prioridad = prioridad;
        Completada = false;
    }

    public string Descripcion { get; set; }
    public byte Prioridad { get; set; }
    public bool Completada { get; set; }

    public int CompareTo(Tarea otro)
    {
        return Descripcion.CompareTo(otro.Descripcion);
    }

    public override string ToString()
    {
        string mostrarTarea = Descripcion + ". Prioridad: " + Prioridad;

        if (Completada)
            return mostrarTarea + " - Completada";
        else
            return mostrarTarea + " - Pendiente";
    }
}


class Ejercicio229
{
    enum MENU
    {
        ANADIR = '1', VERTODO, MARCAR, MODIFICAR, BUSCAR, ORDENAR,
        SALIR = 'S'
    };
    const int POS_INCORRECTA = -1;
    static void Main()
    {
        Ejecutar();
    }

    // --------------------------------------------------
    static Tarea PedirTarea()
    {
        string descripcion = Pedir("Descripcion?: ");
        byte prioridad = Convert.ToByte(Pedir("Prioridad? (1-5): "));

        return new Tarea(descripcion, prioridad);
    }

    // --------------------------------------------------
    static void MostrarMenu()
    {
        Console.WriteLine((char)MENU.ANADIR + "- Añadir una nueva tarea.");
        Console.WriteLine((char)MENU.VERTODO + "- Ver todas las tareas pendientes.");
        Console.WriteLine((char)MENU.MARCAR + "- Marcar una tarea como completada");
        Console.WriteLine((char)MENU.MODIFICAR + "- Modificar una tarea");
        Console.WriteLine((char)MENU.BUSCAR + "- Buscar entre todas las tareas que " +
            "contengan un cierto texto (completadas o no).");
        Console.WriteLine((char)MENU.ORDENAR + "- Ordenar las tareas alfabéticamente.");
        Console.WriteLine((char)MENU.SALIR + "- Salir.");
    }

    // --------------------------------------------------
    static bool ElegirOpciones(List<Tarea> tareas)
    {
        bool salir = false;

        char opcion = Pedir("Opcion?: ").ToUpper()[0];

        switch (opcion)
        {
            case (char)MENU.ANADIR: tareas.Add(PedirTarea()); break;
            case (char)MENU.VERTODO: VerTareas(tareas); break;
            case (char)MENU.MARCAR: MarcarComoCompletada(tareas); break;
            case (char)MENU.MODIFICAR: tareas = ModificarTarea(tareas); break;
            case (char)MENU.BUSCAR: BuscarQueContenga(tareas); break;
            case (char)MENU.ORDENAR: tareas = OrdenarTareas(tareas); break;
            case (char)MENU.SALIR: salir = true; break;
            default:
                Console.WriteLine("Opcion no válida");
                break;
        }
        Console.WriteLine();

        return salir;
    }

    // --------------------------------------------------
    static void Ejecutar()
    {
        List<Tarea> tareas = Cargar();
        
        do
        {
            MostrarMenu();
            Console.WriteLine();
        } 
        
        while (!ElegirOpciones(tareas));

        Guardar(tareas);
    }

    // --------------------------------------------------

    private static List<Tarea> Cargar()
    {
        List<Tarea> tareas = new List<Tarea>();

        if (!File.Exists("tareas.xml"))
        {
            return tareas;
        }

        try
        {
            XmlSerializer formatter = new XmlSerializer(tareas.GetType());
            FileStream stream = new FileStream("tareas.xml",
                FileMode.Open, FileAccess.Read, FileShare.Read);
            tareas = (List<Tarea>)formatter.Deserialize(stream);
            stream.Close();
            return tareas;
        }

        catch (IOException)
        {
            Console.WriteLine("Error de lectura");
        }

        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }

        return tareas;
    }

    // --------------------------------------------------

    private static void Guardar(List<Tarea> tareas)
    {
        try
        {
            XmlSerializer formatter = new XmlSerializer(tareas.GetType());
            FileStream stream = new FileStream("tareas.xml",
                FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream, tareas);
            stream.Close();
        }

        catch (IOException)
        {
            Console.WriteLine("Error de escritura");
        }

        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }
    }

    // --------------------------------------------------
    static List<Tarea> OrdenarTareas(List<Tarea> tareas)
    {
        tareas.Sort();
        return tareas;
    }

    // --------------------------------------------------
    static void BuscarQueContenga(List<Tarea> tareas)
    {
        bool encontrado = false;
        string texto = Pedir("Texto a buscar?: ");

        foreach (Tarea t in tareas)
        {
            if (t.Descripcion.ToUpper().Contains(texto.ToUpper()))
            {
                Console.WriteLine(t);
                encontrado = true;
            }
        }

        if (!encontrado)
            Console.WriteLine("No encontrado");
    }

    // --------------------------------------------------
    static void VerTareas(List<Tarea> tareas)
    {
        for (int i = 0; i < tareas.Count; i++)
        {
            if (!tareas[i].Completada)
                Console.WriteLine((i + 1) + ". " + tareas[i]);
        }
    }

    // --------------------------------------------------
    static void MarcarComoCompletada(List<Tarea> tareas)
    {
        string opcion = Pedir("Posicion?: ");
        int posicion = Convert.ToInt32(opcion);

        if (posicion >= 1 && posicion <= tareas.Count)
        {
            Console.WriteLine(posicion + " -" + tareas[posicion - 1]);
            opcion = Pedir("Completar? s/n").ToUpper();

            if (opcion == "S")
            {
                tareas[posicion - 1].Completada = true;
                Console.WriteLine(tareas[posicion - 1]);
            }
        }
    }

    // --------------------------------------------------
    static List<Tarea> ModificarTarea(List<Tarea> tareas)
    {
        string opcion = Pedir("Posicion?: ");
        int posicion = Convert.ToInt32(opcion);

        if (posicion >= 1 && posicion <= tareas.Count)
        {
            tareas[posicion - 1] = PedirTarea();
        }
        Guardar(tareas);

        return tareas;
    }

    // --------------------------------------------------
    static string Pedir(string dato)
    {
        Console.Write(dato);
        return Console.ReadLine();
    }
}
