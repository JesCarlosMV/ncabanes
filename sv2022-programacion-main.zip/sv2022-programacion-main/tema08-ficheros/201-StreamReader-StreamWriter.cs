﻿/*201. Crea un programa que pregunte al usuario el nombre de un fichero de texto 
de entrada, el nombre de salida, y vuelque el contenido del primero al segundo, 
excepto las líneas vacías. Debes emplear StreamReader y StreamWriter, 
comprobando los posibles errores con try-catch. El programa debe pedir 
confirmación en caso de que el fichero de salida ya exista.

Alumno: Omar (...), retoques por Nacho
*/

using System;
using System.IO;

class Ejercicio201
{
    static void Main()
    {
        Console.Write("Fichero a leer?: ");
        string nombreFLectura = Console.ReadLine();
        Console.Write("Fichero a escribir?: ");
        string nombreFEscritura = Console.ReadLine();
        
        if(File.Exists(nombreFEscritura))
        {
            Console.Write("El fichero \"{0}\" ya existe. Sobreescribir? [S/N]: ", 
                nombreFEscritura);
            if(Console.ReadLine().ToUpper() != "S")
            {
                return; // Cancelamos si no se desea sobreescribir
            }
        }

        try
        {
            StreamReader leer = File.OpenText(nombreFLectura);            
            StreamWriter escribir = File.CreateText(nombreFEscritura);

            string linea;
            do
            {
                linea = leer.ReadLine();
                if ((linea != null) && (linea != ""))
                    escribir.WriteLine(linea);
            } while (linea != null);
            
            escribir.Close();
            leer.Close();
            Console.WriteLine("Volcado completado");
        }
        catch(PathTooLongException)
        {
            Console.WriteLine("La ruta del fichero es demasiado larga");
        }
        catch(IOException)
        {
            Console.WriteLine("Error de lectura de \"{0}\"", nombreFLectura);
        }
        catch(Exception e)
        {
            Console.WriteLine("Error: {0}", e.Message);
        }
    }
}
