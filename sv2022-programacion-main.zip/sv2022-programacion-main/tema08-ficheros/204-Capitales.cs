﻿/*204. Crea una nueva versión del ejercicio 184 (lista de struct), 
 * partiendo de la versión oficial, en la que guardes datos tras 
 * cada cambio (añadir, modificar, borrar) usando StreamWriter y 
 * cargues datos al comenzar la ejecución con StreamReader. 
 * Como son varios datos distintos para cada registro (nombre y país), 
 * puedes escribirlos en una misma línea usando un separador 
 * poco habitual, como "@", o bien en dos líneas separadas. 
 * Tu lectura deberá adaptarse a la forma en que hayas decidido 
 * guardar los datos. 
 * Debes gestionar los posibles errores de forma adecuada.
 
 Radha */

using System;
using System.Collections.Generic;
using System.IO;

class Ejercicio204
{
    struct TipoCapital
    {
        public string nombre;
        public string pais;
    }
    
    
    static List<TipoCapital> Cargar()
    {
        List<TipoCapital> capitales = new List<TipoCapital>();
        if (File.Exists("capitales.txt"))
        {
            try
            {
                using (StreamReader ficheroEntrada = new StreamReader("capitales.txt"))
                {
                    string linea;
                    linea = ficheroEntrada.ReadLine();

                    while (linea != null)
                    {
                        string[] capitalesFichero = linea.Split('@');

                        TipoCapital c = new TipoCapital();

                        c.nombre = capitalesFichero[0];
                        c.pais = capitalesFichero[1];

                        capitales.Add(c);

                        linea = ficheroEntrada.ReadLine();
                    }
                }
            }
            catch (IOException e1)
            {
                Console.WriteLine("No se ha podido leer el fichero");
                Console.WriteLine("El error ha sido: " + e1.Message);
            }
            catch(Exception e2)
            {
                Console.WriteLine("Ha habido un error: " + e2.Message);
            }
        }
        return capitales;
    }
    
    
    static void Guardar(List<TipoCapital> capitales)
    {
        try
        {
            using (StreamWriter ficheroModificar = 
                new StreamWriter("capitales.txt", false))
            {
                for (int i = 0; i < capitales.Count; i++)
                {
                    ficheroModificar.WriteLine(capitales[i].nombre +
                        "@" + capitales[i].pais);
                }

            }
        }
        catch(IOException e1)
        {
            Console.WriteLine("No se ha podido guardar el archivo");
            Console.WriteLine("Error: " + e1.Message);
        }
        catch(Exception e2)
        {
            Console.WriteLine("Error: " + e2.Message);
        }
    }

    static void Main()
    {
        List<TipoCapital> capitales = Cargar();
        const int ANYADIR = 1, VER = 2, BUSCAR = 3, MODIFICAR = 4,
            BORRAR = 5, SALIR = 0;
        int opcion;

        do
        {
            Console.WriteLine(ANYADIR + " Introducir una capital");
            Console.WriteLine(VER + " Ver todas las capitales");
            Console.WriteLine(BUSCAR + " Buscar una capital");
            Console.WriteLine(MODIFICAR + " Modificar una capital");
            Console.WriteLine(BORRAR + " Borrar una capital");
            Console.WriteLine(SALIR + " Salir");
            opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case ANYADIR:
                    TipoCapital nuevaCapital;
                    Console.Write("Nombre: ");
                    nuevaCapital.nombre = Console.ReadLine();
                    Console.Write("País: ");
                    nuevaCapital.pais = Console.ReadLine();
                    if ((nuevaCapital.nombre != "") && (nuevaCapital.pais != ""))
                    {
                        capitales.Add(nuevaCapital);
                    }
                    Guardar(capitales);
                    break;

                case VER:
                    foreach (TipoCapital c in capitales)
                    {
                        Console.WriteLine(c.nombre + " - " + c.pais);
                    }
                    break;

                case BUSCAR:
                    Console.WriteLine("Texto a buscar: ");
                    string textoBuscar = Console.ReadLine().ToLower();
                    for (int i = 0; i < capitales.Count; i++)
                    {
                        if ((capitales[i].nombre.ToLower().Contains(textoBuscar)) || (
                                capitales[i].pais.ToLower().Contains(textoBuscar)))
                        {
                            Console.WriteLine((i + 1) + ": " +
                                capitales[i].nombre + " - " + capitales[i].pais);
                        }
                    }
                    break;

                case MODIFICAR:
                    TipoCapital capitalModificar;
                    Console.Write("¿Que capital quieres modificar?: ");
                    int numeroModificar = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Nuevo nombre de la ciudad: ");
                    capitalModificar.nombre = Console.ReadLine();
                    Console.Write("Nuevo nombre del país: ");
                    capitalModificar.pais = Console.ReadLine();
                    capitales[numeroModificar - 1] = capitalModificar;
                    Guardar(capitales);
                    break;

                case BORRAR:
                    Console.Write("¿Que frase quieres borrar?: ");
                    int numeroBorrar = Convert.ToInt32(Console.ReadLine());
                    capitales.RemoveAt(numeroBorrar - 1);
                    Console.WriteLine("Borrado con éxito");
                    Guardar(capitales);
                    break;

                case SALIR:
                    Console.WriteLine("Fin del programa");
                    break;

                default:
                    Console.WriteLine("Opción no válida");
                    break;
            }
        }
        while (opcion != 0);
    }
}

