﻿/*
211. Crea un programa que muestre la información almacenada en un archivo MP3 (que
tenga una cabecera en formato "ID3 TAG V1"): título, artista, álbum, año. Deberás
comprobar el contenido de los últimos 128 bytes del fichero. En caso de tratarse de
un MP3 que tenga cabecera en dicho formato, deberías encontrar la siguiente secuencia
de bytes a partir de esa posición:

- Los caracteres "TAG" (3 bytes)

- Título: 30 caracteres (30 bytes).

- Artista: 30 caracteres (ídem).

- Álbum: 30 caracteres (ídem).

- Año: 4 caracteres.

- Un comentario: 30 caracteres.

- Género (musical): un byte.

Todas las etiquetas usan caracteres ASCII (terminados en caracteres nulos o quizá en
espacios), excepto el género, que es un número entero almacenado en un único byte.
Tienes un fichero de ejemplo "mp3.mp3" compartido en Aules y GitHub.

Autor: Igor (...) 1DAW
*/


using System;
using System.IO;

class Ej211
{
    static string BytesACadena(byte[] cabecera, byte posicion, byte longitud)
    {
        string etiqueta = string.Empty;
        for (byte i = posicion; i <= longitud; i++)
        {
            etiqueta += ((char)cabecera[i]).ToString();
        }
        return etiqueta.TrimEnd('\0', ' ');
    }

    static void Main()
    {
        const string ID_CABECERA = "TAG", NOMBRE_FICHERO = "mp3.mp3";
        const int LONGITUD_CABECERA = 128;

        if (!File.Exists(NOMBRE_FICHERO))
        {
            Console.WriteLine("El fichero no existe.");
        }
        else
        {
            byte[] cabecera = new byte[LONGITUD_CABECERA];

            try
            {
                using (FileStream fichero = new FileStream(NOMBRE_FICHERO, FileMode.Open))
                {
                    if (fichero.Length < LONGITUD_CABECERA)
                    {
                        Console.WriteLine("El fichero está vacío.");
                    }
                    else
                    {
                        fichero.Seek(-LONGITUD_CABECERA, SeekOrigin.End);
                        int datosLeidos = fichero.Read(cabecera, 0, LONGITUD_CABECERA);

                        if (datosLeidos != LONGITUD_CABECERA)
                        {
                            Console.WriteLine("No se pudieron leer todos los datos.");
                        }
                        else
                        {
                            if (BytesACadena(cabecera, 0, 2) == ID_CABECERA)
                            {
                                Console.WriteLine("Datos del fichero MP3:");
                                Console.WriteLine("ID de formato: {0}",
                                                    BytesACadena(cabecera, 0, 2));
                                Console.WriteLine("Título: {0}",
                                                    BytesACadena(cabecera, 3, 32));
                                Console.WriteLine("Artista: {0}",
                                                    BytesACadena(cabecera, 33, 62));
                                Console.WriteLine("Álbum: {0}",
                                                    BytesACadena(cabecera, 63, 92));
                                Console.WriteLine("Año: {0}",
                                                    BytesACadena(cabecera, 93, 96));
                                Console.WriteLine("Comentario: {0}",
                                                    BytesACadena(cabecera, 97, 126));
                                Console.WriteLine("Género: {0}",
                                                    Convert.ToInt32(cabecera[127]));
                            }
                            else
                            {
                                Console.WriteLine("No es un fichero con formato ID3 TAG V1.");
                            }
                        }
                    }
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("Error en el proceso: {0}.", e.Message);
            }
        }
    }
}
