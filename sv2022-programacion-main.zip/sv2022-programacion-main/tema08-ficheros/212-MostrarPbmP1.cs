/*
El formato Netpbm es una familia de formatos de archivos de imagen 
diseñados buscando simplicidad, en lugar de pretender un tamaño 
pequeño. Existen diferentes variantes, que permiten representar 
imágenes en color, escala de grises o B/N utilizando texto plano 
(aunque existe una variante binaria).

Por ejemplo, una imagen en blanco y negro codificada en ASCII (texto 
puro) se representa mediante la cabecera "P1".

La siguiente línea (opcional) podría ser un comentario, precedido por #.

La siguiente línea contiene el ancho y alto de la imagen, separados por un espacio.

Las líneas restantes contienen los datos: 1 para puntos negros y 0 para 
puntos blancos, como en este ejemplo:

P1
# This is an example bitmap of the letter ""J""
6 10
0 0 0 0 1 0
0 0 0 0 1 0
0 0 0 0 1 0
0 0 0 0 1 0
0 0 0 0 1 0
0 0 0 0 1 0
1 0 0 0 1 0
0 1 1 1 0 0
0 0 0 0 0 0
0 0 0 0 0 0

Crea un programa que permita decodificar un archivo de imagen como éste 
y mostrarlo en pantalla, usando solo la consola
*/

using System;
using System.Collections.Generic;
using System.IO;

class MostrarPbmP1
{
    static void Main()
    {
        Console.Write("Nombre de fichero: ");
        string nombre = Console.ReadLine();
        string[] lineas = File.ReadAllLines(nombre);
		if (lineas[0] != "P1")
			Console.WriteLine("No es un PBM P1");
		else
		{
			int numLinea = 1;
			string anchoAlto = lineas[numLinea];
			if (anchoAlto[0] == '#') // Si hay comentario
			{
				numLinea++;
				anchoAlto = lineas[numLinea];
			}
			numLinea++;

			int ancho = Convert.ToInt32(anchoAlto.Split()[0]);
			int alto = Convert.ToInt32(anchoAlto.Split()[1]);
			string datosImagen = "";

			// Juntamos todas las líneas en 1
			for (int i = numLinea; i < lineas.Length; i++)
				datosImagen += lineas[i];

			// Quitamos espacios y reemplazamos por un caracter "vistoso"
			datosImagen = datosImagen.Replace(" ","");
			datosImagen = datosImagen.Replace("1","#");
			datosImagen = datosImagen.Replace("0",".");
			
			// Finalmente, dibujamos en varias líneas
			for (int i = 0; i < datosImagen.Length; i++)
			{
				Console.Write(datosImagen[i]);
				if (i % ancho == ancho - 1)
					Console.WriteLine();
			}
		}
    }
}
