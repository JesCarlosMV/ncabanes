﻿INSERT INTO ejemploconversion02 (ID, NOMBRE, DIRECCION, ESPECIALID) VALUES (1,'La Tienda','C/ Ancha, 20','Ropa');
INSERT INTO ejemploconversion02 (ID, NOMBRE, DIRECCION, ESPECIALID) VALUES (2,'La botica','C/ Mayor, 19','Comestibles');
INSERT INTO ejemploconversion02 (ID, NOMBRE, DIRECCION, ESPECIALID) VALUES (3,'Especialidades Manuel','C/ Antigua, 2','Decoración;Iluminación');
