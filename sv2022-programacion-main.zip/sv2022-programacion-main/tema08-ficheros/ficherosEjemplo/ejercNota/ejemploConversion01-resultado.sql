INSERT INTO ejemploconversion01 (NOMBRE, APELLIDO, EDAD, CIUDAD) VALUES ('Juan','López',20,'Alicante');
INSERT INTO ejemploconversion01 (NOMBRE, APELLIDO, EDAD, CIUDAD) VALUES ('Pedro','Álvarez',19,'Ibi');
INSERT INTO ejemploconversion01 (NOMBRE, APELLIDO, EDAD, CIUDAD) VALUES ('Antonio','Martínez',22,'Benidorm');
