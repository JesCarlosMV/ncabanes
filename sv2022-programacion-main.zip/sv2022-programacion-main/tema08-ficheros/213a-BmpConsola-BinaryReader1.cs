﻿/*
Mostrar un BMP en consola (examen del tema 8, grupo presencial, 
2013-2014; resuelto en un video de Udemy)

Crea un programa que sea capaz de mostrar una imagen en blanco y negro 
en formato BMP de 256 colores en la consola, como el archivo de ejemplo 
que tienes compartido, llamado "welcome8.bmp".

La estructura de la cabecera de un fichero BMP es:

TYPE OF INFORMATION   POSITION IN THE FILE
File type (letters BM)  0-1
File Size  2-5
Reserved 6-7 
Reserved 8-9
Start of image data 10-13
Size of bitmap header 14-17
Width (pixels) 18-21
Height (pixels) 22-25
Number of planes 26-27
Size of each point 28-29
Compression (0=not compressed) 30-33
Image size 34-37
Horizontal resolution 38-41
Vertical resolution 42-45
Size of color table 46-49
Important colors counter 50-53

Puedes leer el ancho (bytes 18 a 21) y el alto (bytes 22 a 25) de la 
imagen, ya sea usando BinaryReader (cada uno es un entero de 32 bits) o 
FileStream (de la forma que puedes ver en la página 24 de los apuntes).

Los bytes 10 a 13 (que también forman un Int32) se pueden usar para 
saber en qué posición del fichero comienzan los datos de la imagen. 
Como alternativa, ya que cada píxel corresponde a un byte, puedes 
situarte a "-ancho*alto" desde el final del archivo y comenzar a leer 
desde ahí. 

Debes dibujar un "." si el valor del píxel es > 127, o un "*" en caso 
contrario.
*/

// Planteamiento 1: Byte a byte con BinaryReader

using System;
using System.IO;

class MostrarBMP
{
    static void Main(string[] args)
    {
        if (args.Length != 1)
        {
			Console.WriteLine("Por favor, indique el nombre de fichero");
		}
		else
        {
            byte[] cabecera = new byte[54];
            int inicioImagen, ancho, alto;
            char[,] imagen;
            byte byteLeido;
            if ( ! File.Exists(args[0]))
            {
				Console.WriteLine("El archivo no existe");
			}
			else
            {
				// Leemos cabecera
                BinaryReader fichero = new BinaryReader(
                    File.Open(args[0], FileMode.Open));
                for (int i = 0; i < cabecera.Length; i++)
                {
                    cabecera[i] = fichero.ReadByte();
                }
                
                // Analizamos cabecera: comienzo de datos, ancho, alto
                inicioImagen = cabecera[10]
					+cabecera[11]*256
					+cabecera[12]*256*256
					+cabecera[13]*256*256*256;
                ancho = cabecera[18]
					+cabecera[19]*256
					+cabecera[20]*256*256
                    +cabecera[21]*256*256*256;
                alto = cabecera[22]
					+cabecera[23]*256
					+cabecera[24]*256*256
                    +cabecera[25]*256*256*256;
                    
                // Leemos los datos de la imagen
                imagen = new char[alto, ancho];
                fichero.BaseStream.Seek(inicioImagen, SeekOrigin.Begin);
                Console.WriteLine(inicioImagen + " - " + ancho + " - "
                    + alto);
                for (int i = 0; i < alto; i++)
                {
                    for (int j = 0; j < ancho; j++)
                    { 
                    byteLeido = fichero.ReadByte();
                        if (byteLeido > 127)
                        {
                            imagen[i, j] = '.';
                        }
                        else
                        {
                            imagen[i, j] = '*';
                        }
                    }
                }
                fichero.Close();
                
                // Y la dibujamos cabeza abajo
                for (int i = alto - 1; i > 0; i--)
                {
                    for (int j = 0; j < ancho; j++)
                    {
                        Console.Write(imagen[i,j]);
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
