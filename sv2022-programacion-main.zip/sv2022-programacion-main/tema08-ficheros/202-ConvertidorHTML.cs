﻿// Francisco (...) - 1º DAM Semipresencial

/*
202. Crea un "convertidor básico de texto a HTML", que leerá un archivo de 
texto de origen y creará un archivo HTML a partir de su contenido, añadiendo 
una cabecera simple (que tendrá el nombre del fichero como "title") y tratando 
cada línea como un párrafo. Por ejemplo, si el archivo contiene:

Hola
Soy yo
Ya he terminado

El archivo HTML resultante debe contener

<html>
<head>
  <title>fichero.txt</title>
</head>
<body>
  <p>Hola</p>
  <p>Soy yo</p>
  <p>Ya he terminado</p>
</body>
</html>

El nombre del fichero de entrada se leerá de línea de comandos. Si no hay 
parámetros en línea de comandos, se le preguntará al usuario. El fichero de 
salida tendrá el mismo nombre que el de entrada, pero añadiendo ".html". Debes 
usar StreamReader y StreamWriter. Recuerda comprobar los posibles errores de 
funcionamiento.
*/


using System;
using System.IO;
class Ejercicio202
{
    static void Main(string[] args)
    {
        string ficheroDeEntrada, ficheroDeSalida, linea;
        StreamReader lectura;
        StreamWriter escritura;

        try
        {
            if (args.Length == 0)
            {
                Console.Write("Nombre del fichero de entrada: ");
                ficheroDeEntrada = Console.ReadLine();
            }
            else
            {
                ficheroDeEntrada = args[0];
            }

            ficheroDeSalida = ficheroDeEntrada + ".html";

            lectura = new StreamReader(ficheroDeEntrada);
            escritura = new StreamWriter(ficheroDeSalida);

            escritura.WriteLine("<html>");
            escritura.WriteLine("<head>");
            escritura.Write("  <title>");
            escritura.Write(ficheroDeEntrada);
            escritura.WriteLine("</title>");
            escritura.WriteLine("<body>");

            do
            {
                linea = lectura.ReadLine();
                if (linea != null)
                {
                    if (linea != "")
                    {
                        escritura.Write("  <p>");
                        escritura.Write(linea);
                        escritura.WriteLine("</p>");
                    }
                }
            }
            while (linea != null);

            escritura.WriteLine("</body>");
            escritura.WriteLine("</html>");

            lectura.Close();
            escritura.Close();
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("ERROR, el fichero no existe");
        }
        catch (IOException)
        {
            Console.WriteLine("ERROR de escritura o lectura");
        }
        catch (Exception e)
        {
            Console.WriteLine("ERROR: " + e.Message);
        }
    }
}
