﻿/*203. Crea una nueva versión del ejercicio 183 (lista de strings), partiendo 
de la versión oficial, en la que guardes datos al salir usando StreamWriter y 
cargues datos al comenzar la ejecución con StreamReader. Debes gestionar los 
posibles errores de forma adecuada.

Fátima (...) */

using System;
using System.Collections.Generic;
using System.IO;

class Ejercicio183
{
    static void Main()
    {
        List<string> frases = Cargar();

        const int ANYADIR = 1, VER = 2, BUSCAR = 3, MODIFICAR = 4,
            BORRAR = 5, SALIR = 0;
        int opcion;
        do
        {
            Console.WriteLine(ANYADIR + " Introducir frase");
            Console.WriteLine(VER + " Ver todas las frases");
            Console.WriteLine(BUSCAR + " Buscar una frase");
            Console.WriteLine(MODIFICAR + " Modificar una frase");
            Console.WriteLine(BORRAR + " Borrar una frase");
            Console.WriteLine(SALIR + " Salir");
            opcion = Convert.ToInt32(Console.ReadLine());
            string frase;
            switch (opcion)
            {
                case ANYADIR:
                    Console.Write("Frase: ");
                    frase = Console.ReadLine();
                    if (frase != "")
                    {
                        frases.Add(frase);
                    }
                    break;

                case VER:
                    foreach (string f in frases)
                    {
                        Console.WriteLine(f);
                    }
                    break;

                case BUSCAR:
                    Console.WriteLine("Texto a buscar: ");
                    string textoBuscar = Console.ReadLine().ToLower();
                    foreach (string f in frases)
                    {
                        if (f.ToLower().Contains(textoBuscar))
                        {
                            Console.WriteLine(f);
                        }
                    }
                    break;

                case MODIFICAR:
                    Console.WriteLine("¿Que frase quieres modificar?: ");
                    int numeroModificar = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Nuevo contenido: ");
                    string fraseNueva = Console.ReadLine();
                    frases[numeroModificar - 1] = fraseNueva;
                    break;

                case BORRAR:
                    Console.WriteLine("¿Que frase quieres borrar?: ");
                    int numeroBorrar = Convert.ToInt32(Console.ReadLine());
                    frases.RemoveAt(numeroBorrar - 1);
                    Console.WriteLine("Borrado con éxito");
                    break;

                case SALIR:
                    Console.WriteLine("Fin del programa");
                    break;

                default:
                    Console.WriteLine("Opción no válida");
                    break;
            }
        }
        while (opcion != 0);

        Guardar(frases);
    }


    private static List<string> Cargar()
    {
        List<string> frases = new List<string>();

        if (!File.Exists("frases.txt"))
        {
            return frases;
        }
        try
        {
            StreamReader fichero = new StreamReader("frases.txt");
            int cantidad = Convert.ToInt32(fichero.ReadLine());

            for (int i = 0; i < cantidad; i++)
            {
                string linea = fichero.ReadLine();
                frases.Add(linea);
            }
            fichero.Close();
        }
        catch (IOException)
        {
            Console.WriteLine("Error de lectura");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }
        return frases;
    }


    private static void Guardar(List<string> frases)
    {
        try
        {
            StreamWriter fichero = new StreamWriter("frases.txt");
            fichero.WriteLine(frases.Count);
            foreach (string f in frases)
            {
                fichero.WriteLine(f);
            }
            fichero.Close();
        }
        catch(IOException)
        {
            Console.WriteLine("Error de escritura");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error: " + e.Message);
        }
    }   
}
