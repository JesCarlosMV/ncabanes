// Dan 1DAW

/* 205. Crea un programa que pida el nombre de un fichero GIF y 
compruebe si realmente se trata de una imagen en ese formato. Debes 
hacerlo con BinaryReader. Para conseguirlo, deberás leer byte a byte, y 
comprobar que los 4 primeros bytes corresponden a los caracteres G, I, 
F, 8. El quinto byte permite saber la versión concreta de fichero GIF 
del que se trata (GIF87 o GIF89), que deberás mostrar en pantalla. 
Tienes un fichero de ejemplo "welcome8.gif" compartido en Aules y 
GitHub. */

// Versión 2: con constructor

using System;
using System.IO;

class Ejercicios
{
    static void Main()
    {
        Console.Write("Nombre del fichero: ");
        string nombre = Console.ReadLine();
        
        try
        {
            BinaryReader f = new BinaryReader(
				File.Open(nombre, FileMode.Open));

            byte byte1 = (byte)f.ReadByte();
            byte byte2 = (byte)f.ReadByte();
            byte byte3 = (byte)f.ReadByte();
            byte byte4 = (byte)f.ReadByte();
            byte byte5 = (byte)f.ReadByte();

            if (byte1 == 'G' && byte2 == 'I' && 
                byte3 == 'F' && byte4 == '8')
            {
                Console.WriteLine("Es un gif versión: {0}", 
					Convert.ToChar(byte5));
            }
            else
            {
                Console.WriteLine("No es un gif");
            }

            f.Close();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
    }
}
