﻿// Juan Manuel (...) 1º DAM Semipresencial

/*
209. Crea una variante del programa anteriores: deberá extraer los caracteres
imprimibles (código ASCII 32 a 127, además del 7, el 10 y el 13) de un fichero
y los vuelque a otro fichero. Todos los demás bytes que leas se convertirán a
espacio (ASCII 32). El nombre del fichero de origen se tomará de la línea de
comandos y el de destino se creará añadiendo ".2.txt" al nombre de origen. Debes
usar FileStream (tanto para leer como para escribir) y un bloque con el tamaño de
todo el archivo. Si el fichero de destino ya existe, lo sobreescribirás sin
preguntar. Puedes probarlo (por ejemplo) con los ficheros documento.doc y
customer.dbf que tienes compartidos en Aules y GitHub.
*/

using System;
using System.IO;


class Ejercicio209
{
    static void Main(string[] args)
    {
        if (args.Length == 1)
        {
            if (File.Exists(args[0]))
            {
                try
                {
                    if (File.Exists(args[0]))
                    {
                        FileStream entrada = File.OpenRead(args[0]);
                        int tamanyo = (int)entrada.Length;
                        byte[] datos = new byte[tamanyo];
                        //creamos un arraya del tamaño de fichero y
                        //leemos todo el contenido.

                        FileStream salida = File.Create(entrada.Name + ".2.txt");
                        // Creo el fichero de salida en la misma carpeta del de origen.

                        int cantidadLeida = entrada.Read(datos, 0, tamanyo);
                        entrada.Close();
                        if (cantidadLeida == tamanyo)
                        {
                            for (int i = 0; i < cantidadLeida; i++)
                            {
                                if (datos[i] == 7 || datos[i] == 10 || datos[i] == 13 ||
                                    (datos[i] >= 32 && datos[i] <= 127))
                                {
                                    salida.WriteByte(datos[i]);
                                }
                                else
                                {
                                    salida.WriteByte(32);
                                }
                            }

                            salida.Close();
                            Console.WriteLine("Fichero creado...");
                        }
                        else
                        {
                            Console.WriteLine("No se ha podido leer el fichero origen.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("El fichero {0} no existe", args[0]);
                    }
                }
                catch (PathTooLongException e1)
                {
                    Console.WriteLine("Ruta muy larga");
                }
                catch (IOException e2)
                {
                    Console.WriteLine("Error de E/S: {0}", e2);
                }
                catch (Exception e3)
                {
                    Console.WriteLine("Error: {0}", e3);
                }
            }
            else
            {
                Console.WriteLine("Fichero origen {0} no existe.", args[0]);
            }
        }
        else
        {
            Console.WriteLine("Número de argumentos no adecuados en la línea de comando.");
        }
    }
}

