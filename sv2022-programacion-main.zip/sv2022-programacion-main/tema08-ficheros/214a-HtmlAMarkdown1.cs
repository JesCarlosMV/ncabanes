﻿
/* 214
Debes crear un programa capaz de extraer el texto plano contenido en un fichero HTML.
Partirá de un fichero que se leerá de parámetros (o se pedirá al usuario en caso de no
existir parámetros) y creará un fichero con el mismo nombre y en el que la extensión
".html" (o ".htm", quizá en mayúsculas) será reemplazada por ".txt".

A partir de un fichero con un contenido como

<!DOCTYPE html>
<html>
<body>
  <h1>Título</h1>
  <p>Párrafo
  con <b>varias</b> palabras.</p>
  <ul>
    <li>Dato uno</li>
    <li>Dato dos</li>
  </ul>
</body>
</html>


Se debería generar otro con el contenido:



# Título

Párrafo
con varias palabras.

* Dato uno
* Dato dos


Es decir: no se mostrarán cabeceras, se eliminarán los sangrados del texto,
si los hay; los títulos y los párrafos tendrán a continuación una línea en blanco;
los elementos de lista se precederán por asterisco y espacio; los títulos se
precederán por una almohadilla; se eliminarán todas las etiquetas.

Como mejora deseable (pero que puntuará por encima del 10, sólo en caso de que el
resto del ejercicio esté perfecto), los párrafos que estén formados por varias
líneas deberán agruparse en una única línea y luego partirse en palabras exactas
en la columna 72 o la columna anterior más cercana. Por ejemplo

<p>Este es un párrafo formado
inicialmente por tres líneas
que deberían agruparse en una
única línea para luego partirla.</p>


se convertiría en

Este es un párrafo formado inicialmente por tres líneas que deberían
agruparse en una única línea para luego partirla.

*/

using System;
using System.Collections.Generic;
using System.IO;

class HtmlAMarkdown
{
    static int Main(string[] args)
    {
        string nombreArchivo;

        if (args.Length < 1)
        {
            Console.WriteLine("Escribe el nombre del archivo a convertir");
            nombreArchivo = Console.ReadLine();
        }
        else
        {
            nombreArchivo = args[0];
        }


        if (File.Exists(nombreArchivo))
        {
            try
            {
                List<string> lineas = new List<string>(
					File.ReadAllLines(nombreArchivo));
                int cantidad = lineas.Count;

                for (int i = 0; i < cantidad; i++)
                {
					lineas[i] = lineas[i].Trim();
					lineas[i] = lineas[i].Replace("<h1>", "# ");
					lineas[i] = lineas[i].Replace("</h1>",
						Environment.NewLine);

					lineas[i] = lineas[i].Replace("<p>", "");
					lineas[i] = lineas[i].Replace("</p>",
						Environment.NewLine + Environment.NewLine);
					lineas[i] = lineas[i].Replace("<b>", "");
					lineas[i] = lineas[i].Replace("</b>", "");
					lineas[i] = lineas[i].Replace("<ul>", "");
					lineas[i] = lineas[i].Replace("</ul>", "");
					lineas[i] = lineas[i].Replace("<li>", "* ");
					lineas[i] = lineas[i].Replace("</li>", "");

                    if (lineas[i].Contains("<!DOCTYPE html>")
						|| lineas[i].Contains("<body>")
						|| lineas[i].Contains("<html>")
						|| lineas[i].Contains("</html>")
						|| lineas[i].Contains("</body>"))
                    {
						lineas.RemoveAt(i);
						i--;
						cantidad--;
                    }
                }
                nombreArchivo = nombreArchivo.ToLower().Replace(".html", ".txt");
                nombreArchivo = nombreArchivo.ToLower().Replace(".htm", ".txt");
                File.WriteAllLines(nombreArchivo, lineas.ToArray());
                Console.WriteLine("Se ha completado con exito");
                return 0;
            }
            catch(FileNotFoundException)
            {
                Console.WriteLine("No se encuentra el archivo");
                return 1;
            }
            catch(IOException)
            {
                Console.WriteLine("Error de escritura");
                return 1;
            }
            catch (Exception e)
            {
                Console.WriteLine("ERROR: " + e);
                return 1;
            }
        }
        else
        {
            Console.WriteLine("El fichero no existe");
            return 1;
        }
    }
}
