﻿/*
92. Crea una función llamada "ComprobarHechos", que escriba en pantalla "Se me 
va dando mejor la programación". Úsala desde Main, en un programa de prueba, en 
el que la función esté declarada después de Main.
*/

using System;

class Recomendado92
{
    static void Main()
    {
        Console.WriteLine("Probando...");
        ComprobarHechos();
    }

    static void ComprobarHechos()
    {
        Console.WriteLine("Se me va dando mejor la Programación");
    }
}
