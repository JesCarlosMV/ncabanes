// Escribir del 100 al 125
// Ismael (...)

using System;

class De100a125 
{
    static void Main() 
    {
        int i = 100;
        while (i <= 125) 
        {
            Console.WriteLine(i);
            i++;
        }

    }
}
