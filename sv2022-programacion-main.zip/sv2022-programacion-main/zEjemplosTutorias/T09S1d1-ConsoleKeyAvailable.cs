// Mejora el ejercicio anterior,
// para que además, cada segundo
// se mueva una posición hacia arriba,
// comenzando desde la fila 20.

using System;
using System.Threading;

class ReadKey2
{
    static void Main()
    {
        bool terminado = false;
        int x = 30;
        int y = 10;

        Console.BackgroundColor = ConsoleColor.DarkBlue;
        Console.ForegroundColor = ConsoleColor.Yellow;

        do
        {
            Console.Clear();
            Console.SetCursorPosition(x, y);
            Console.Write("A");
            y--;
            Thread.Sleep(1000);
            if (Console.KeyAvailable)
            {
                ConsoleKeyInfo tecla = Console.ReadKey();
                
                if (tecla.Key == ConsoleKey.RightArrow)
                    x++;
                if (tecla.Key == ConsoleKey.LeftArrow)
                    x--;
                if (tecla.Key == ConsoleKey.Escape)
                    terminado = true;
            }
        }
        while (!terminado);

    }
}
