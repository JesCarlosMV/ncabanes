// Muestra la fecha actual, en formato
// "04-Abril-23 Martes". Ayúdate de un
// array con los nombres de los meses
// y otro con los nombres de los días
// de la semana.

using System;
using System.IO;

class FechaHoraToString
{
    static void Main()
    {

        string[] nombresMeses = { "Enero" , 
            "Febrero", "Marzo", "Abril"};
        string[] nombresDias = { "Domingo", "Lunes" ,
            "Martes"};
        DateTime hoy = DateTime.Now;
        
        Console.WriteLine(hoy);
        // 04/04/2023 10:31:35

        Console.Write("{0}-{1}-{2} ",
            hoy.Day.ToString("00"),
            nombresMeses[hoy.Month-1],
            hoy.Year % 100
        );
        // 04-Abril-23

        //Console.Write(hoy.DayOfWeek);
        // Tuesday
        //Console.Write((int) hoy.DayOfWeek);
        // 2
        Console.WriteLine(nombresDias[ 
            (int)hoy.DayOfWeek]);
        // Martes

        // 04-Abril-23 Martes

        Console.WriteLine("d= " + hoy.ToString("d"));
        Console.WriteLine("D= " + hoy.ToString("D"));
        Console.WriteLine("g= " + hoy.ToString("g"));
        Console.WriteLine("t= " + hoy.ToString("t"));

        // d = 04/04/2023
        // D = martes, 4 de abril de 2023
        // g = 04 / 04 / 2023 10:41
        // t = 10:41
    }
}
