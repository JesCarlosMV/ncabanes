using System;
using System.IO;
using System.Collections.Generic;

public class Persist01
{
    public int Numero;
    public double Numero2;
    public List<int> Datos = new List<int>
        { 2, 3, 4, 5 };

    public override string ToString()
    {
        string respuesta = Numero + " - " +
            Numero2 + " - ";
        foreach (int d in Datos)
        {
            respuesta += d + " ";
        }
        return respuesta;
    }

    public void Guardar(string nombre)
    {
        BinaryWriter ficheroSalida = new BinaryWriter(
            File.Open(nombre, FileMode.Create));
        ficheroSalida.Write(Numero);
        ficheroSalida.Write(Numero2);
        ficheroSalida.Write(Datos.Count);
        for (int i = 0; i < Datos.Count; i++)
        {
            ficheroSalida.Write(Datos[i]);
        }
        ficheroSalida.Close();
    }

    public void Cargar(string nombre)
    {
        BinaryReader ficheroEntrada = new BinaryReader(
            File.Open(nombre, FileMode.Open));
        Numero = ficheroEntrada.ReadInt32();
        Numero2 = ficheroEntrada.ReadDouble();
        int cantidad = ficheroEntrada.ReadInt32();
        Datos = new List<int>();
        for (int i = 0; i < cantidad; i++)
        {
            Datos.Add(ficheroEntrada.ReadInt32());
        }
        ficheroEntrada.Close();
    }


    public static void Main()
    {
        // Preparamos el objeto y lo guardamos
        Persist01 ejemplo = new Persist01();
        ejemplo.Numero = 5;
        ejemplo.Numero2 = 3.4;
        ejemplo.Datos[1] = 300;
        Console.WriteLine("Valor: {0}", ejemplo);
        ejemplo.Guardar("ejemplo2.dat");

        // Creamos un nuevo objeto
        Persist01 ejemplo2 = new Persist01();
        Console.WriteLine("Valor 2: {0}", ejemplo2);

        // Y cambiamos su valor, cargando los datos del primer objeto
        ejemplo2.Cargar("ejemplo2.dat");
        Console.WriteLine("Y ahora: {0}", ejemplo2);
    }

    // Valor: 5 - 3,4 - 2 300 4 5
    // Valor 2: 0 - 0 - 2 3 4 5
    // Y ahora: 5 - 3,4 - 2 300 4 5

}
