// Pide al usuario el nombre de un fichero WEBP. Lee un bloque de 4 bytes 
//tras saltar los primeros 8 bytes. Avísale en caso de que los 4 bytes no 
// sean W,E,B,P.

using System;
using System.IO;

class FichBinarios3
{
    static void Main()
    {
        byte[] cabecera = new byte[4];
        int cantidadLeida;

        FileStream fichero = File.OpenRead("welcome8.webp");
        fichero.Seek(8, SeekOrigin.Begin);
        cantidadLeida = fichero.Read(cabecera, 0, 4);
        if (cantidadLeida != 4)
        {
            Console.WriteLine("Fichero incompleto");
            return;
        }

        //...
        if ((cabecera[0] == 'W')
            && (cabecera[1] == 'E')
            && (cabecera[2] == 'B')
            && (cabecera[3] == 'P'))
        {
            Console.WriteLine("Es una imagen en formato WebP");
        }
        else
        {
            Console.WriteLine("No es una imagen en formato WebP");
        }
        fichero.Close();
    }
}
