// Pide al usuario el nombre de un fichero WEBP. Usando BinaryReader, lee 
// 4 bytes tras saltar los primeros 8 bytes. Avísale en caso de que los 4 
// bytes no sean W,E,B,P.

using System;
using System.IO;

class FichBinarios4
{
    static void Main()
    {
        byte c1, c2, c3, c4;

        BinaryReader fichero = 
            new BinaryReader(
                File.Open("welcome8.webp", 
                FileMode.Open));

        fichero.BaseStream.Seek(8, SeekOrigin.Begin);
        c1 = fichero.ReadByte();
        c2 = fichero.ReadByte();
        c3 = fichero.ReadByte();
        c4 = fichero.ReadByte();

        //...
        if ((c1 == 'W')
            && (c2 == 'E')
            && (c3 == 'B')
            && (c4 == 'P'))
        {
            Console.WriteLine("Es una imagen en formato WebP");
        }
        else
        {
            Console.WriteLine("No es una imagen en formato WebP");
        }
        fichero.Close();
    }
}
