/*
Crea una nueva versión de uno de los primeros ejercicios de arrays 
sobredimensionados (por ejemplo, el 75a), haciendo que se guarden los 
datos en fichero al terminar la ejecución y que se carguen desde 
fichero (si existe) al abrir el programa. Puedes aprovechar para que 
hacer que use listas, en vez de arrays.
*/

// Aproximación 2: usando una lista

using System;
using System.Collections.Generic;
using System.IO;

class LeerYGuardar2
{
    static void Main()
    {
        List<string> nombres = new List<string>();
        byte opcion;

        if (File.Exists("personas.dat"))
        {
            StreamReader ficheroEntrada = File.OpenText("personas.dat");
            string linea;
            do
            {
                linea = ficheroEntrada.ReadLine();
                if (linea != null)
                    nombres.Add(linea);
            }
            while (linea != null);
            ficheroEntrada.Close();
        }

        do
        {
            Console.WriteLine("1. Añadir un nuevo dato.");
            Console.WriteLine("2. Ver todos los datos.");
            Console.WriteLine("3. Buscar una persona.");
            Console.WriteLine("0. Salir.");

            opcion = Convert.ToByte(Console.ReadLine());

            switch (opcion)
            {
                case 0:
                    Console.WriteLine("Adiós.");
                    break;

                case 1:
                    Console.Write("Nombre a introducir: ");
                    nombres.Add( Console.ReadLine() );
                    break;

                case 2:
                    for (int i = 0; i < nombres.Count; i++)
                    {
                        Console.Write(nombres[i] + " ");
                    }
                    break;

                case 3:
                    Console.Write("Nombre a buscar: ");
                    string nombre = Console.ReadLine();

                    bool encontrado = false;
                    for (int i = 0; i < nombres.Count; i++)
                    {
                        if (nombres[i] == nombre)
                        {
                            encontrado = true;
                        }
                    }

                    if (encontrado)
                    {
                        Console.WriteLine("{0} es parte de la colección.", nombre);
                    }
                    break;
            }
        }
        while (opcion != 0);

        StreamWriter ficheroSalida = File.CreateText("personas.dat");
        foreach (string s in nombres)
        {
            ficheroSalida.WriteLine(s);
        }
        ficheroSalida.Close();
    }
}
