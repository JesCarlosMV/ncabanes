using System;

class EjemploEjercicio92
{
    static void Main()
    {
        ComprobarHechos();
    }

    static void ComprobarHechos()
    {
        Console.WriteLine("Se me va dando mejor la programación");
    }
}
