// Muestra una letra A en pantalla,
// que se pueda mover hacia izquierda
// y derecha con las flechas del cursor.

using System;

class ReadKey1
{
    static void Main()
    {
        bool terminado = false;
        int x = 30;
        int y = 10;
        do
        {
            Console.Clear();
            Console.SetCursorPosition(x, y);
            Console.Write("A");
            ConsoleKeyInfo tecla = Console.ReadKey();
            if (tecla.Key == ConsoleKey.RightArrow)
                x++;
            if (tecla.Key == ConsoleKey.LeftArrow)
                x--;
            if (tecla.Key == ConsoleKey.Escape)
                terminado = true;
        }
        while (!terminado);

    }
}
