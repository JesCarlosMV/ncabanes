// Crea una variante del ejercicio anterior, tratando todo el fichero como 
// una gran cadena de texto.

using System;
using System.IO;

class FicherosTexto2
{
	// El fichero de datos debe estar en una carpeta parecida a:
    // c:\users\nacho\source\repos\prueba\bin\debug
    // o
    // c:\users\nacho\source\repos\prueba\bin\debug\net6.0
 
    static void Main(string[] args)
    {
        string texto = File.ReadAllText("canciones.cs");
        texto = texto.Replace(" ", "");
        File.WriteAllText("canciones2.cs", texto);
    }
}


