// Crea una variable float, otra int y otra ulong.
// Guarda todas ellas en un mismo fichero usando un
// BinaryWriter. Luego lee todas ellas con un
// BinaryReader y comprueba que sus valores son
// los que esperabas.

using System;
using System.IO;

class Ejercicios
{
    static void Main()
    {
        float v1 = 3.5f;
        int v2 = 234567;
        ulong v3 = 12345678901234;

        BinaryWriter fichSalida =
            new BinaryWriter(
                File.Open("datos.dat",
                FileMode.Create));
        fichSalida.Write(v1);
        fichSalida.Write(v2);
        fichSalida.Write(v3);
        fichSalida.Close();

        float e1;
        int e2;
        ulong e3;
        BinaryReader fichEntrada = 
            new BinaryReader(
                File.Open("datos.dat", 
                FileMode.Open));
        e1 = fichEntrada.ReadSingle();
        e2 = fichEntrada.ReadInt32();
        e3 = fichEntrada.ReadUInt64();
        Console.WriteLine(e1);
        Console.WriteLine(e2);
        Console.WriteLine(e3);
        fichEntrada.Close();
    }
}
