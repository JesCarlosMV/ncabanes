using System;
using System.IO;

public class Persist01
{
    public int Numero;

    public void Guardar(string nombre)
    {
        BinaryWriter ficheroSalida = new BinaryWriter(
            File.Open(nombre, FileMode.Create));
        ficheroSalida.Write(Numero);
        ficheroSalida.Close();
    }

    public void Cargar(string nombre)
    {
        BinaryReader ficheroEntrada = new BinaryReader(
            File.Open(nombre, FileMode.Open));
        Numero = ficheroEntrada.ReadInt32();
        ficheroEntrada.Close();
    }


    public static void Main()
    {
        // Preparamos el objeto y lo guardamos
        Persist01 ejemplo = new Persist01();
        ejemplo.Numero = 5;
        Console.WriteLine("Valor: {0}", ejemplo.Numero);
        ejemplo.Guardar("ejemplo.dat");

        // Creamos un nuevo objeto
        Persist01 ejemplo2 = new Persist01();
        Console.WriteLine("Valor 2: {0}", ejemplo2.Numero);

        // Y cambiamos su valor, cargando los datos del primer objeto
        ejemplo2.Cargar("ejemplo.dat");
        Console.WriteLine("Y ahora: {0}", ejemplo2.Numero);
    }

    // Valor: 5
    // Valor 2: 0
    // Y ahora: 5

}
