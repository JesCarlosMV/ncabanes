// Pide al usuario el nombre de un fichero WEBP. Avísale en caso de que el 
// primer byte no sea una letra R.

using System;
using System.IO;

class FichBinarios1
{
    static void Main()
    {
        int dato;

        FileStream fichero = File.OpenRead("welcome8.webp");
        dato = fichero.ReadByte();
        if (dato != -1 )
        {
            byte datoCabecera = (byte) dato;
            if (dato == 'R')
            {
                Console.WriteLine("Parece un WEBP");
            }
            else
            {
                Console.WriteLine("NO ES un WEBP (no empieza por R)");
            }
        }
        fichero.Close();
    }
}
