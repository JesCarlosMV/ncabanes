using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

[Serializable]
public class Persist01
{
    public int Numero;

    public static void Guardar(string nombre, Persist01 dato)
    {
        IFormatter formatter = new BinaryFormatter();
        Stream fichero = new FileStream(nombre,
            FileMode.Create, FileAccess.Write,
            FileShare.None);
        formatter.Serialize(fichero, dato);
        fichero.Close();
    }


    public static Persist01 Cargar(string nombre)
    {
        Persist01 dato;
        IFormatter formatter = new BinaryFormatter();
        Stream fichero = new FileStream(nombre,
            FileMode.Open, FileAccess.Read,
            FileShare.Read);
        dato = (Persist01)formatter.Deserialize(fichero);
        fichero.Close();
        return dato;
    }



    public static void Main()
    {
        // Preparamos el objeto y lo guardamos
        Persist01 ejemplo = new Persist01();
        ejemplo.Numero = 5;
        Console.WriteLine("Valor: {0}", ejemplo.Numero);
        Guardar("ejemplo3.dat", ejemplo);

        // Creamos un nuevo objeto
        Persist01 ejemplo2 = new Persist01();
        Console.WriteLine("Valor 2: {0}", ejemplo2.Numero);

        // Y cambiamos su valor, cargando los datos del primer objeto
        ejemplo2 = Cargar("ejemplo3.dat");
        Console.WriteLine("Y ahora: {0}", ejemplo2.Numero);
    }

    // Valor: 5
    // Valor 2: 0
    // Y ahora: 5

}
