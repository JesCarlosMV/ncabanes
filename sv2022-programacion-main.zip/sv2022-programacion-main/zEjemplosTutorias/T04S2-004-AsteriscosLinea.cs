// Repaso de figuras geométricas 1: fila de 20 asteriscos

using System;

class AsteriscosLinea
{
    static void Main()
    {
        for (int i = 1; i < 20; i++)
        {
            Console.Write("*");
        }
        Console.WriteLine();
    }
}
