// Pide al usario números enteros, guárdalos en una lista y luego muestra los 
// positivos ordenados.

using System;
using System.Text.RegularExpressions;

class EjemploRegex
{
    public static bool EsReal(String s)
    {
        Regex r = new Regex(@"\A[0-9]*\.?[0-9]+\z");
        return r.IsMatch(s);
    }

    static void Main()
    {
        Console.WriteLine( "1.0 " + EsReal("1.0"));
        Console.WriteLine( "a " + EsReal("a"));
        Console.WriteLine( "1a " + EsReal("1a"));
        Console.WriteLine( "a0 " + EsReal("a0"));
        Console.WriteLine( ".25 " + EsReal(".25"));
        Console.WriteLine( "47 " + EsReal("47"));
        Console.WriteLine( "5 8 " + EsReal("5 8"));
    }
}
