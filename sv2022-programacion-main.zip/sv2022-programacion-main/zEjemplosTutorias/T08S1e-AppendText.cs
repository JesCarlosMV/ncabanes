// Crea un programa que, cada vez que se lance, pida una frase al usuario, 
// la añada al fichero "registro.txt" y termine.

using System;
using System.IO;

class FicherosTexto5
{
    static void Main()
    {
        Console.Write("Dato para el log? ");
        string linea = Console.ReadLine();

        StreamWriter fichero1 = File.AppendText("registro.txt");
        fichero1.WriteLine(linea);
        fichero1.Close();
    }
}

