// Comprime los ficheros de la
// carpeta actual, lanzando el
// compresor "rar" (o "7z") de
// línea de comandos. 
// Deberás usar una orden como "rar a datos *.*"

using System;
using System.Diagnostics;

class LanzarProceso
{
    static void Main()
    {
        Process proceso = Process.Start("rar.exe", "a datos *.cs");
        proceso.WaitForExit();

        if (proceso.ExitCode == 0) 
        {
            Console.WriteLine("Comprimido correctamente");
        }
        else
        {
            Console.WriteLine("No se ha podido comprimir");
        }
    }
}
