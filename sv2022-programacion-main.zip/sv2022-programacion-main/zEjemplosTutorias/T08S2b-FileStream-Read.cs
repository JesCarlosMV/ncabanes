// Pide al usuario el nombre de un fichero WEBP. Lee el primer bloque de 
// 12 bytes. Avísale en caso de que los bytes 9 a 12 no sean W,E,B,P.

using System;
using System.IO;

class FichBinarios2
{
    static void Main()
    {
        byte[] cabecera = new byte[12];
        int cantidadLeida;

        FileStream fichero = File.OpenRead("welcome8.webp");
        cantidadLeida = fichero.Read(cabecera, 0, 12);
        if (cantidadLeida != 12)
        {
            Console.WriteLine("Fichero incompleto");
            return;
        }

        //...
        if ((cabecera[8] == 'W')
            && (cabecera[9] == 'E')
            && (cabecera[10] == 'B')
            && (cabecera[11] == 'P'))
        {
            Console.WriteLine("Es una imagen en formato WebP");
        }
        else
        {
            Console.WriteLine("No es una imagen en formato WebP");
        }
        fichero.Close();
    }
}
