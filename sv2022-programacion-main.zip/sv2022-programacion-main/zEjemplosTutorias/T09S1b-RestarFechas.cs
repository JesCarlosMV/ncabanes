// Calcula cuántos días quedan hasta que
// empiecen los exámenes (22 de mayo).

using System;
using System.IO;

class DiasHasta22DeMayo
{
    static void Main()
    {
        DateTime hoy = DateTime.Today;
        DateTime fechaLimite =
            new DateTime(2023, 5, 22);

        TimeSpan diferencia = fechaLimite.Subtract(hoy);
        Console.WriteLine("Días restantes: " + diferencia.Days);

        // 48
    }
}
