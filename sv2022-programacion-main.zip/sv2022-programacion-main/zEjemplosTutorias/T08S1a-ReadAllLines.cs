// Abre un fichero de texto de nombre prefijado, volcando su contenido a 
// un array de cadenas.
// 
// Vuelca a otro fichero (también de nombre prefijado) su contenido tras 
// eliminar todos los espacios.

using System;
using System.IO;

class FicherosTexto1
{
	// El fichero de datos debe estar en una carpeta parecida a:
    // c:\users\nacho\source\repos\prueba\bin\debug
    // o
    // c:\users\nacho\source\repos\prueba\bin\debug\net6.0

    static void Main()
    {
        string[] lineas = File.ReadAllLines("canciones.cs");

        for (int i = 0; i < lineas.Length; i++)
        {
            lineas[i] = lineas[i].Replace(" ", "");
        }

        File.WriteAllLines("canciones2.cs", lineas);
    }
}

