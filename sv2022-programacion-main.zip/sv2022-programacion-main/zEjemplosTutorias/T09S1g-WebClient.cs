// Muestra las líneas que contienen
// la palabra "daw" en la página
// principal del IES San Vicente.

using System;
using System.Diagnostics;
using System.IO;  // Para Stream
using System.Net; // Para System.Net.WebClient 

class DescargarWeb
{
    static void Main()
    {
        WebClient client = new WebClient();
        Stream conexion = client.OpenRead("http://www.iessanvicente.com");
        StreamReader lector = new StreamReader(conexion);
        string linea;
        do
        {
            linea = lector.ReadLine();
            if (linea != null)
            {
                if (linea.ToUpper().Contains("DAW"))
                    Console.WriteLine(linea);
            }
        }
        while (linea != null);
        conexion.Close();

        //       <li><a href="alu/daw/index.php"> Desarrollo de Aplicaciones Web, presencial y semipresencial (Grado Superior)</a><br></li>
    }
}
