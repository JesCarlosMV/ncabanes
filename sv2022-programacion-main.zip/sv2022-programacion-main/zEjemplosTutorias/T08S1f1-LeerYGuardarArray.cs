/*
Crea una nueva versión de uno de los primeros ejercicios de arrays 
sobredimensionados (por ejemplo, el 75a), haciendo que se guarden los 
datos en fichero al terminar la ejecución y que se carguen desde 
fichero (si existe) al abrir el programa. Puedes aprovechar para que 
hacer que use listas, en vez de arrays.
*/

// Aproximación 1: usando un array sobredimensionado

using System;
using System.IO;

class LeerYGuardar1
{
    static void Main()
    {
        string[] nombres = new string[100];
        int cantidad = 0;
        byte opcion;

        if (File.Exists("personas.dat"))
        {
            StreamReader ficheroEntrada = File.OpenText("personas.dat");
            cantidad = Convert.ToInt32(ficheroEntrada.ReadLine());
            for (int i = 0; i < cantidad; i++)
            {
                nombres[i] = ficheroEntrada.ReadLine();
            }
            ficheroEntrada.Close();
        }

        do
        {
            Console.WriteLine("1. Añadir un nuevo dato.");
            Console.WriteLine("2. Ver todos los datos.");
            Console.WriteLine("3. Buscar una persona.");
            Console.WriteLine("0. Salir.");

            opcion = Convert.ToByte(Console.ReadLine());

            switch (opcion)
            {
                case 0:
                    Console.WriteLine("Adiós.");
                    break;

                case 1:
                    Console.Write("Nombre a introducir: ");
                    nombres[cantidad] = Console.ReadLine();
                    cantidad++;
                    break;

                case 2:
                    for (int i = 0; i < cantidad; i++)
                    {
                        Console.Write(nombres[i] + " ");
                    }
                    break;

                case 3:
                    Console.Write("Nombre a buscar: ");
                    string nombre = Console.ReadLine();

                    bool encontrado = false;
                    for (int i = 0; i < cantidad; i++)
                    {
                        if (nombres[i] == nombre)
                        {
                            encontrado = true;
                        }
                    }

                    if (encontrado)
                    {
                        Console.WriteLine("{0} es parte de la colección.", nombre);
                    }
                    break;
            }
        }
        while (opcion != 0);

        StreamWriter ficheroSalida = File.CreateText("personas.dat");
        ficheroSalida.WriteLine(cantidad);
        for (int i = 0; i < cantidad; i++)
        {
            ficheroSalida.WriteLine(nombres[i]);
        }
        ficheroSalida.Close();
    }
}
