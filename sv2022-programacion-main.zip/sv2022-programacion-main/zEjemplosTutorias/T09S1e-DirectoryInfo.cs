// Muestra el nombre y fecha de los
// fuentes en C# (ficheros .cs) que
// hay en la carpeta actual.


using System;
using System.IO;

class Directorio
{
    static void Main()
    {
        DirectoryInfo directorio = new DirectoryInfo(".");
        FileInfo[] ficheros = directorio.GetFiles();
        foreach (FileInfo f in ficheros) 
        { 
            if (f.Extension == ".cs")
                Console.WriteLine(f.Name + " " + f.CreationTime);
        }
    }
}
