// Lee el primero de los tres ficheros que has creado en el ejercicio 
// anterior y muestra su contenido.

using System;
using System.IO;

class FicherosTexto4
{
    static void Main()
    {
        string linea;

        StreamReader fichero1 = File.OpenText("1.txt");
        do
        {
            linea = fichero1.ReadLine();
            if (linea != null)
                Console.WriteLine( linea );
        }
        while (linea != null);
        fichero1.Close();
    }
}

