// Pide al usario números enteros, guárdalos en una lista y luego muestra los 
// positivos ordenados.

using System;
using System.Collections.Generic;
using System.Linq;

class EjemploLinq
{
    static void Main()
    {
        List<int> datos = new List<int> { 5, 3, 2, -10, 8, 1};

        var resultado =
            from dato in datos
            where dato > 0
            orderby dato
            select dato;
        
        foreach (var n in resultado)
            Console.WriteLine(n);
    }
}
