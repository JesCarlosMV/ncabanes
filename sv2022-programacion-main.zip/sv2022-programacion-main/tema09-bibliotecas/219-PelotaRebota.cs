﻿// Juan Manuel (...) 1º DAM Semipresencial

/*
219. Crea un programa que muestre la hora actual en la esquina superior derecha
de la consola, en color gris, con fondo azul oscuro, actualizando cada segundo,
mientras una "pelota" (una letra O) de color cian rebota en la pantalla.
La pelota comenzará en unas coordenadas al azar de la pantalla. Debe detenerse
cuando el usuario pulse Intro.
*/

using System;
using System.Threading;

class Ejercicio219
{

    static void Escribe(int x, int y, string rotulo, ConsoleColor fondo,
        ConsoleColor texto)
    {
        Console.BackgroundColor = fondo;
        Console.ForegroundColor = texto;
        Console.SetCursorPosition(x, y);
        Console.Write(rotulo);
    }

    static void Main()
    {
        string horaActual = "";
        bool salir = false;

        Random aleator = new Random();
        int posicionX = aleator.Next(1, Console.WindowWidth + 1);
        int posicionY = aleator.Next(1, Console.WindowHeight + 1);
        int velocidadX = 1;
        int velocidadY = 1;
        int posicionPreviaX = -1;
        int posicionPreviaY = -1;

        Console.Clear();
        Console.CursorVisible = false;

        do
        {
            // Escribir la hora
            horaActual = DateTime.Now.ToString("HH:MM:ss");
            Escribe(Console.WindowWidth - horaActual.Length, 0,
                horaActual, ConsoleColor.DarkBlue, ConsoleColor.Gray);

            // Ahora la pelota
            if (posicionPreviaX != -1) //Primera ejecución en todas las demas borramos.
            {
                Escribe(posicionPreviaX, posicionPreviaY, " ", ConsoleColor.Black, ConsoleColor.Black);
            }

            Escribe(posicionX, posicionY, "O", ConsoleColor.Black, ConsoleColor.Cyan);


            if (posicionX > Console.WindowWidth - 2 || posicionX < 1)
            {
                velocidadX *= -1;
            }

            if (posicionY > Console.WindowHeight - 2 || posicionY < 1)
            {
                velocidadY *= -1;
            }

            // Actualizamos los valores de posicionPrevia
            posicionPreviaX = posicionX;
            posicionPreviaY = posicionY;

            // Modificamos las posiciones en funcion de la velocidad
            // que puede ser positiva o negativa.
            posicionX += velocidadX;
            posicionY += velocidadY;

            //Comprobando si hay una pulsación de teclado
            //y si esta es Intro salimos.
            if (Console.KeyAvailable)
            {
                ConsoleKeyInfo tecla = Console.ReadKey(true);
                if (tecla.Key == ConsoleKey.Enter)
                    salir = true;
            }

            Thread.Sleep(90);

        } while (!salir);

        Console.ResetColor();
        Console.CursorVisible = true;
    }
}

