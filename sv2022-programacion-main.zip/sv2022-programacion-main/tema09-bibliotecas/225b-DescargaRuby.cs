/*
225. Descarga, de forma automatizada, la versión HTML del libro "Learn Ruby the
Hard Way" (al menos los 52 ejercicios), desde

https://learnrubythehardway.org/book/
*/

// Versión alternativa, más compacta, usando "WebClient.DownloadFile"

// Nota: Funcionará desde VS2022, probablemente no desde Geany


using System;
using System.IO;
using System.Net;

public class DescargaRubyAlternativo
{
    public static void Main()
    {
        Console.Write("Descargando... ");
        WebClient webClient = new WebClient();
        for (int i = 0; i <= 52; i++)
        {
            Console.Write(i + " ");
            webClient.DownloadFile(
                "https://learnrubythehardway.org/book/ex"+
                i + ".html", 
                "ruby"+i.ToString("00")+".html");
        }
    }
}
