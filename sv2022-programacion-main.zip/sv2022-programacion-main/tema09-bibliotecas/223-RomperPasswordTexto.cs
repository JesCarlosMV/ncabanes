﻿//Francis (...) - 1ºDAM Semipresencial, retoques por Nacho

/*
223. Intenta romper la contraseña de un segundo archivo comprimido, en 
esta ocasión probando todas las palabras de un diccionario (el fichero 
"words.txt" que ya habíamos usando anteriormente). Tendrás un fichero 
compartido llamado "c2.7z" en Aules y en GitHub, y también tendrás el 
(des)compresor de línea de comandos "7za.exe" (la orden para 
descomprimir probando una contraseña "hola" es "7za x c2.7z -phola").
 */

using System;
using System.IO;
using System.Diagnostics;

class RomperPassword
{
    static void Main()
    {
        string[] palabras;
        palabras = File.ReadAllLines("words.txt");

        for (int i = 0; i < palabras.Length; i++)
        {
            string password = palabras[i];
            Console.Write(password + " ");
            Process proceso = Process.Start("7za.exe", "x c2.7z -p"  
                + password);
            proceso.WaitForExit();
            if (proceso.ExitCode == 0)
            {
                Console.WriteLine("La contraseña es: "
                    + password);
                return;
            }
        }
    }
}
