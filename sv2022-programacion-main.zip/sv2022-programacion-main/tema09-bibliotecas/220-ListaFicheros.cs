﻿/*
220. Crea un programa que muestre la lista de ficheros que hay en una cierta
ruta que se indique en línea de comandos (o en la carpeta del ejecutable, si
no se indica nada en línea de comandos). Para cada fichero, mostrará su nombre,
extensión, tamaño en KB (destacando los millares, si es el caso) y fecha
de modificación, así:

ejemplo.exe, 1.234 KB, 12-Mar-2023
ejemplo.dat, 67 KB, 04-Abr-2023

Autor: Igor (..) 1DAW 
*/


using System;
using System.IO;

class Ej220
{
    static void Main(string[] args)
    {
        string ruta;
        if (args.Length == 0)
        {
            ruta = Directory.GetCurrentDirectory();
        }
        else
        {
            ruta = args[0];
        }

        DirectoryInfo dir = new DirectoryInfo(ruta);
        FileInfo[] ficheros = dir.GetFiles();

        foreach (FileInfo fichero in ficheros)
        {
            string tamanyo = (fichero.Length / 1024.0).ToString("N3");

            string fechaModificacion =
                            fichero.LastWriteTime.ToString("dd-MMM-yyyy");

            fechaModificacion = fechaModificacion.Substring(0, 3) +
                                char.ToUpper(fechaModificacion[3]) +
                                fechaModificacion.Substring(4)
                                .Replace(".", string.Empty);

            Console.WriteLine("{0}, {1} KB, {2}", fichero.Name,
                                                  tamanyo, fechaModificacion);
        }
    }
}
