﻿/*
217. Crea un programa llamado "logger", que, cada vez que se lance,
añadirá una línea a un archivo de texto llamado "log.txt".  Esta línea
contendrá la fecha y hora actuales, en formato DD-MM-AA HH:MM:SS.mmm ,
seguida por el texto que el usuario haya indicado como parámetros de la
línea de comandos. Por ejemplo, si el ejecutable se llama "logger.exe" y
el usuario escribe "logger Esto es una prueba" en la línea de comandos,
se debe añadir una línea como:

05-04-23 17:20:02.023 - Esto es una prueba

Si no se indica nada en línea de comandos, se preguntará al usuario qué
texto desea anotar como parte del "log".


Autor: Igor (...) 1DAW 
*/


using System;
using System.IO;

class Logger
{
    static void Main(string[] args)
    {
        const string FICHERO_REGISTROS = "log.txt",
                     SEPARADOR = " - ";

        string parametros;
        if (args.Length > 0)
        {
            parametros = string.Join(" ", args);
        }
        else
        {
            Console.Write("¿Qué texto desea anotar como parte del registro?: ");
            parametros = Console.ReadLine();
        }

        DateTime fechaActual = DateTime.Now;
        string registro = string.Join(SEPARADOR,
                                fechaActual.ToString("dd-MM-yy HH:mm:ss.fff"),
                                parametros);

        try
        {
            using (StreamWriter ficheroRegistros =
                                File.AppendText(FICHERO_REGISTROS))
            {
                ficheroRegistros.WriteLine(registro);
            }

            Console.WriteLine("Registro añadido al fichero {0}: {1}",
                                        FICHERO_REGISTROS, registro);
        }
        catch (IOException e)
        {
            Console.WriteLine("Error en la escritura: {0}", e.Message);
        }
    }
}
