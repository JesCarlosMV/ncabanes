﻿// Juan Manuel (...) 1º DAM Semipresencial

/*
221. Crea un menú en consola, que permita al usuario lanzar 8 aplicaciones
prefijadas, pulsando las teclas del 1 al 8, o salir pulsando ESC. Por
ejemplo, 1 podría lanzar Geany y 2 podría lanzar el navegador de Internet.
*/


using System.Diagnostics;
using System;
using System.Threading;

class Ejercicio221
{

    static void MostrarMenu()
    {
        Console.WriteLine("1.- Geany.");
        Console.WriteLine("2.- Mozilla Firefox.");
        Console.WriteLine("3.- Microsoft Edge.");
        Console.WriteLine("4.- Bloc de notas.");
        Console.WriteLine("5.- MicroSoft Visual Studio.");
        Console.WriteLine("6.- Paint.");
        Console.WriteLine("7.- Calculadora.");
        Console.WriteLine("8.- Explorador de archivos.");
        Console.WriteLine("Esc.- Salir.");
        Console.WriteLine();
        Console.WriteLine("Seleccione una opción.");
    }

    static bool Salir()
    {
        Console.WriteLine("Adios...");
        Console.CursorVisible = true;
        return true;
    }


    static void Escribe(int x, int y, string rotulo, ConsoleColor fondo,
       ConsoleColor texto)
    {
        Console.BackgroundColor = fondo;
        Console.ForegroundColor = texto;
        Console.SetCursorPosition(x, y);
        Console.Write(rotulo);
        Console.ResetColor();
        Thread.Sleep(1500);
        string linea = new string(' ', rotulo.Length);
        Console.SetCursorPosition(x, y);
        Console.Write(linea);
    }


    static void Ejecuta(string rutaEjecucion)
    {
        try
        {
            Process proceso = Process.Start(rutaEjecucion);
            proceso.WaitForExit();
        }
        catch (Exception e)
        {
            Escribe(0, 12, e.Message, ConsoleColor.Blue, ConsoleColor.Yellow);
        }
    }



    static void Main()
    {
        bool salir = false;
        ConsoleKeyInfo tecla;
        Console.CursorVisible = false;
        MostrarMenu();
        do
        {
            if (Console.KeyAvailable)
            {
                tecla = Console.ReadKey(true);

                switch (tecla.Key)
                {
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        Ejecuta(@"C:\Program Files\Geany\bin\geany.exe");
                        break;

                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        Ejecuta(@"C:\Program Files\Mozilla Firefox\firefox.exe");
                        break;

                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        Ejecuta(@"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe");
                        break;

                    case ConsoleKey.D4:
                    case ConsoleKey.NumPad4:
                        Ejecuta("notepad.exe");

                        break;

                    case ConsoleKey.D5:
                    case ConsoleKey.NumPad5:
                        Ejecuta(@"C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\IDE\devenv.exe");
                        break;

                    case ConsoleKey.D6:
                    case ConsoleKey.NumPad6:
                        Ejecuta("mspaint.exe");
                        break;

                    case ConsoleKey.D7:
                    case ConsoleKey.NumPad7:
                        Ejecuta("calc.exe");
                        break;

                    case ConsoleKey.D8:
                    case ConsoleKey.NumPad8:
                        Ejecuta("explorer.exe");
                        break;

                    case ConsoleKey.Escape:
                        salir = Salir();
                        break;
                }
            }
        } while (!salir);
    }
}
