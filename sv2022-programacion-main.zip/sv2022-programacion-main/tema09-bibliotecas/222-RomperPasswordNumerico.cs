﻿//Francis (...) - 1ºDAM Semipresencial, retoques por Nacho

/*
222. Intenta romper la contraseña de un archivo comprimido, lanzando un 
descompresor y verificando si el valor devuelto es 0. Tendrás un 
fichero compartido llamado "c.rar" en Aules y en GitHub, cuya 
contraseña es un número de 4 cifras (entre 0000 y 9999), y también 
tendrás el (des)compresor de línea de comandos "rar.exe" (la orden para 
descomprimir el fichero "c.rar" probando una contraseña "1234" sería 
"rar x c.rar -p1234").
 */

using System;
using System.Diagnostics;

class RomperPassword
{
    static void Main()
    {
        for (int i = 0; i < 10000; i++)
        {
            string password = i.ToString("0000");
            Console.Write(password + " ");
            Process proceso = Process.Start("rar.exe", "x c.rar -p" 
                + password);
            proceso.WaitForExit();
            if (proceso.ExitCode == 0)
            {
                Console.WriteLine("La contraseña es: "
                    + password);
                return;
            }
        }
    }
}
