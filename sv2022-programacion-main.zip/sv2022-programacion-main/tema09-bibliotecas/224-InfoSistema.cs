﻿/*
224. Muestra información sobre el sistema: versión de Windows, versión
de Punto Net, nombre de usuario actual, carpeta de documentos y espacio
libre y espacio total en todas las particiones de disco (quizá necesites
buscar información sobre "DriveInfo").

Autor: Igor (...) 1DAW 
*/


using System;
using System.IO;

class Ej224
{
    static void Main()
    {
        Console.WriteLine("Versión de Windows: {0}", Environment.OSVersion);
        Console.WriteLine("Versión .NET: {0}", Environment.Version);
        Console.WriteLine("Nombre de usuario actual: {0}", Environment.UserName);
        Console.WriteLine("Carpeta de documentos: {0}" + Environment.NewLine,
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));

        DriveInfo[] unidades = DriveInfo.GetDrives();
        foreach (DriveInfo u in unidades)
        {
            Console.WriteLine("Unidad {0}", u.Name);
            Console.WriteLine("Espacio libre: {0} Mbytes", 
                u.AvailableFreeSpace / 1024 / 1024);
            Console.WriteLine("Espacio total: {0} Mbytes",
                u.TotalSize / 1024 / 1024);
            Console.WriteLine();
        }
    }
}
