﻿/*
226. Crea una nueva versión del ejercicio 188 (biblioteca + List),
descomponiendo en 3 clases:

La clase Libro tendrá los datos, así como los métodos que puedan ser interesantes
para un único libro (CompareTo, ToString, Contiene...). No debe hacer ninguna
referencia a la consola.
La clase ListaDeLibros debe ocultar que por debajo existe un List<Libro>, por lo
que tendrá una propiedad "Cantidad" (que ocultará a Count), un método
"Obtener(pos)" para acceder al libro que existe en cierta posición, un método
Anyadir para guardar un nuevo Libro, métodos para Cargar los datos anteriores
(si los hay) y para Guardar los datos en ficheros (tras añadir o modificar), etc.
Tampoco debe acceder a la consola.
La clase Biblioteca, que es la que interactúa con el usuario, y que, por tanto,
será la única que acceda a la consola. No debe saber que existe internamente un
"List<Libro>", ni acceder a ficheros, ni ordenar los datos... (podría ser deseable
que ni siquiera conociera la clase Libro, lo que se puede conseguir -por ejemplo-
haciendo que el método Anyadir de la clase ListaDeLibros no reciba un parámetro
de la clase Libro, sino un autor, un título y un año.

Autor: Igor (...) 1DAW, retoques menores por Nacho

Ejercicio base: https://github.com/ncabanes/sv2022-programacion/blob/main/tema07-memoriaDinamica/188-BibliotecaList.cs
*/


using System;
using System.Collections.Generic;
using System.IO;

// -------------

class Libro : IComparable<Libro>
{ 
    public string Titulo {get; set;}
    public string Autor { get; set; }
    public short AnyoPubli { get; set; }

    public Libro(string titulo, string autor, short anyoPubli)
    {
        Modificar(titulo, autor, anyoPubli);
    }

    public void Modificar(string nuevoTitulo, string nuevoAutor, short nuevoAnyoPubli)
    {
        Titulo = nuevoTitulo;
        Autor = nuevoAutor;
        AnyoPubli = nuevoAnyoPubli;
    }

    public override string ToString()
    {
        return "Título: " + Titulo + ", Autor: " + Autor +
               ", Año de publicación: " +
               (AnyoPubli == -1 ? "Desconocido" : ""+AnyoPubli);
    }

    public int CompareTo(Libro libro)
    {
        return Titulo.CompareTo(libro.Titulo);
    }

    public bool Contains(string busqueda)
    {
        return Titulo.ToUpper().Contains(busqueda.ToUpper());
    }
}

// -------------

class ListaDeLibros
{
    private List<Libro> libros;
    private const string NOMBRE_FICHERO= "libros.dat";

    public ListaDeLibros()
    {
        libros = new List<Libro>();
        Cargar();
    }

    public int Cantidad
    {
        get { return libros.Count; }
    }

    public Libro Obtener(int pos)
    {
        return libros[pos];
    }

    public void Anyadir(string titulo, string autor, short anyoPubli)
    {
        Libro nuevoLibro = new Libro(titulo, autor, anyoPubli);
        libros.Add(nuevoLibro);
        libros.Sort();
        Guardar();
    }

    public void Modificar(int pos, string autor, string titulo, short anyoPubli)
    {
        libros[pos].Modificar(autor, titulo, anyoPubli);
        Guardar();
    }

    public void Eliminar(int numRegistro)
    {
        libros.RemoveAt(numRegistro);
        Guardar();
    }

    private void Cargar()
    {
        if (File.Exists(NOMBRE_FICHERO))
        {
            try
            {
                using (StreamReader lector = new StreamReader(NOMBRE_FICHERO))
                {
                    string linea;
                    while ((linea = lector.ReadLine()) != null)
                    {
                        string[] datosLibro = linea.Split('#');
                        Libro libro = new Libro(
                            datosLibro[0], datosLibro[1], Convert.ToInt16(datosLibro[2]));
                        libros.Add(libro);
                    }
                }
            }
            catch (IOException e)
            {
                Console.WriteLine("Error cargando el fichero de datos: {0}", e.Message);
            }
        }
    }

    private void Guardar()
    {
        try
        {
            using (StreamWriter escritor = new StreamWriter(NOMBRE_FICHERO))
            {
                foreach (Libro libro in libros)
                {
                    escritor.WriteLine("{0}#{1}#{2}", 
                        libro.Titulo, libro.Autor,libro.AnyoPubli);
                }
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("Error guardando el fichero de datos: {0}", e.Message);
        }
    }
}

// -------------

class Biblioteca
{
    const string SALIR = "S",
            ANADIR = "1", VERTODO = "2", BUSCARTITULO = "3",
            BUSCARFECHA = "4", MODIFICAR = "5", BORRAR = "6",
            ORTOGRAFIA = "7";
    const byte BLOQUE = 18;

    static void Main()
    {
        string opcion;
        ListaDeLibros libros = new ListaDeLibros();

        do
        {
            MostrarMenu();
            opcion = PedirOpcion();
            switch (opcion)
            {
                case ANADIR: Anyadir(libros); break;
                case VERTODO: VerTodo(libros); break;
                case BUSCARTITULO: BuscarTitulo(libros); break;
                case BUSCARFECHA: BuscarFecha(libros); break;
                case MODIFICAR: Modificar(libros); break;
                case BORRAR: Borrar(libros); break;
                case ORTOGRAFIA: ComprobarOrtografia(libros); break;
                case SALIR: Console.WriteLine("¡Adiós!"); break;
                default: Console.WriteLine("Opción no válida!"); break;
            }
        }
        while (opcion != SALIR);
    }

    static void MostrarMenu()
    {
        Console.WriteLine("===============MENU===============");
        Console.WriteLine(ANADIR + "-Añadir un libro");
        Console.WriteLine(VERTODO + "-Mostrar todos los libros");
        Console.WriteLine(BUSCARTITULO + "-Buscar por título");
        Console.WriteLine(BUSCARFECHA + "-Buscar entre fechas");
        Console.WriteLine(MODIFICAR + "-Modificar libro");
        Console.WriteLine(BORRAR + "-Borrar libro");
        Console.WriteLine(ORTOGRAFIA + "-Revisar ortografía");
        Console.WriteLine(SALIR + "-Salir");
        Console.WriteLine();
    }

    static string PedirOpcion()
    {
        Console.Write("Opción?: ");
        return Console.ReadLine().ToUpper();
    }

    static void Anyadir(ListaDeLibros libros)
    {
        string titulo, autor;
        short anyoGuardar;

        titulo = PedirNoVacio("Título?: ");
        autor = PedirNoVacio("Autor?: ");
        // Año -1 si no se escribe nada
        string anyo = Pedir("Año de publicacion?: ");
        if (anyo == "")
        {
            anyoGuardar = -1;
        }
        else
        {
            anyoGuardar = Convert.ToInt16(anyo);
        }

        libros.Anyadir(titulo, autor, anyoGuardar);
    }

    static void VerTodo(ListaDeLibros libros)
    {
        if (libros.Cantidad == 0)
            Console.WriteLine("Sin datos");
        else
            for (int i = 0; i < libros.Cantidad; i++)
            {
                MostrarRegistro(libros, i);

                if ((i + 1) % BLOQUE == 0)
                {
                    Console.ReadLine();
                }
            }
        Console.WriteLine();
    }

    static void BuscarTitulo(ListaDeLibros libros)
    {
        Console.Write("BUSCAR. Título?: ");
        string buscar = Console.ReadLine();
        if (buscar != "")
        {
            for (int i = 0; i < libros.Cantidad; i++)
            {
                if (libros.Obtener(i).Contains(buscar))
                {
                    MostrarRegistro(libros, i);
                }
            }
        }
    }

    static void BuscarFecha(ListaDeLibros libros)
    {
        Console.WriteLine("BUSCAR. RANGO AÑO DE PUBLICACION");
        Console.Write("Entre año: ");
        ushort fecha1 = Convert.ToUInt16(Console.ReadLine());
        Console.Write("Y año: ");
        ushort fecha2 = Convert.ToUInt16(Console.ReadLine());

        // Invertir fechas si están al revés
        ushort fechaInicial = fecha1 > fecha2 ? fecha2 : fecha1;
        ushort fechaFinal = fecha1 < fecha2 ? fecha2 : fecha1;

        for (int i = 0; i < libros.Cantidad; i++)
        {
            if (libros.Obtener(i).AnyoPubli >= fechaInicial &&
                    libros.Obtener(i).AnyoPubli <= fechaFinal)
            {
                MostrarRegistro(libros, i);
            }
        }
    }

    static void Modificar(ListaDeLibros libros)
    {
        Console.Write("Número de registro?: ");
        int numRegistro = Convert.ToInt32(Console.ReadLine());
        if (numRegistro >= 1 && numRegistro <= libros.Cantidad)
        {
            MostrarRegistro(libros, numRegistro - 1);

            string titulo = Pedir("Título?: ").Trim();
            if (titulo == "")
            {
                titulo = libros.Obtener(numRegistro - 1).Titulo;
            }


            string autor  = Pedir("Autor?:").Trim();
            if (autor == "")
            {
                autor = libros.Obtener(numRegistro - 1).Autor;
            }

            string anyo = Pedir("Año de publicacion?: ");
            if (anyo == "")
            {
                anyo = "" + libros.Obtener(numRegistro - 1).AnyoPubli;
            }

            libros.Modificar(numRegistro - 1, 
                titulo, autor, Convert.ToInt16(anyo));

            // Avisos de mayúsculas, minúsculas, espacios
            if (EsMayusculas(libros.Obtener(numRegistro - 1).Autor))
            {
                Console.WriteLine("Cuidado: Autor en mayúsculas");
            }

            if (EsMayusculas(libros.Obtener(numRegistro - 1).Titulo))
            {
                Console.WriteLine("Cuidado: Título en mayúsculas");
            }

            if (EsMinusculas(libros.Obtener(numRegistro - 1).Autor))
            {
                Console.WriteLine("Cuidado: Autor en minúsculas");
            }

            if (EsMinusculas(libros.Obtener(numRegistro - 1).Titulo))
            {
                Console.WriteLine("Cuidado: Título en minúsculas");
            }

            if (libros.Obtener(numRegistro - 1).Autor.Contains("  "))
            {
                Console.WriteLine("Cuidado: Autor con espacios de sobra");
            }

            if (libros.Obtener(numRegistro - 1).Titulo.Contains("  "))
            {
                Console.WriteLine("Cuidado: Título con espacios de sobra");
            }
        }
        else
            Console.WriteLine("No se encuentra el registro.");
    }

    static void Borrar(ListaDeLibros libros)
    {
        Console.Write("Numero de registro?: ");
        int numRegistro = Convert.ToInt32(Console.ReadLine()) - 1;
        if (numRegistro >= 0 && numRegistro < libros.Cantidad)
        {
            MostrarRegistro(libros, numRegistro);

            Console.Write(
                "Seguro que quieres borrar este libro? Si/No:");
            string siNo = Console.ReadLine().ToUpper();
            if (siNo == "SI" || siNo == "S")
            {
                libros.Eliminar(numRegistro);
            }
        }
        else
        {
            Console.WriteLine("Sin datos");
            Console.WriteLine();
        }
    }

    static void ComprobarOrtografia(ListaDeLibros libros)
    {
        for (int i = 0; i < libros.Cantidad; i++)
        {
            bool fichaCorrecta = true;
            string titulo = libros.Obtener(i).Titulo;
            int longitud = titulo.Length;

            // Contiene espacios duplicados?
            if (titulo.Contains("  "))
            {
                fichaCorrecta = false;
            }

            // Empieza o termina en espacio?
            if (titulo[0] == ' ' ||
                titulo[longitud - 1] == ' ')
            {
                fichaCorrecta = false;
            }


            // Minúscula justo antes de mayúscula
            for (int l = 0; l < longitud - 1; l++)
            {

                if ((titulo[l] >= 'a') && (titulo[l] <= 'z')
                    && (titulo[l + 1] >= 'A') && (titulo[l + 1] <= 'Z'))
                {
                    fichaCorrecta = false;
                }
            }

            if (!fichaCorrecta)
            {
                string tituloCorregir;
                MostrarRegistro(libros, i);
                Console.Write("¿Desea arreglar este registro (s/n)? ");
                string corregir = Console.ReadLine().ToUpper();
                if (corregir == "S")
                {
                    // Sin espacios iniciales ni finales
                    tituloCorregir = libros.Obtener(i).Titulo.Trim();

                    // Sin espacios redundantes
                    while (tituloCorregir.Contains("  "))
                        tituloCorregir =
                            tituloCorregir.Replace("  ", " ");

                    // Mayúsculas correctas
                    // Fase 1: 1ª mayúscula, resto minúscula
                    tituloCorregir = tituloCorregir.ToUpper()[0] +
                                        tituloCorregir.ToLower().Substring(1);
                    // Fase 2: Mays tras cada punto
                    string t = tituloCorregir;
                    bool proxMayuscula = false;
                    for (int l = 1; l < t.Length - 1; l++)
                    {
                        if (t[l - 1] == '.')
                            proxMayuscula = true;

                        if ((t[l] >= 'a') && (t[l] <= 'z')
                            && proxMayuscula)
                        {
                            t = t.Insert(l, t.ToUpper().Substring(l, 1));
                            t = t.Remove(l + 1, 1);
                            proxMayuscula = false;
                        }
                    }
                    tituloCorregir = t;

                    libros.Modificar(i, 
                        tituloCorregir,
                        libros.Obtener(i).Autor,
                        libros.Obtener(i).AnyoPubli);
                }
            }
        }
    }

    // --------- Funciones auxiliares -------------

    static string Pedir(string aviso)
    {
        Console.Write(aviso);
        return Console.ReadLine();
    }

    static string PedirNoVacio(string aviso)
    {
        string respuesta;
        do
        {
            Console.Write(aviso);
            respuesta = Console.ReadLine();
        }
        while (respuesta == "");
        return respuesta;
    }

    static bool EsMayusculas(string texto)
    {
        return texto == texto.ToUpper();
    }

    static bool EsMinusculas(string texto)
    {
        return texto == texto.ToLower();
    }

    static void MostrarRegistro(ListaDeLibros libros, int pos)
    {
        Console.WriteLine("{0}- {1}", pos + 1, libros.Obtener(pos));
    }
}
