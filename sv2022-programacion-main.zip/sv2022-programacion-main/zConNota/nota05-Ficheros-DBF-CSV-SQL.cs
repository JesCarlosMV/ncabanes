﻿/*
Quinto ejercicio con nota (tema 8)
 
Queremos hacer un programa que genere sentencias INSERT de SQL a partir 
de la estructura (cantidad de campos y tipos de campos) de un fichero 
de base de datos .dbf, y de los datos que estarán guardados en un 
archivo .csv.

La llamada al programa será indicando 3 parámetros en línea de 
comandos: el primero es el nombre del archivo .dbf, el segundo el 
nombre del archivo .csv y el tercero será el nombre del archivo 
resultado .sql, como en:

convertir gente.dbf datos.csv amigos.sql

(tendrás compartidos ficheros de ejemplo, tanto DBF, como CSV, como la 
salida esperable en formato SQL).

Se debe comprobar que se han escrito los 3 parámetros (con las 
extensiones adecuadas) y en su caso, indicar el mensaje de error y la 
ayuda necesaria para que el usuario sepa utilizar el comando.

El programa leerá del archivo .dbf los nombre y tipos de los campos, 
para poder generar la sentencia SQL correspondiente. Después, el 
programa irá leyendo cada una de las líneas del archivo .csv para 
extraer la información con la que se completará la sentencia ‘insert’:

- Se comprobará que el número de datos de cada línea del fichero CSV 
coincide con el número de campos y en caso contrario, se pasará a la 
siguiente línea olvidándose de la que se acaba de leer.

- También se comprobará que los campos numéricos se pueden transformar 
a números y si se produce algún error, se olvidará la línea. Los 
números se escriben sin comillas.

- Los campos de texto se leerán entre comillas dobles y se deben volcar 
entre comillas simples.

- Para las fechas, daremos por sentado que se reciben como cadenas de 
texto en formato AAAA-MM-DD, y se volcarán en ese mismo formato.

Por último, se creará un fichero de texto según el nombre indicado en 
el que se irán añadiendo las sentencias INSERT válidas. El nombre de la 
tabla en cada orden INSERT coincidirá con el nombre que se ha escogido 
para ese archivo de salida.


Información sobre los formatos de los archivos:

o Formato CSV

El formato CSV ("Comma Separated Values") es un formato de intercambio 
usado por muchas hojas de cálculo y sistemas gestores de bases de 
datos. Se trata de una serie de valores separados por comas y 
encerrados entre comillas, aunque también existen variantes que no usan 
comillas, o que emplean punto y coma como separador. Es frecuente que 
los datos numéricos no estén encerrados entre comillas. Un fichero de 
ejemplo en el formato que usará nuestro ejercicio, con punto y coma 
como separador, comillas dobles en los textos y sin comillas en los 
números, podría ser:

"Juan";"López Pérez";"Alicante";25
"Antonio";"Pérez López";"Madrid";27

o Formato SQL

A partir de un fichero como ese (y utilizando los nombres de campos que 
se habrán leído del fichero DBF y el nombre del fichero de salida como 
nombre de tabla), se deberían generar órdenes como éstas:

INSERT INTO AMIGOS (NOMBRE, APELLIDOS, CIUDAD, EDAD) VALUES 
('Juan','López Pérez','Alicante',25);

INSERT INTO AMIGOS (NOMBRE, APELLIDOS, CIUDAD, EDAD) VALUES 
('Antonio','Pérez López','Madrid',27);

o Formato DBF

Es el usado por el antiguo gestor de bases de datos dBase, y soportado 
como formato de exportación por muchas herramientas actuales, como 
Excel o Access. 

Los archivos DBF se dividen en dos partes: una cabecera que almacena 
información sobre la estructura del archivo y una zona de datos.

La zona de cabecera se separa de la zona de datos con el carácter CR 
(avance de carro, número 13 del código ASCII). A su vez la cabecera se 
divide en dos partes: la primera ocupa 32 bytes y contiene información 
general sobre el archivo, mientras que la segunda contiene información 
sobre cada campo y está formada por tantos bloques de 32 bytes como 
campos tenga la tabla.

La cabecera general del archivo es:

Posicion        Tamaño (bytes)   Descripcion
     1                1          Nro. que identifica el producto con el fue creada la tabla
     2                3          Fecha ultima actualizacion año/mes/dia
     5                4          Nro.total de registros de la tabla (en orden inverso)
     9                2          Longitud total de la cabecera incluido CR
    11                2          Longitud del registro (incluye el caracter de marca de borrado)
    13                2          Reservados
    15                1          Flag de Transaccion activa
    16                1          Flag de encriptacion
    17               12          Indicadores para el uso en red de area local
    29                1          Flag de fichero de indica .MDX
    30                3          Reservados


La cabecera de cada campo es:

Posicion        Tamaño (bytes)   Descripcion
   1                  11         Nombre de Campo
  12                   1         Tipo de campo (C,D,F,L,M,N)
  13                   4         Reservados
  17                   1         Longitud de campo
  18                   1         Numero de decimales si el campo numerico, 
                                 tambien usado para campos de caracteres de gran tamaño
  19                   2         Reservados
  21                   1         Flag de area de trabajo
  22                  10         Reservados
  32                   1         Flag de inclusion en el indice .MDX

(Se puede observar que la cantidad de campos no se indica en la 
cabecera, pero se puede deducir, sabiendo la longitud de la cabecera, 
que está en las posiciones 9 y 10, y el tamaño de cada bloque de 
cabecera, que es de 32 bytes).

Los tipos de campo son:
- C y M: String
- D: Fecha
- F y N: Numérico 
- L: Lógico o booleano
*/

using System;
using System.Collections.Generic;
using System.IO;

class ExtractorDBFyCSVaSQL
{
    static void Main(string[] args)
    {
        if (!ParametrosValidos(args))
        {
            MostrarAyuda();
            return;
        }

        string nombreDBF = args[0];
        string nombreCSV = args[1];
        string nombreSQL = args[2];

        if (!File.Exists(nombreDBF) || !File.Exists(nombreCSV))
        {
            Console.WriteLine("Un fichero de entrada no existe");
            return;
        }

        List<string> camposDBF = LeerCamposDBF(nombreDBF);
        if (camposDBF.Count == 0)
        {
            Console.WriteLine("No se ha podido leer el DBF");
            return;
        }

        string[] datosCSV = File.ReadAllLines(nombreCSV);
        AnalizarYVolcar(camposDBF, datosCSV, nombreSQL);
    }

    private static void MostrarAyuda()
    {
        Console.WriteLine("Parámetros incorrectos. Deben ser: ");
        Console.WriteLine("fichEntrada1.dbf fichEntrada2.csv fichSalida.sql)");
    }

    private static bool ParametrosValidos(string[] args)
    {
        if (args.Length != 3)
            return false;

        if ((!args[0].ToLower().EndsWith(".dbf"))
                || (!args[1].ToLower().EndsWith(".csv"))
                || (!args[2].ToLower().EndsWith(".sql")))
            return false;

        return true;
    }

    private static List<string> LeerCamposDBF(string nombreDBF)
    {
        List<string> campos = new List<string>();
        const int TAMANYO_BLOQUE = 32;
        try
        {
            FileStream fichDBF = File.OpenRead(nombreDBF);
            fichDBF.Seek(8, SeekOrigin.Begin);
            int posicionDatos = fichDBF.ReadByte();
            int cantidadCampos = (posicionDatos / TAMANYO_BLOQUE) - 1;

            for (int i = 1; i <= cantidadCampos; i++)
            {
                fichDBF.Seek(TAMANYO_BLOQUE * i, SeekOrigin.Begin);
                string nombreCampo = "";
                for (int j = 0; j < 11; j++)
                {
                    int dato = fichDBF.ReadByte();
                    if (dato != 0)
                        nombreCampo += Convert.ToChar(dato);
                }
                campos.Add(nombreCampo);
            }
            fichDBF.Close();
        }
        catch { }
        return campos;
    }

    private static void AnalizarYVolcar(List<string> camposDBF,
        string[] datosCSV, string nombreSQL)
    {
        try
        {
            StreamWriter ficheroSQL = File.CreateText(nombreSQL);
            foreach (string dato in datosCSV)
            {
                // Preparamos el comienzo de INSERT, con nombres de campos
                string nombreTabla = nombreSQL.Split('.')[0];
                string ordenSQL = "INSERT INTO " + nombreTabla + " (";
                ordenSQL += string.Join(",", camposDBF);
                ordenSQL += ") VALUES (";

                // Obtenemos los valores, cambiando comillas
                List<string> camposCSV = DescomponerLineaCSV(dato);
                for (int i = 0; i < camposCSV.Count; i++)
                {
                    if (camposCSV[i].StartsWith("\""))
                        camposCSV[i] = "'"
                            + camposCSV[i].Substring(1, camposCSV[i].Length - 2)
                            + "'";
                }

                // Añadimos valores y guardamos
                ordenSQL += string.Join(",", camposCSV);
                ordenSQL += ");";
                ficheroSQL.WriteLine(ordenSQL);
            }
            ficheroSQL.Close();
        }
        catch (IOException ioe)
        {
            Console.WriteLine("Error de lectura/escritura: " + ioe.Message);
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }

    private static List<string> DescomponerLineaCSV(string linea)
    {
        List<string> resultado = new List<string>();
        while (linea.Length > 0)
        {
            int posIni = 0;
            // Si hay comillas, leemos hasta comillas y saltamos el ;
            if (linea[posIni] == '"') 
            { 
                int posFin = linea.IndexOf("\"", posIni+1);
                if (posFin == -1)
                    posFin = linea.Length;
                resultado.Add( linea.Substring(posIni, posFin+1) );
                linea = linea.Remove(posIni, posFin+1);
                if (linea.Length > 0)
                    linea = linea.Remove(0, 1);
            }
            // Si no hay comillas, leemos hasta el ;
            else
            {
                int posFin = linea.IndexOf(";");
                if (posFin == -1)
                    posFin = linea.Length;
                resultado.Add(linea.Substring(posIni, posFin));
                linea = linea.Remove(posIni, posFin);
                if (linea.Length > 0)
                    linea = linea.Remove(0, 1);
            }
        }

        return resultado;
    }
}
