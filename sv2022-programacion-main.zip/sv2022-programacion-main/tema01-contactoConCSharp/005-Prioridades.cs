/* Juan Manuel(...) 1º DAM Semipresencial */

/*5. Calcula el resultado de (50 - 12 / 5 + 2 * 3 ) % 7 (hazlo tanto a mano
  como empleando un programa que te ayude a comprobar que tus cálculos son
  correctos).
  */
  
  
using System;

class Calculo
{
    static void Main()
    {
        Console.WriteLine(" El resultado de (50 - 12 / 5 + 2 * 3 ) % 7 es {0}",
            (50 - 12 / 5 + 2 * 3 ) % 7);  
    }
}
