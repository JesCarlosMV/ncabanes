class Saludo 
{
    static void Main() 
    {
        System.Console.WriteLine("Hola Emiliano");
    }
}
