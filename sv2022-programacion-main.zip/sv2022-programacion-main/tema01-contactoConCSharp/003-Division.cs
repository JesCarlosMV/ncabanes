﻿//Nombre: Francisco de Borja (...)
//Vamos a dar el resultado de la operación de dividir 8765 entre 432.
        
public class Ejercicio1_3
{
    public static void Main()
    {
        int resultado;

        resultado = 8765 / 432;
        System.Console.WriteLine("El resultado de dividir 8765 entre 432 es {0}", 
            resultado);
    }
}
