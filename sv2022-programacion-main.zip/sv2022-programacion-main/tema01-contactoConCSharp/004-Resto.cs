﻿//Francis (...) - 1ºDAM Semipresencial

/*
 * 4. Haz un programa que calcule el resto de la división de 579 entre 12. 
 * Haz la división a mano y comprueba el resultado.
 */

class Ejercicio04_tema1
{
    static void Main()
    {
        int resto = 579 % 12;

        System.Console.Write("El resto de dividir 579 entre 12 es: ");
        System.Console.Write(resto);
    }
}
